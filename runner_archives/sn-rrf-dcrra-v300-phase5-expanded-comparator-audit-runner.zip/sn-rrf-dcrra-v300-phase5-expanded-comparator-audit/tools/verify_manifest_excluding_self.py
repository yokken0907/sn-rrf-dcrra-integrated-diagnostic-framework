#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib
ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "FILE_MANIFEST.csv"
SELF = {"FILE_MANIFEST.csv", "manifest.json"}
def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()
def main():
    if not MANIFEST.exists():
        print("FAIL-MANIFEST-MISSING")
        return 1
    rows=[]
    with MANIFEST.open(newline='', encoding='utf-8') as f:
        rows=list(csv.DictReader(f))
    errors=[]; count=0
    for row in rows:
        rel=row['path']
        if rel in SELF:
            continue
        p=ROOT/rel
        if not p.exists():
            errors.append(f"missing: {rel}"); continue
        if sha256(p) != row['sha256']:
            errors.append(f"sha256 mismatch: {rel}")
        count += 1
    if errors:
        print("FAIL-MANIFEST-VERIFICATION")
        for e in errors[:50]: print(e)
        return 1
    print("PASS-MANIFEST-VERIFICATION")
    print(f"verified_files={count}")
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
