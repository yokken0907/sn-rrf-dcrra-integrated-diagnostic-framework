# SN-RRF-DCRRA v3.0.0 Phase 5 Expanded Comparator Audit Runner

This package runs Phase 5 of the SN-RRF-DCRRA v3.0.0 internal deepening branch.

Phase 5 is an **internal SPARC expanded-comparator diagnostic audit**. It uses:

- `outputs_v3_0_0/residual_response_feature_table.csv` from Phase 0-3;
- `outputs_v3_0_0_phase4ab/` from Phase 4AB;
- local SPARC public `Rotmod_LTG/*_rotmod.dat` files supplied by the user's WSL workspace.

It does **not** perform non-SPARC external residual-level validation. That branch remains on data-availability HOLD until an independent non-SPARC radius-resolved baryonic component-curve table is available.

## Replay

```bash
python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase5_expanded_comparator_audit.py \
  --rotmod-dir ../data_external/sparc_public_rotmod/Rotmod_LTG
python scripts/verify_v300_phase5_outputs.py
```

Expected run-level statuses:

```text
PASS-MANIFEST-VERIFICATION
PASS-PHASE5-EXPANDED-COMPARATOR-AUDIT-RUN
PASS-V300-PHASE5-OUTPUT-VERIFICATION
```

## Claim boundary

The outputs are diagnostic comparator-audit evidence inside the SPARC residual-analysis branch only. They are not dark-matter exclusion, ΛCDM replacement, MOND/RAR falsification, NFW falsification, new-physics discovery, or non-SPARC external validation.
