# Phase 5 Claim Boundary

Allowed:

- expanded diagnostic comparator audit inside the SPARC 143-galaxy branch;
- comparison among SN-RRF-family, NFW-like diagnostic shape, cored-halo-like diagnostic shapes, baryonic-mismatch proxy, nuisance-gradient proxy, and over-flexible polynomial/null comparator;
- identification of comparator degeneracy, over-flexible absorption risk, and zone-level diagnostic structure.

Not allowed:

- dark-matter exclusion;
- ΛCDM replacement;
- MOND/RAR falsification;
- NFW-halo falsification;
- physical dark-matter taxonomy;
- particle identity inference;
- non-SPARC external residual-level validation claim.

The comparator functions are diagnostic shape families. They are not full physical implementations of the corresponding astrophysical model classes.
