# Phase 5 No-Go Ledger

No Phase 5 result may be promoted to any of the following claims:

- dark matter has been excluded;
- ΛCDM has been replaced;
- MOND/RAR has been falsified;
- NFW has been falsified;
- a new physical law has been discovered;
- the SN-RRF/DCRRA framework has been externally validated on non-SPARC data;
- a diagnostic comparator winner is a physical model-selection winner.

Allowed wording:

> Phase 5 expands the internal SPARC diagnostic comparator set and records comparator competitiveness, degeneracy, nuisance absorption, and over-flexible null risk under the tested reduced protocol.
