# Phase 5 Expanded Comparator Audit

Phase 4AB showed that DCRRA zones are not reducible to simple residual-shape clustering. Phase 5 therefore asks whether the residual-regime structure is better understood as a comparator-competitiveness and degeneracy structure.

Implemented diagnostic comparators:

1. `SN_RRF_LOCKED_N3_258993`
2. `SN_RRF_SATURATING_FAMILY`
3. `NFW_LIKE_DIAGNOSTIC`
4. `BURKERT_LIKE_CORED_HALO_DIAGNOSTIC`
5. `CORED_ISOTHERMAL_LIKE_DIAGNOSTIC`
6. `EINASTO_LIKE_SURROGATE_DIAGNOSTIC`
7. `BARYONIC_MISMATCH_PROXY`
8. `NUISANCE_GRADIENT_PROXY`
9. `OVERFLEX_POLY5_NULL`

These are all reduced diagnostic comparators fitted to normalized squared-velocity residuals reconstructed from SPARC public rotmod files. They are not full astrophysical model fits.

Primary outputs:

- `outputs_v3_0_0_phase5/expanded_comparator_scores_long.csv`
- `outputs_v3_0_0_phase5/expanded_comparator_winners.csv`
- `outputs_v3_0_0_phase5/expanded_comparator_zone_summary.csv`
- `outputs_v3_0_0_phase5/comparator_degeneracy_ledger.csv`
- `outputs_v3_0_0_phase5/phase5_decision.json`
- `outputs_v3_0_0_phase5/PHASE5_REPORT.md`
