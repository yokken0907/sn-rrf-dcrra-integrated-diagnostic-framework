#!/usr/bin/env python3
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd
VERSION = "3.0.0-phase5-expanded-comparator-audit"
EPS = 1e-12
FORBIDDEN_CLAIMS = ["dark_matter_exclusion","lcdm_replacement","mond_rar_falsification","nfw_falsification","new_physics_discovery","non_sparc_external_validation_claim","physical_model_selection_claim"]
ONE_SHAPE_GRIDS = np.array([0.05,0.075,0.10,0.15,0.20,0.25,0.30,0.40,0.50,0.65,0.80,1.00,1.25,1.60,2.00])
N_GRID = np.array([0.5,1.0,1.5,2.0,2.25,2.5,3.0,3.258993,4.0,6.0,8.0,12.0])
EINASTO_ALPHA_GRID = np.array([0.4,0.6,0.8,1.0,1.4])

def read_rotmod(path: Path) -> pd.DataFrame:
    rows=[]
    for line in path.read_text(errors='ignore').splitlines():
        line=line.strip()
        if not line or line.startswith('#'): continue
        parts=line.split()
        if len(parts)<8: continue
        try: rows.append([float(x) for x in parts[:8]])
        except ValueError: pass
    if not rows: raise ValueError(f"no numeric rows in {path}")
    return pd.DataFrame(rows, columns=['Rad','Vobs','errV','Vgas','Vdisk','Vbul','SBdisk','SBbul'])

def aic_from_resid(resid, k, weights=None):
    n=len(resid)
    sse=float(np.sum((weights if weights is not None else 1.0)*resid**2))
    sse=max(sse, EPS)
    return n*math.log(sse/max(n,1))+2*k

def fit_linear(y, X, k, weights=None, nonnegative=False):
    y=np.asarray(y,float); X=np.asarray(X,float)
    if X.ndim==1: X=X[:,None]
    if weights is not None:
        sw=np.sqrt(np.asarray(weights,float)); Xw=X*sw[:,None]; yw=y*sw
    else: Xw=X; yw=y
    try: coef,*_=np.linalg.lstsq(Xw,yw,rcond=None)
    except np.linalg.LinAlgError: coef=np.zeros(X.shape[1])
    if nonnegative: coef=np.maximum(coef,0)
    pred=X@coef; resid=y-pred
    return {'aic':aic_from_resid(resid,k,weights), 'coef':coef.tolist(), 'rss':float(np.sum(resid**2))}

def norm01(shape):
    arr=np.nan_to_num(np.asarray(shape,float), nan=0.0, posinf=0.0, neginf=0.0)
    m=np.max(np.abs(arr))
    return arr if m<=EPS else arr/m

def sat_kernel(s, sc, n):
    x=np.maximum(s,EPS)/max(sc,EPS); return norm01((x**n)/(1+x**n))
def nfw_shape(s, sc):
    x=np.maximum(s,EPS)/max(sc,EPS); return norm01((np.log1p(x)-x/(1+x))/np.maximum(x,EPS))
def burkert_shape(s, sc):
    x=np.maximum(s,EPS)/max(sc,EPS); return norm01((np.log1p(x)+0.5*np.log1p(x*x)-np.arctan(x))/np.maximum(x,EPS))
def cored_iso_shape(s, sc):
    x=np.maximum(s,EPS)/max(sc,EPS); return norm01(1-np.arctan(x)/np.maximum(x,EPS))
def einasto_surrogate_shape(s, sc, alpha):
    x=np.maximum(s,EPS)/max(sc,EPS); z=x**alpha; return norm01(1-np.exp(-z)*(1+z+0.5*z*z))

def best_one_shape(y, weights, s, model_name, shape_fn, extra_grid=None, k=2):
    best=None
    for sc in ONE_SHAPE_GRIDS:
        if extra_grid is None:
            shape=shape_fn(s,sc); fit=fit_linear(y,shape,k,weights,True)
            cand={'comparator':model_name,'aic':fit['aic'],'params':{'scale':float(sc),'amplitude':fit['coef'][0] if fit['coef'] else 0.0},'rss':fit['rss']}
            if best is None or cand['aic']<best['aic']: best=cand
        else:
            for eg in extra_grid:
                shape=shape_fn(s,sc,eg); fit=fit_linear(y,shape,k,weights,True)
                cand={'comparator':model_name,'aic':fit['aic'],'params':{'scale':float(sc),'extra':float(eg),'amplitude':fit['coef'][0] if fit['coef'] else 0.0},'rss':fit['rss']}
                if best is None or cand['aic']<best['aic']: best=cand
    return best

def best_sn_family(y, weights, s):
    best=None
    for sc in ONE_SHAPE_GRIDS:
        for n in N_GRID:
            shape=sat_kernel(s,sc,n); fit=fit_linear(y,shape,3,weights,True)
            cand={'comparator':'SN_RRF_SATURATING_FAMILY','aic':fit['aic'],'params':{'scale':float(sc),'n':float(n),'amplitude':fit['coef'][0] if fit['coef'] else 0.0},'rss':fit['rss']}
            if best is None or cand['aic']<best['aic']: best=cand
    return best

def polyfit_null(y, weights, s):
    deg=min(5,max(1,len(y)-2)); X=np.vstack([s**d for d in range(deg+1)]).T
    fit=fit_linear(y,X,deg+1,weights,False)
    return {'comparator':'OVERFLEX_POLY5_NULL','aic':fit['aic'],'params':{'degree':deg,'coef':fit['coef']},'rss':fit['rss']}
def nuisance_gradient(y, weights, s):
    X=np.vstack([np.ones_like(s),s]).T; fit=fit_linear(y,X,2,weights,False)
    return {'comparator':'NUISANCE_GRADIENT_PROXY','aic':fit['aic'],'params':{'intercept':fit['coef'][0],'slope':fit['coef'][1]},'rss':fit['rss']}
def baryonic_mismatch(y, weights, df, vscale2):
    gas=np.sign(df['Vgas'].to_numpy())*(df['Vgas'].to_numpy()**2)/vscale2
    stellar=(df['Vdisk'].to_numpy()**2+df['Vbul'].to_numpy()**2)/vscale2
    X=np.vstack([gas,stellar]).T; fit=fit_linear(y,X,2,weights,False)
    return {'comparator':'BARYONIC_MISMATCH_PROXY','aic':fit['aic'],'params':{'gas_coef':fit['coef'][0],'stellar_coef':fit['coef'][1]},'rss':fit['rss']}

def compute_for_galaxy(galaxy, zone, rotmod_path):
    df=read_rotmod(rotmod_path); vobs=df['Vobs'].to_numpy(float); err=np.maximum(df['errV'].to_numpy(float),1e-6)
    rad=df['Rad'].to_numpy(float); rlast=max(float(np.max(rad)),EPS); s=np.clip(rad/rlast,EPS,None)
    vscale=max(float(np.nanmax(np.abs(vobs))),EPS); vscale2=vscale*vscale
    vbar2=np.sign(df['Vgas'].to_numpy())*(df['Vgas'].to_numpy()**2)+df['Vdisk'].to_numpy()**2+df['Vbul'].to_numpy()**2
    y=(vobs*vobs-vbar2)/vscale2
    sigma=np.maximum(2*np.abs(vobs)*err/vscale2,0.05); weights=1/(sigma*sigma)
    rows=[]
    def add(c):
        c=dict(c); c.update({'galaxy':galaxy,'zone':zone,'rotmod_points':len(df),'Rlast_kpc':rlast}); rows.append(c)
    add(best_one_shape(y,weights,s,'SN_RRF_LOCKED_N3_258993',lambda ss,sc: sat_kernel(ss,sc,3.258993), k=2))
    add(best_sn_family(y,weights,s))
    add(best_one_shape(y,weights,s,'NFW_LIKE_DIAGNOSTIC',nfw_shape,k=2))
    add(best_one_shape(y,weights,s,'BURKERT_LIKE_CORED_HALO_DIAGNOSTIC',burkert_shape,k=2))
    add(best_one_shape(y,weights,s,'CORED_ISOTHERMAL_LIKE_DIAGNOSTIC',cored_iso_shape,k=2))
    add(best_one_shape(y,weights,s,'EINASTO_LIKE_SURROGATE_DIAGNOSTIC',einasto_surrogate_shape,extra_grid=EINASTO_ALPHA_GRID,k=3))
    add(baryonic_mismatch(y,weights,df,vscale2)); add(nuisance_gradient(y,weights,s)); add(polyfit_null(y,weights,s))
    best_aic=min(r['aic'] for r in rows)
    for r in rows:
        r['delta_aic_vs_best']=float(r['aic']-best_aic); r['params_json']=json.dumps(r.pop('params'), ensure_ascii=False, sort_keys=True); r['rss']=float(r['rss'])
    return rows

def classify_family(comp):
    if comp.startswith('SN_RRF'): return 'SN_RRF_FAMILY'
    if any(x in comp for x in ['NFW','BURKERT','ISOTHERMAL','EINASTO']): return 'HALO_OR_CORED_COMPARATOR'
    if 'BARYONIC' in comp: return 'BARYONIC_SYSTEMATICS_PROXY'
    if 'NUISANCE' in comp: return 'NUISANCE_PROXY'
    if 'OVERFLEX' in comp: return 'OVERFLEX_NULL'
    return 'OTHER'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--rotmod-dir', required=True); ap.add_argument('--feature-table', default='outputs_v3_0_0/residual_response_feature_table.csv'); ap.add_argument('--outdir', default='outputs_v3_0_0_phase5')
    args=ap.parse_args(); root=Path.cwd(); rotmod_dir=Path(args.rotmod_dir).expanduser().resolve(); feature_path=(root/args.feature_table).resolve(); outdir=(root/args.outdir); outdir.mkdir(parents=True, exist_ok=True)
    if not feature_path.exists(): raise FileNotFoundError(f'feature table not found: {feature_path}')
    if not rotmod_dir.exists(): raise FileNotFoundError(f'rotmod dir not found: {rotmod_dir}')
    ft=pd.read_csv(feature_path); all_scores=[]; missing=[]
    for _, row in ft.iterrows():
        gal=str(row['galaxy']).strip(); zone=str(row['dcrra7_residual_map_zone']).strip(); path=rotmod_dir/f'{gal}_rotmod.dat'
        if not path.exists(): missing.append(gal); continue
        all_scores.extend(compute_for_galaxy(gal, zone, path))
    scores=pd.DataFrame(all_scores)
    if scores.empty: raise RuntimeError('no comparator scores generated')
    scores['comparator_family']=scores['comparator'].map(classify_family); scores.to_csv(outdir/'expanded_comparator_scores_long.csv', index=False)
    winners=scores.sort_values(['galaxy','aic']).groupby('galaxy').head(1).copy().rename(columns={'comparator':'winning_comparator','comparator_family':'winning_comparator_family','aic':'winning_aic'})
    winners[['galaxy','zone','rotmod_points','Rlast_kpc','winning_comparator','winning_comparator_family','winning_aic','params_json','rss']].to_csv(outdir/'expanded_comparator_winners.csv', index=False)
    rows=[]
    for gal,g in scores.groupby('galaxy'):
        best=float(g['aic'].min()); within2=g[g['aic']<=best+2].sort_values('aic'); within10=g[g['aic']<=best+10].sort_values('aic')
        rows.append({'galaxy':gal,'zone':str(g['zone'].iloc[0]),'best_comparator':str(g.sort_values('aic').iloc[0]['comparator']),'within_2_count':int(len(within2)),'within_10_count':int(len(within10)),'within_2_comparators':'|'.join(within2['comparator'].astype(str).tolist()),'within_10_comparators':'|'.join(within10['comparator'].astype(str).tolist()),'overflex_within_2':bool((within2['comparator']=='OVERFLEX_POLY5_NULL').any()),'overflex_winner':bool(str(g.sort_values('aic').iloc[0]['comparator'])=='OVERFLEX_POLY5_NULL')})
    deg=pd.DataFrame(rows); deg.to_csv(outdir/'comparator_degeneracy_ledger.csv', index=False)
    wc=winners['winning_comparator'].value_counts().rename_axis('winning_comparator').reset_index(name='count'); wc['fraction']=wc['count']/len(winners); wc.to_csv(outdir/'expanded_comparator_winner_counts.csv', index=False)
    zone_summary=winners.groupby(['zone','winning_comparator']).size().reset_index(name='count'); ztot=winners.groupby('zone').size().rename('zone_total').reset_index(); zone_summary=zone_summary.merge(ztot,on='zone'); zone_summary['fraction_within_zone']=zone_summary['count']/zone_summary['zone_total']; zone_summary.to_csv(outdir/'expanded_comparator_zone_summary.csv', index=False)
    family_zone=winners.groupby(['zone','winning_comparator_family']).size().reset_index(name='count'); family_zone=family_zone.merge(ztot,on='zone'); family_zone['fraction_within_zone']=family_zone['count']/family_zone['zone_total']; family_zone.to_csv(outdir/'expanded_comparator_family_zone_summary.csv', index=False)
    matched=int(winners['galaxy'].nunique()); overflex=float((winners['winning_comparator']=='OVERFLEX_POLY5_NULL').mean()); snfrac=float((winners['winning_comparator_family']=='SN_RRF_FAMILY').mean()); halofrac=float((winners['winning_comparator_family']=='HALO_OR_CORED_COMPARATOR').mean()); near2=float(deg['within_2_count'].mean())
    interp='MIXED-COMPARATOR-STRUCTURE-DIAGNOSTIC'
    if overflex>=0.50: interp='OVERFLEX-NULL-DOMINATED-CAUTION'
    elif snfrac>=0.50: interp='SN-RRF-FAMILY-PROMINENT-WITHIN-EXPANDED-COMPARATORS'
    elif halofrac>=0.50: interp='HALO-OR-CORED-COMPARATOR-PROMINENT-WITHIN-EXPANDED-COMPARATORS'
    decision={'version':VERSION,'status':'PASS-PHASE5-EXPANDED-COMPARATOR-AUDIT-RUN','interpretation':interp,'feature_rows':int(len(ft)),'rotmod_dir':str(rotmod_dir),'matched_rotmod_count':matched,'missing_rotmod_count':int(len(missing)),'missing_rotmod_galaxies':missing,'comparator_count':int(scores['comparator'].nunique()),'score_rows':int(len(scores)),'overflex_winner_fraction':overflex,'sn_rrf_family_winner_fraction':snfrac,'halo_or_cored_comparator_winner_fraction':halofrac,'mean_within_2_comparator_count':near2,'external_validation_status':'HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE','claim_boundary':'Internal SPARC expanded diagnostic comparator audit only. Comparator wins are not physical model-selection claims.','forbidden_claims':FORBIDDEN_CLAIMS}
    (outdir/'phase5_decision.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False), encoding='utf-8')
    (outdir/'V300_PHASE5_DECISION.txt').write_text(f"PASS-PHASE5-EXPANDED-COMPARATOR-AUDIT-RUN\nfeature_rows={decision['feature_rows']}\nmatched_rotmod_count={matched}\nmissing_rotmod_count={len(missing)}\ncomparator_count={decision['comparator_count']}\nexternal_validation=HOLD\n", encoding='utf-8')
    report = "# Phase 5 Expanded Comparator Audit Report\n\n" + f"Status: `{decision['status']}`\n\nInterpretation flag: `{interp}`\n\n" + f"## Coverage\n\n- Feature rows: {decision['feature_rows']}\n- Matched SPARC rotmod files: {matched}\n- Missing rotmod files: {len(missing)}\n- Comparator count: {decision['comparator_count']}\n\n" + f"## Winner fractions\n\n- SN-RRF family winner fraction: {snfrac:.6f}\n- Halo/cored comparator winner fraction: {halofrac:.6f}\n- Overflex null winner fraction: {overflex:.6f}\n- Mean comparators within +2 AIC: {near2:.6f}\n\n## Claim boundary\n\nThis is an internal SPARC expanded diagnostic comparator audit. It is not a physical model-selection result and not non-SPARC external validation.\n"
    (outdir/'PHASE5_REPORT.md').write_text(report, encoding='utf-8')
    print(decision['status']); print(f"feature_rows={decision['feature_rows']}"); print(f"matched_rotmod_count={matched}"); print(f"missing_rotmod_count={len(missing)}"); print(f"comparator_count={decision['comparator_count']}"); print('external_validation=HOLD')
if __name__ == '__main__': main()
