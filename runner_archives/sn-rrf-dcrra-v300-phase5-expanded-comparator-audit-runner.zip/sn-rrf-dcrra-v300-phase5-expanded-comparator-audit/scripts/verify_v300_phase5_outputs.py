#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
OUT=Path.cwd()/'outputs_v3_0_0_phase5'
required=['expanded_comparator_scores_long.csv','expanded_comparator_winners.csv','expanded_comparator_zone_summary.csv','expanded_comparator_family_zone_summary.csv','expanded_comparator_winner_counts.csv','comparator_degeneracy_ledger.csv','phase5_decision.json','PHASE5_REPORT.md','V300_PHASE5_DECISION.txt']
def fail(msg):
    print('FAIL-V300-PHASE5-OUTPUT-VERIFICATION'); print(msg); return 1
def main():
    if not OUT.exists(): return fail('outputs_v3_0_0_phase5 missing')
    for name in required:
        if not (OUT/name).exists(): return fail(f'missing required output: {name}')
    decision=json.loads((OUT/'phase5_decision.json').read_text(encoding='utf-8'))
    scores=pd.read_csv(OUT/'expanded_comparator_scores_long.csv'); winners=pd.read_csv(OUT/'expanded_comparator_winners.csv')
    if decision.get('status')!='PASS-PHASE5-EXPANDED-COMPARATOR-AUDIT-RUN': return fail('decision status is not PASS run status')
    if int(decision.get('feature_rows',-1)) != 143: return fail('feature_rows != 143')
    if int(decision.get('matched_rotmod_count',-1)) != 143: return fail('matched_rotmod_count != 143')
    if int(decision.get('missing_rotmod_count',-1)) != 0: return fail('missing_rotmod_count != 0')
    if int(decision.get('comparator_count',-1)) < 8: return fail('comparator_count < 8')
    if winners['galaxy'].nunique()!=143: return fail('winner galaxy count != 143')
    if scores['galaxy'].nunique()!=143: return fail('score galaxy count != 143')
    print('PASS-V300-PHASE5-OUTPUT-VERIFICATION')
    print(f"feature_rows={decision['feature_rows']}")
    print(f"matched_rotmod_count={decision['matched_rotmod_count']}")
    print(f"missing_rotmod_count={decision['missing_rotmod_count']}")
    print(f"comparator_count={decision['comparator_count']}")
    print(f"interpretation={decision.get('interpretation')}")
    print('external_validation=HOLD')
    return 0
if __name__=='__main__': raise SystemExit(main())
