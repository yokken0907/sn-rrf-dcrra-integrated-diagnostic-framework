# SN-RRF-DCRRA v3.0.0 Phase 0-3 Internal Deepening Report

## Reader guidance

This is an internal diagnostic deepening report, not an astrophysical discovery claim. The report integrates selected SN-RRF v2.0.1 and DCRRA v1.0.1 outputs under the A10 theory-freedom / strict-audit operating split.

## Decision

```text
PASS-SN-RRF-DCRRA-v3.0.0-PHASE0-3-INTERNAL-DEEPENING-LOCKED

Decision:
  PASS internal feature-table construction, diagnostic feature-space audit, and provisional regime-transition adjacency construction.

External residual-level validation:
  HOLD. No non-SPARC radius-resolved baryonic component-curve table is bundled or accepted in this package.

Allowed interpretation:
  A claim-bounded SPARC-internal diagnostic feature-space and residual-regime transition audit.

Not claimed:
  No dark-matter exclusion; no Lambda-CDM replacement; no MOND/RAR falsification; no NFW-halo falsification; no new physical law; no external-complete validation.
```

## Feature-space audit

- Feature rows: 143
- Residual-map zones: 7
- PCA features used: 15
- First three explained-variance ratios: 0.9713, 0.0286, 0.0001
- Fraction closer to own zone centroid than nearest other zone centroid: 0.2657

## Top provisional regime-transition adjacencies

The following edges are kNN feature-space adjacencies only. They are not physical evolutionary paths.

| zone_a                           | zone_b                                    |   directed_knn_cross_count |   undirected_support_score |
|:---------------------------------|:------------------------------------------|---------------------------:|---------------------------:|
| NUISANCE_SENSITIVE_ZONE          | RESPONSE_FAMILY_DOMINANT_ZONE             |                        148 |                  0.147852  |
| RESPONSE_FAMILY_DOMINANT_ZONE    | RESPONSE_FAMILY_WITH_NFW_COMPETITIVE_ZONE |                        135 |                  0.134865  |
| MIXED_THREE_WAY_COMPETITIVE_ZONE | RESPONSE_FAMILY_DOMINANT_ZONE             |                         82 |                  0.0819181 |
| NUISANCE_SENSITIVE_ZONE          | RESPONSE_FAMILY_WITH_NFW_COMPETITIVE_ZONE |                         56 |                  0.0559441 |
| PATHOLOGY_ARCHIVE_ZONE           | RESPONSE_FAMILY_DOMINANT_ZONE             |                         55 |                  0.0549451 |
| HALO_COMPARATOR_DOMINANT_ZONE    | RESPONSE_FAMILY_DOMINANT_ZONE             |                         47 |                  0.046953  |
| MIXED_THREE_WAY_COMPETITIVE_ZONE | RESPONSE_FAMILY_WITH_NFW_COMPETITIVE_ZONE |                         45 |                  0.044955  |
| MIXED_THREE_WAY_COMPETITIVE_ZONE | NUISANCE_SENSITIVE_ZONE                   |                         43 |                  0.042957  |
| HALO_COMPARATOR_DOMINANT_ZONE    | RESPONSE_FAMILY_WITH_NFW_COMPETITIVE_ZONE |                         20 |                  0.01998   |
| PATHOLOGY_ARCHIVE_ZONE           | RESPONSE_FAMILY_WITH_NFW_COMPETITIVE_ZONE |                         19 |                  0.018981  |

## Failure-boundary ledger

The Phase 0-3 run records 348 failure-boundary events. These include pathology/archive preservation, nuisance-sensitive zones, low point-count risks, comparator degeneracy, and fixed-exponent non-uniqueness cases where neighbor monotone kernels compete with or beat the locked representative kernel.

## External validation

External residual-level validation remains HOLD. This package does not include a non-SPARC radius-resolved baryonic component-curve table. If such data arrives later, external validation must restart at manual material acceptance, not at full validation.

## Safe synthesis

Within the selected SPARC-internal SN-RRF/DCRRA outputs, the residual-regime map can be reorganized into a diagnostic feature-space and provisional regime-transition adjacency audit. This supports a further internal-deepening branch, but does not establish a physical dark-sector taxonomy or external observational validation.
