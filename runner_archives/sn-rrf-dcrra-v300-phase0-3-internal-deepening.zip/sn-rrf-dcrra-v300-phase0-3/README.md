# SN-RRF-DCRRA v3.0.0 Phase 0-3 Internal Deepening

**Status:** claim-bounded internal diagnostic deepening package.  
**Version:** `3.0.0-phase0-3-internal-deepening`  
**Suggested GitHub release tag:** `v3.0.0-phase0-3-internal-deepening`

This repository package integrates selected SN-RRF v2.0.1 and DCRRA v1.0.1 outputs into a Phase 0-3 internal diagnostic audit:

1. Phase 0: integration and claim-boundary lock.
2. Phase 1: residual-response feature table construction.
3. Phase 2: diagnostic feature-space / residual-response manifold audit.
4. Phase 3: provisional regime-transition adjacency diagnostics.

## Claim boundary

This package is **not** a dark-matter exclusion result, not a Lambda-CDM replacement, not a MOND/RAR falsification, not an NFW-halo falsification, not a new physical law, and not external residual-level validation.

The allowed interpretation is narrower: within the selected SPARC-internal SN-RRF/DCRRA outputs, this package constructs a reproducible diagnostic feature table, a feature-space coordinate audit, provisional regime-transition adjacencies, and a failure-boundary ledger.

## Current decision

```text
PASS-SN-RRF-DCRRA-v3.0.0-PHASE0-3-INTERNAL-DEEPENING-LOCKED

Decision:
  PASS internal feature-table construction, diagnostic feature-space audit, and provisional regime-transition adjacency construction.

External residual-level validation:
  HOLD. No non-SPARC radius-resolved baryonic component-curve table is bundled or accepted in this package.

Allowed interpretation:
  A claim-bounded SPARC-internal diagnostic feature-space and residual-regime transition audit.

Not claimed:
  No dark-matter exclusion; no Lambda-CDM replacement; no MOND/RAR falsification; no NFW-halo falsification; no new physical law; no external-complete validation.
```

## Key outputs

- `outputs_v3_0_0/residual_response_feature_table.csv`
- `outputs_v3_0_0/manifold_coordinates.csv`
- `outputs_v3_0_0/manifold_summary.json`
- `outputs_v3_0_0/regime_transition_edges.csv`
- `outputs_v3_0_0/failure_boundary_ledger.csv`
- `paper/figs/v300_phase0_3_feature_space_zone_overlay.png`
- `paper/figs/v300_phase0_3_regime_transition_edges.png`

## Replay

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/run_v300_phase0_to_phase3.py
python scripts/verify_v300_outputs.py
python tools/verify_manifest_excluding_self.py
```

## External validation status

External residual-level validation remains **HOLD**. No non-SPARC radius-resolved baryonic component-curve table is bundled or accepted in this package. If such material is provided later, restart at the manual material acceptance gate described in `docs/RESTART_PROTOCOL_IF_EXTERNAL_DATA_ARRIVES.md`.

## AI assistance disclosure

Large language models, including OpenAI ChatGPT, were used as research-assistance tools for theory structuring, verification-protocol organization, code drafting, numerical-audit workflow design, and manuscript/repository editing support. The author remains responsible for the final scientific claims, claim boundaries, interpretation, and public use of this package.
