#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs_v3_0_0'
required=[
 'phase0_integration_summary.json','residual_response_feature_table.csv','feature_schema.json',
 'manifold_coordinates.csv','manifold_zone_centroids.csv','manifold_summary.json',
 'regime_transition_edges.csv','regime_transition_summary.json','failure_boundary_ledger.csv',
 'V300_PHASE0_3_DECISION.txt'
]
missing=[p for p in required if not (OUT/p).exists()]
if missing:
    raise SystemExit('FAIL-V300-OUTPUT-VERIFICATION missing='+','.join(missing))
ft=pd.read_csv(OUT/'residual_response_feature_table.csv')
coords=pd.read_csv(OUT/'manifold_coordinates.csv')
summary=json.loads((OUT/'manifold_summary.json').read_text(encoding='utf-8'))
schema=json.loads((OUT/'feature_schema.json').read_text(encoding='utf-8'))
errors=[]
if len(ft)!=143: errors.append(f'expected 143 feature rows, got {len(ft)}')
if len(coords)!=143: errors.append(f'expected 143 coordinate rows, got {len(coords)}')
if ft['dcrra7_residual_map_zone'].nunique()!=7: errors.append('expected 7 residual map zones')
if not schema.get('external_validation_status','').startswith('HOLD'):
    errors.append('external validation status must remain HOLD')
if summary.get('external_component_curve_material') != 'not available in package':
    errors.append('external component-curve material must remain unavailable')
for forbidden in ['dark-matter exclusion','MOND/RAR falsification','NFW-halo falsification']:
    if forbidden not in summary.get('not_claimed',[]): errors.append('missing forbidden claim guard: '+forbidden)
if errors:
    raise SystemExit('FAIL-V300-OUTPUT-VERIFICATION\n'+'\n'.join(errors))
print('PASS-V300-OUTPUT-VERIFICATION')
print('feature_rows=143')
print('zone_count=7')
print('external_validation=HOLD')
