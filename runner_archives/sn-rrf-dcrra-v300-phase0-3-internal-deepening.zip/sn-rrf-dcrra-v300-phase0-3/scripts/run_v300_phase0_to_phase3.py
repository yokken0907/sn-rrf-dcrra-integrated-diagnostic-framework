#!/usr/bin/env python3
"""SN-RRF/DCRRA v3.0.0 Phase 0-3 internal-deepening audit.

This script constructs a unified residual-response feature table from selected
SN-RRF v2.0.1 and DCRRA v1.0.1 outputs, performs a strictly diagnostic
feature-space/PCA audit, and derives provisional regime-transition adjacency
edges. It does not perform external residual-level validation and does not make
physical dark-sector claims.
"""
from __future__ import annotations
import json
import math
import os
from pathlib import Path
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
SRC_SN = ROOT / "source_materials" / "sn_rrf_v2_0_1_selected"
SRC_D = ROOT / "source_materials" / "dcrra_v1_0_1_selected"
OUT = ROOT / "outputs_v3_0_0"
FIGS = ROOT / "paper" / "figs"
OUT.mkdir(exist_ok=True)
FIGS.mkdir(parents=True, exist_ok=True)

CLAIM_BOUNDARY = {
    "allowed": "SPARC-internal residual-regime feature-space diagnostics only.",
    "not_claimed": [
        "dark-matter exclusion",
        "Lambda-CDM replacement",
        "MOND/RAR falsification",
        "NFW-halo falsification",
        "new physical law discovery",
        "external residual-level validation",
        "universal exponent or physical constant",
    ],
}

NUMERIC_FEATURES = [
    "best_n",
    "rrf_rc_over_rlast",
    "rrf_A_over_vouter2",
    "v_outer_kms",
    "v_max_kms",
    "gas_fraction_proxy",
    "outer_baryon_fraction_proxy",
    "n_points",
    "estimated_family_delta_aic_minus_nfw_like",
    "estimated_family_delta_aic_minus_rar_like",
    "nearest_centroid_margin",
    "delta_aic_locked_minus_best_continuum",
    "grid_count_within_10_of_best",
    "delta_aic_rrf_minus_best_destructive_null",
    "delta_aic_rrf_minus_best_neighbor_null",
]

def read_inputs() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    d7 = pd.read_csv(SRC_D / "dcrra7_by_galaxy_residual_map.csv")
    d4 = pd.read_csv(SRC_D / "dcrra4_by_galaxy_triangular_comparator.csv")
    s26 = pd.read_csv(SRC_SN / "stage26_null_kernel_by_galaxy.csv")
    s30 = pd.read_csv(SRC_SN / "stage30_continuum_by_galaxy.csv")
    counts = pd.read_csv(SRC_D / "dcrra7_map_zone_counts.csv")
    return d7, d4, s26, s30, counts

def build_feature_table() -> pd.DataFrame:
    d7, d4, s26, s30, counts = read_inputs()
    # DCRRA7 already contains the primary SPARC-internal regime map. Join SN controls.
    ft = d7.copy()
    keep_s26 = [
        "galaxy", "rrf_aic_v2", "curve_level_rrf_A_kms2", "curve_level_rrf_rc_kpc",
        "best_destructive_null", "delta_aic_rrf_minus_best_destructive_null",
        "best_neighbor_null", "delta_aic_rrf_minus_best_neighbor_null",
    ]
    keep_s30 = [
        "galaxy", "best_aic_v2", "locked_aic_v2", "delta_aic_locked_minus_best_continuum",
        "locked_within_2_of_best", "locked_within_10_of_best", "grid_count_within_2_of_best",
        "grid_count_within_10_of_best",
    ]
    ft = ft.merge(s26[keep_s26], on="galaxy", how="left", validate="one_to_one")
    ft = ft.merge(s30[keep_s30], on="galaxy", how="left", validate="one_to_one")
    # Derived strictly diagnostic axes.
    ft["response_family_strength_axis"] = -ft["estimated_family_delta_aic_minus_nfw_like"].clip(upper=0) - ft["estimated_family_delta_aic_minus_rar_like"].clip(upper=0)
    ft["halo_competitiveness_axis"] = ft["estimated_family_delta_aic_minus_nfw_like"]
    ft["rar_competitiveness_axis"] = ft["estimated_family_delta_aic_minus_rar_like"]
    ft["nuisance_or_pathology_flag"] = ft["dcrra7_residual_map_zone"].isin(["NUISANCE_SENSITIVE_ZONE", "PATHOLOGY_ARCHIVE_ZONE"]).astype(int)
    ft["overflex_neighbor_risk_flag"] = (ft["delta_aic_rrf_minus_best_neighbor_null"] > 0).astype(int)
    ft["destructive_null_pass_flag"] = (ft["delta_aic_rrf_minus_best_destructive_null"] < 0).astype(int)
    # Conservative, not physics: normalized compactness of proxy feature row.
    ft["component_curve_external_validation_status"] = "NOT_TESTED_DATA_AVAILABILITY_HOLD"
    return ft

def robust_zscore(df: pd.DataFrame, features: List[str]) -> Tuple[np.ndarray, List[str], Dict[str, Dict[str, float]]]:
    used=[]; cols=[]; stats={}
    for f in features:
        if f not in df.columns: continue
        x=pd.to_numeric(df[f], errors="coerce").astype(float)
        if x.notna().sum() < 10: continue
        med=float(np.nanmedian(x)); q1=float(np.nanpercentile(x,25)); q3=float(np.nanpercentile(x,75)); iqr=q3-q1
        if not np.isfinite(iqr) or iqr == 0: continue
        z=(x-med)/iqr
        z=z.replace([np.inf,-np.inf], np.nan).fillna(0.0)
        used.append(f); cols.append(z.to_numpy()); stats[f]={"median":med,"q1":q1,"q3":q3,"iqr":iqr}
    X=np.vstack(cols).T if cols else np.empty((len(df),0))
    return X, used, stats

def pca_svd(X: np.ndarray, ncomp:int=3) -> Tuple[np.ndarray, np.ndarray]:
    Xc = X - np.mean(X, axis=0, keepdims=True)
    U,S,Vt=np.linalg.svd(Xc, full_matrices=False)
    coords=U[:,:ncomp]*S[:ncomp]
    var=(S**2)/(max(X.shape[0]-1,1))
    ratio=var/var.sum() if var.sum()>0 else var
    return coords, ratio[:ncomp]

def zone_centroids(coords: np.ndarray, zones: pd.Series) -> pd.DataFrame:
    rows=[]
    for z in sorted(zones.dropna().unique()):
        idx=np.where(zones.to_numpy()==z)[0]
        sub=coords[idx]
        rows.append({
            "zone":z,
            "count":len(idx),
            "pc1_centroid":float(np.mean(sub[:,0])),
            "pc2_centroid":float(np.mean(sub[:,1])),
            "pc3_centroid":float(np.mean(sub[:,2])) if coords.shape[1]>2 else 0.0,
            "pc12_radius_median":float(np.median(np.sqrt((sub[:,0]-np.mean(sub[:,0]))**2+(sub[:,1]-np.mean(sub[:,1]))**2))),
        })
    return pd.DataFrame(rows)

def knn_edges(coords: np.ndarray, zones: pd.Series, k:int=7) -> pd.DataFrame:
    n=len(coords)
    D=np.sqrt(((coords[:,None,:2]-coords[None,:,:2])**2).sum(axis=2))
    edge_counts={}
    for i in range(n):
        nn=np.argsort(D[i])[1:k+1]
        zi=zones.iloc[i]
        for j in nn:
            zj=zones.iloc[j]
            if zi==zj: continue
            a,b=sorted([str(zi),str(zj)])
            edge_counts[(a,b)]=edge_counts.get((a,b),0)+1
    rows=[]
    for (a,b),cnt in edge_counts.items():
        rows.append({"zone_a":a,"zone_b":b,"directed_knn_cross_count":cnt,"undirected_support_score":cnt/(n*k)})
    out=pd.DataFrame(rows).sort_values(["directed_knn_cross_count","zone_a","zone_b"], ascending=[False,True,True])
    return out

def simple_separation(coords: np.ndarray, zones: pd.Series) -> Dict[str,float]:
    cent=zone_centroids(coords,zones)
    centers=cent[["pc1_centroid","pc2_centroid"]].to_numpy()
    labels=cent["zone"].tolist()
    zone_to_center={z:centers[i] for i,z in enumerate(labels)}
    own=[]; other=[]
    for i,z in enumerate(zones):
        c=zone_to_center[z]
        own.append(float(np.linalg.norm(coords[i,:2]-c)))
        od=[float(np.linalg.norm(coords[i,:2]-zone_to_center[zz])) for zz in labels if zz!=z]
        other.append(min(od) if od else 0)
    own=np.array(own); other=np.array(other)
    return {
        "median_own_centroid_distance_pc12":float(np.median(own)),
        "median_nearest_other_centroid_distance_pc12":float(np.median(other)),
        "centroid_margin_median_other_minus_own":float(np.median(other-own)),
        "fraction_closer_to_own_centroid_than_other":float(np.mean(own < other)),
    }

def make_figures(coords_df: pd.DataFrame, ft: pd.DataFrame, edges: pd.DataFrame) -> None:
    # Matplotlib with default colors; no physics interpretation.
    zones=coords_df["dcrra7_residual_map_zone"].unique().tolist()
    fig, ax = plt.subplots(figsize=(8,6))
    for z in zones:
        sub=coords_df[coords_df["dcrra7_residual_map_zone"]==z]
        ax.scatter(sub["pc1"], sub["pc2"], label=z.replace("_ZONE",""), s=28, alpha=0.82)
    ax.set_xlabel("PC1 diagnostic feature coordinate")
    ax.set_ylabel("PC2 diagnostic feature coordinate")
    ax.set_title("SN-RRF/DCRRA v3.0.0 Phase 0-3: diagnostic feature-space map")
    ax.legend(fontsize=7, loc="best")
    fig.tight_layout()
    fig.savefig(FIGS/"v300_phase0_3_feature_space_zone_overlay.png", dpi=160)
    plt.close(fig)

    counts=ft["dcrra7_residual_map_zone"].value_counts().sort_values(ascending=True)
    fig, ax = plt.subplots(figsize=(8,5))
    ax.barh([c.replace("_ZONE","") for c in counts.index], counts.values)
    ax.set_xlabel("Galaxy count")
    ax.set_title("DCRRA residual-map zones carried into v3.0.0 integration")
    fig.tight_layout()
    fig.savefig(FIGS/"v300_phase0_3_zone_counts.png", dpi=160)
    plt.close(fig)

    top=edges.head(10).copy()
    if len(top):
        labels=[f"{a.replace('_ZONE','')} ↔ {b.replace('_ZONE','')}" for a,b in zip(top.zone_a, top.zone_b)]
        fig, ax=plt.subplots(figsize=(9,5))
        ax.barh(labels[::-1], top["directed_knn_cross_count"].values[::-1])
        ax.set_xlabel("kNN cross-zone adjacency count")
        ax.set_title("Provisional diagnostic regime-transition adjacencies")
        fig.tight_layout()
        fig.savefig(FIGS/"v300_phase0_3_regime_transition_edges.png", dpi=160)
        plt.close(fig)

def failure_boundary_ledger(ft: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    def add(g, condition, category, note):
        rows.append({"galaxy":g,"failure_boundary_condition":condition,"category":category,"diagnostic_note":note})
    for _,r in ft.iterrows():
        g=r["galaxy"]
        zone=r["dcrra7_residual_map_zone"]
        if zone=="PATHOLOGY_ARCHIVE_ZONE": add(g,"pathology_archive_zone","archive_not_repaired","Do not promote to physical interpretation.")
        if zone=="NUISANCE_SENSITIVE_ZONE": add(g,"nuisance_sensitive_zone","nuisance_boundary","Treat as systematics/model-sensitivity boundary material.")
        if pd.notna(r.get("n_points")) and r["n_points"] < 10: add(g,"low_rotation_curve_point_count","data_density_risk","Low point count can destabilize residual-regime interpretation.")
        if pd.notna(r.get("nearest_centroid_margin")) and r["nearest_centroid_margin"] < 0.5: add(g,"low_proxy_centroid_margin","proxy_degeneracy","Proxy-only constructive control gives weak class-separation margin.")
        if pd.notna(r.get("delta_aic_rrf_minus_best_neighbor_null")) and r["delta_aic_rrf_minus_best_neighbor_null"] > 0: add(g,"neighbor_monotone_kernel_competes_or_beats_locked_kernel","fixed_exponent_nonuniqueness","Supports family interpretation rather than fixed exponent.")
        if pd.notna(r.get("estimated_family_delta_aic_minus_nfw_like")) and abs(r["estimated_family_delta_aic_minus_nfw_like"]) < 10: add(g,"family_nfw_comparator_degeneracy","comparator_boundary","No strong family-vs-NFW diagnostic separation under AIC threshold 10.")
        if pd.notna(r.get("estimated_family_delta_aic_minus_rar_like")) and abs(r["estimated_family_delta_aic_minus_rar_like"]) < 10: add(g,"family_rar_comparator_degeneracy","comparator_boundary","No strong family-vs-RAR diagnostic separation under AIC threshold 10.")
    return pd.DataFrame(rows)

def main() -> None:
    ft=build_feature_table()
    ft.to_csv(OUT/"residual_response_feature_table.csv", index=False)
    X, used, stats = robust_zscore(ft, NUMERIC_FEATURES)
    coords, ratio = pca_svd(X, 3)
    coords_df=pd.DataFrame({
        "galaxy":ft["galaxy"],
        "dcrra7_residual_map_zone":ft["dcrra7_residual_map_zone"],
        "pc1":coords[:,0], "pc2":coords[:,1], "pc3":coords[:,2],
    })
    coords_df.to_csv(OUT/"manifold_coordinates.csv", index=False)
    cent=zone_centroids(coords, ft["dcrra7_residual_map_zone"])
    cent.to_csv(OUT/"manifold_zone_centroids.csv", index=False)
    edges=knn_edges(coords, ft["dcrra7_residual_map_zone"], k=7)
    edges.to_csv(OUT/"regime_transition_edges.csv", index=False)
    ledger=failure_boundary_ledger(ft)
    ledger.to_csv(OUT/"failure_boundary_ledger.csv", index=False)
    schema={
        "row_count": int(len(ft)),
        "galaxy_id_column": "galaxy",
        "zone_column": "dcrra7_residual_map_zone",
        "numeric_features_used_for_pca": used,
        "feature_robust_scaling_stats": stats,
        "claim_boundary": CLAIM_BOUNDARY,
        "external_validation_status": "HOLD: no non-SPARC radius-resolved baryonic component-curve table bundled or tested",
    }
    (OUT/"feature_schema.json").write_text(json.dumps(schema, indent=2), encoding="utf-8")
    separation=simple_separation(coords, ft["dcrra7_residual_map_zone"])
    summary={
        "phase": "v3.0.0 Phase 0-3 internal-deepening",
        "decision": "PASS-INTERNAL-FEATURE-SPACE-AUDIT; EXTERNAL-RESIDUAL-VALIDATION-HOLD",
        "row_count": int(len(ft)),
        "zone_count": int(ft["dcrra7_residual_map_zone"].nunique()),
        "pca_features_used": used,
        "pca_explained_variance_ratio_first3": [float(x) for x in ratio],
        "zone_counts": ft["dcrra7_residual_map_zone"].value_counts().to_dict(),
        "separation_diagnostic": separation,
        "top_transition_edges": edges.head(8).to_dict(orient="records"),
        "failure_boundary_event_count": int(len(ledger)),
        "external_component_curve_material": "not available in package",
        "not_claimed": CLAIM_BOUNDARY["not_claimed"],
    }
    (OUT/"manifold_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    trans_summary={
        "interpretation_level":"diagnostic adjacency only; not physical evolutionary path",
        "k_neighbors":7,
        "edge_count":int(len(edges)),
        "top_edges":edges.head(15).to_dict(orient="records"),
        "guardrails":[
            "Do not interpret adjacency as dark-matter taxonomy.",
            "Do not interpret adjacency as galaxy evolution sequence.",
            "Use as prioritization for follow-up, holdout, comparator, and external validation tests."
        ],
    }
    (OUT/"regime_transition_summary.json").write_text(json.dumps(trans_summary, indent=2), encoding="utf-8")
    phase0={
        "integrated_sources":["SN-RRF v2.0.1 selected tables", "DCRRA v1.0.1 selected tables", "A10 Core v0.2.1 directive"],
        "stage":"Phase 0-3",
        "source_galaxy_count": int(len(ft)),
        "claim_boundary_locked": True,
        "external_validation_hold": True,
    }
    (OUT/"phase0_integration_summary.json").write_text(json.dumps(phase0, indent=2), encoding="utf-8")
    make_figures(coords_df, ft, edges)
    decision = """PASS-SN-RRF-DCRRA-v3.0.0-PHASE0-3-INTERNAL-DEEPENING-LOCKED

Decision:
  PASS internal feature-table construction, diagnostic feature-space audit, and provisional regime-transition adjacency construction.

External residual-level validation:
  HOLD. No non-SPARC radius-resolved baryonic component-curve table is bundled or accepted in this package.

Allowed interpretation:
  A claim-bounded SPARC-internal diagnostic feature-space and residual-regime transition audit.

Not claimed:
  No dark-matter exclusion; no Lambda-CDM replacement; no MOND/RAR falsification; no NFW-halo falsification; no new physical law; no external-complete validation.
"""
    (OUT/"V300_PHASE0_3_DECISION.txt").write_text(decision, encoding="utf-8")
    print(decision)

if __name__ == "__main__":
    main()
