# SN-RRF-DCRRA v3.0.0 Phase 0-3 内部統合深化パッケージ

**状態:** 主張境界付きの内部診断深化パッケージ  
**Version:** `3.0.0-phase0-3-internal-deepening`  
**推奨GitHub release tag:** `v3.0.0-phase0-3-internal-deepening`

本パッケージは、SN-RRF v2.0.1 と DCRRA v1.0.1 の選定出力を統合し、Phase 0〜3として以下を実行します。

1. Phase 0: 統合と claim-boundary lock。
2. Phase 1: residual-response feature table の構築。
3. Phase 2: 診断 feature-space / residual-response manifold audit。
4. Phase 3: 暫定的 regime-transition adjacency diagnostics。

## 主張境界

本パッケージは、暗黒物質否定、Lambda-CDM置換、MOND/RAR反証、NFW反証、新物理法則、外部完全残差検証ではありません。

許可される解釈は、SPARC内部のSN-RRF/DCRRA選定出力に基づく、再現可能な診断特徴量表、特徴空間座標監査、暫定的レジーム遷移隣接、failure-boundary ledger の構築に限られます。

## 現在判定

```text
PASS-SN-RRF-DCRRA-v3.0.0-PHASE0-3-INTERNAL-DEEPENING-LOCKED

Decision:
  PASS internal feature-table construction, diagnostic feature-space audit, and provisional regime-transition adjacency construction.

External residual-level validation:
  HOLD. No non-SPARC radius-resolved baryonic component-curve table is bundled or accepted in this package.

Allowed interpretation:
  A claim-bounded SPARC-internal diagnostic feature-space and residual-regime transition audit.

Not claimed:
  No dark-matter exclusion; no Lambda-CDM replacement; no MOND/RAR falsification; no NFW-halo falsification; no new physical law; no external-complete validation.
```

## 再実行

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/run_v300_phase0_to_phase3.py
python scripts/verify_v300_outputs.py
python tools/verify_manifest_excluding_self.py
```

外部 residual-level validation はHOLDです。非SPARCの半径別バリオン成分曲線テーブルは本パッケージ内に含まれておらず、受理もされていません。外部資料が届いた場合は `docs/RESTART_PROTOCOL_IF_EXTERNAL_DATA_ARRIVES.md` の manual material acceptance gate から再開します。
