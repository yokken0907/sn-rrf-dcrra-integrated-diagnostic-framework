# GitHub Repository Metadata

Repository name suggestion: `sn-rrf-dcrra-integrated-diagnostics`

Description:
Claim-bounded SN-RRF/DCRRA internal residual-response feature-space and regime-transition diagnostics for SPARC galaxy rotation-curve residual regimes.

Topics:
`sparc`, `galaxy-rotation-curves`, `residual-diagnostics`, `claim-bounded`, `sn-rrf`, `dcrra`, `a10`

Release tag:
`v3.0.0-phase0-3-internal-deepening`
