# Integrated History Map v3.0.0 Phase 0-3

## Source lineage

1. **SN-RRF v2.0.1**  
   A10/TVC-inspired fixed-kernel residual-response diagnostics were narrowed into a scale-normalized monotone-saturating residual-response family. Fixed-exponent uniqueness is not retained.

2. **DCRRA v1.0.1**  
   The SN-RRF parent result was used as a diagnostic parent to construct a seven-zone residual-regime map across 143 eligible SPARC galaxies.

3. **A10 Core v0.2.1**  
   Theory construction freedom is expanded while strict audit, failure/null preservation, and public claim-boundary gates remain active.

## v3.0.0 Phase 0-3 purpose

This package does not replace the earlier packages. It creates a version-aware integration layer from selected outputs and tests whether the DCRRA zones can be treated as locations in a diagnostic feature-space with provisional transition adjacencies.

## Evidence hierarchy

- SPARC-internal diagnostic structure: tested here.
- Non-SPARC external residual-level validation: not tested here, HOLD.
- Physical dark-sector claim: not made.
