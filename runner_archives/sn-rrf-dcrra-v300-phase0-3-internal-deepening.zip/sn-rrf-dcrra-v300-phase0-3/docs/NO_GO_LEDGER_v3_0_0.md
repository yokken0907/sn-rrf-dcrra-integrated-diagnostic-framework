# No-Go Ledger v3.0.0 Phase 0-3

The following statements are disallowed in README, manuscript, release notes, and public summaries:

- "SN-RRF/DCRRA disproves dark matter."
- "This falsifies NFW, MOND, or RAR."
- "This replaces Lambda-CDM."
- "The feature-space manifold is a physical dark-sector manifold."
- "The kNN transition graph is a physical evolutionary path."
- "LITTLE THINGS or other external datasets fully validate the residual theory." 
- "n = 3.258993 is a universal physical exponent."
- "The external component-curve validation succeeded." 

Allowed replacement language:

- "claim-bounded SPARC-internal diagnostic feature-space audit"
- "provisional residual-regime adjacency diagnostics"
- "failure-boundary and validation-priority ledger"
- "external residual-level validation remains on data-availability HOLD"
