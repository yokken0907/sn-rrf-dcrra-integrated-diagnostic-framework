# Restart Protocol If External Data Arrives

If a data-provider reply supplies a URL, attachment, table, or contact route for non-SPARC radius-resolved baryonic component curves, do not jump directly to full validation.

## Required gate: Stage52 manual source material acceptance

Check:

1. Permission / public availability / citation condition.
2. Galaxy identifiers.
3. Radius column and units.
4. Observed rotation-curve column.
5. Gas component curve.
6. Stellar disk component curve.
7. Bulge component curve, if applicable.
8. Uncertainties, missing values, and conventions.
9. Reproducible local placement under `manual_source_materials/`.
10. Schema acceptance report before any converter run.

## Branch handling

- Accepted data: reopen external component-curve validation branch.
- Ambiguous permission: HOLD.
- Non-shareable material: record data-availability barrier.
- No reply after project decision window: formalize data-availability HOLD.

The internal Phase 0-3 outputs remain SPARC-internal and must not be promoted to external validation.
