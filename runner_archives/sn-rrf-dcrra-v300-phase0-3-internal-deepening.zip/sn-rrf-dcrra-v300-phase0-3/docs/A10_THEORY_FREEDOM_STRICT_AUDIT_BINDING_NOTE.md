# A10 Theory-Freedom / Strict-Audit Binding Note

This project adopts the A10 Core v0.2.1 operating split:

- Theory construction may be bold.
- Speculative hypotheses may enter the protocol.
- Failed hypotheses, NULL results, and HOLD states are retained.
- Verification gates, comparator controls, manifest checks, and public claim boundaries remain strict.
- Only evidence-bounded claims may exit the protocol.

For this SN-RRF/DCRRA branch, residual-response manifold language is allowed only as diagnostic feature-space language. It does not denote a physical dark-sector object.
