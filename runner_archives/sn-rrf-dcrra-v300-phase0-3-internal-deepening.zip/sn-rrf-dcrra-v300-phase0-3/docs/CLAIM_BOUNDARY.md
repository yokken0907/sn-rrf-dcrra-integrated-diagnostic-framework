# Claim Boundary — SN-RRF-DCRRA v3.0.0 Phase 0-3

## Allowed claim

This package constructs a claim-bounded, SPARC-internal diagnostic integration of selected SN-RRF v2.0.1 and DCRRA v1.0.1 outputs. It provides:

- a unified residual-response feature table,
- a diagnostic feature-space coordinate audit,
- provisional kNN-based regime-transition adjacency diagnostics,
- a failure-boundary ledger,
- replayable scripts and verification gates.

## Not claimed

This package does not claim:

- dark-matter exclusion,
- Lambda-CDM replacement,
- MOND/RAR falsification,
- NFW-halo falsification,
- Bullet Cluster explanation,
- dark-matter particle identity,
- Hubble-tension solution,
- universal physical exponent or constant,
- physical dark-sector manifold,
- physical galaxy-evolution sequence,
- external residual-level validation.

## External validation status

External residual-level validation remains on data-availability HOLD. A non-SPARC radius-resolved baryonic component-curve table has not been accepted into this package.
