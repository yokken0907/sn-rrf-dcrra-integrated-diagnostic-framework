No installation is required. This is a browser-only static HTML orientation page.
