# Project Visual Orientation

Open `index.html` in a browser for a compact orientation page.
