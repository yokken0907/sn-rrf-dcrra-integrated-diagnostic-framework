#!/usr/bin/env python3
from pathlib import Path
import hashlib, csv, sys
ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'FILE_MANIFEST.csv'
if not manifest.exists():
    raise SystemExit('FAIL-MANIFEST-VERIFICATION: FILE_MANIFEST.csv not found')
errors=[]; count=0
with manifest.open(newline='', encoding='utf-8') as f:
    reader=csv.DictReader(f)
    for row in reader:
        rel=row['path']
        if rel in {'FILE_MANIFEST.csv','manifest.json','SHA256SUMS.txt','MANIFEST_VERIFY_PASS.txt'}:
            continue
        p=ROOT/rel
        if not p.exists(): errors.append('missing '+rel); continue
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h!=row['sha256']: errors.append('hash mismatch '+rel)
        count+=1
if errors:
    print('FAIL-MANIFEST-VERIFICATION')
    for e in errors: print(e)
    sys.exit(1)
print('PASS-MANIFEST-VERIFICATION')
print(f'verified_files={count}')
