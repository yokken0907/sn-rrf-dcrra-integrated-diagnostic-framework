# Support

This repository is a claim-bounded independent research package. If GitHub Sponsors or other support channels are enabled by the author, support is appreciated but does not change the scientific claim boundary, evidence status, or licensing terms.
