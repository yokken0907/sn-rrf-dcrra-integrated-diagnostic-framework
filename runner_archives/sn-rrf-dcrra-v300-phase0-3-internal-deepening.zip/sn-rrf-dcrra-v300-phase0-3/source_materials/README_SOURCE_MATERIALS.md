# Selected Source Materials

This package includes selected, version-aware source materials only. It does not dump the full prior repositories into a deep archive.

- `sn_rrf_v2_0_1_selected/`: key SN-RRF v2.0.1 tables and manuscript files.
- `dcrra_v1_0_1_selected/`: key DCRRA v1.0.1 regime-map and synthesis files.
- `a10_core_v0_2_1_selected/`: A10 Core theory-freedom / strict-audit directive files.

The selected CSVs are sufficient to reproduce the Phase 0-3 feature-space audit in this package.
