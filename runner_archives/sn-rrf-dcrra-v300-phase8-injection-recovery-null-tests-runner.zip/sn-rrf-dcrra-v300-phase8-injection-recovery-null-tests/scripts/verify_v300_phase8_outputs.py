#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs_v3_0_0_phase8"
required = [
    OUT / "phase8_injection_recovery_results.csv",
    OUT / "phase8_injection_recovery_confusion_matrix.csv",
    OUT / "phase8_recovery_by_injection_type.csv",
    OUT / "phase8_recovery_by_noise_level.csv",
    OUT / "phase8_recovery_by_zone_and_type.csv",
    OUT / "phase8_metric_summary.json",
    OUT / "phase8_decision.json",
    OUT / "V300_PHASE8_DECISION.txt",
    OUT / "PHASE8_REPORT.md",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    raise SystemExit("MISSING_PHASE8_OUTPUTS: " + ", ".join(missing))
summary = json.loads((OUT / "phase8_metric_summary.json").read_text(encoding="utf-8"))
results = pd.read_csv(OUT / "phase8_injection_recovery_results.csv")
by_type = pd.read_csv(OUT / "phase8_recovery_by_injection_type.csv")
expected_cases = summary["feature_rows"] * summary["injection_type_count"] * summary["noise_level_count"]
assert len(results) == expected_cases, (len(results), expected_cases)
assert summary["synthetic_case_count"] == expected_cases
assert summary["feature_rows"] == 143
assert summary["shape_grid_rows"] == 5720
assert summary["galaxy_count"] == 143
assert len(by_type) == summary["injection_type_count"]
assert summary["external_validation"] == "HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE"
assert 0.0 <= summary["overall_recovery_rate"] <= 1.0
assert 0.0 <= summary["balanced_accuracy"] <= 1.0
assert summary["status"] in ["PASS", "MIXED_PASS", "FAIL_OR_NULL"]
print("PASS-V300-PHASE8-OUTPUT-VERIFICATION")
print(f"feature_rows={summary['feature_rows']}")
print(f"shape_grid_rows={summary['shape_grid_rows']}")
print(f"synthetic_case_count={summary['synthetic_case_count']}")
print(f"overall_recovery_rate={summary['overall_recovery_rate']:.6f}")
print(f"balanced_accuracy={summary['balanced_accuracy']:.6f}")
print(f"guard_pass_count={summary['guard_pass_count']}")
print(f"guard_count={summary['guard_count']}")
print(f"interpretation={summary['interpretation']}")
print("external_validation=HOLD")
