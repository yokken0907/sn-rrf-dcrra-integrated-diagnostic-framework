#!/usr/bin/env python3
"""
SN-RRF-DCRRA v3.0.0 Phase 8
Injection-Recovery Null Tests

This script performs an internal synthetic-control audit on the SPARC residual-shape grid
already produced by Phase 4AB. It does NOT perform non-SPARC external validation.

The goal is to test whether a simple frozen diagnostic recovery layer can recover known
synthetic residual-pattern families injected on top of the observed SPARC residual-shape
background. Synthetic PASS/MIXED/FAIL results are claim-bounded protocol evidence only.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Dict, Tuple, List

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs_v3_0_0_phase8"
OUT.mkdir(exist_ok=True)

FEATURE_PATH = ROOT / "outputs_v3_0_0" / "residual_response_feature_table.csv"
GRID_PATH = ROOT / "outputs_v3_0_0_phase4ab" / "phase4b_rotmod_residual_shape_grid_long.csv"
PHASE7_DECISION = ROOT / "outputs_v3_0_0_phase7" / "phase7_decision.json"

SEED = 426803
rng = np.random.default_rng(SEED)

INJECTION_TYPES = [
    "RESPONSE_FAMILY_LIKE",
    "HALO_LIKE",
    "RAR_LIKE",
    "NUISANCE_GRADIENT",
    "PATHOLOGY_OUTLIER",
    "MIXED_RESPONSE_HALO",
]

NOISE_LEVELS = {
    "LOW": 0.025,
    "MEDIUM": 0.060,
    "HIGH": 0.110,
}

BACKGROUND_MIX = {
    "LOW": 0.10,
    "MEDIUM": 0.25,
    "HIGH": 0.40,
}


def zscore(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
    sd = float(np.std(y))
    if sd < 1e-12:
        return y - float(np.mean(y))
    return (y - float(np.mean(y))) / sd


def normalize_unit(y: np.ndarray) -> np.ndarray:
    y = np.asarray(y, dtype=float)
    y = np.nan_to_num(y, nan=0.0, posinf=0.0, neginf=0.0)
    y = y - float(np.mean(y))
    norm = float(np.linalg.norm(y))
    if norm < 1e-12:
        return y
    return y / norm


def saturating(s: np.ndarray, n: float, sc: float) -> np.ndarray:
    x = np.maximum(s, 1e-9) / sc
    return x**n / (1.0 + x**n)


def make_templates(s: np.ndarray) -> Dict[str, np.ndarray]:
    # Templates are intentionally simple diagnostic shape families, not physical models.
    response = saturating(s, n=2.4, sc=0.33)
    halo = np.log1p(4.0 * s) / np.log1p(4.0)
    rar = np.sqrt(np.maximum(s, 0.0))
    nuisance = 2.0 * s - 1.0
    # An archive/pathology-like profile with sign-changing curvature and an outer bump.
    pathology = 0.65 * np.sin(3.0 * np.pi * s) + 1.15 * np.exp(-((s - 0.78) / 0.055) ** 2)
    mixed = 0.55 * response + 0.45 * halo
    raw = {
        "RESPONSE_FAMILY_LIKE": response,
        "HALO_LIKE": halo,
        "RAR_LIKE": rar,
        "NUISANCE_GRADIENT": nuisance,
        "PATHOLOGY_OUTLIER": pathology,
        "MIXED_RESPONSE_HALO": mixed,
    }
    return {k: normalize_unit(v) for k, v in raw.items()}


def fit_template_score(y: np.ndarray, t: np.ndarray) -> Tuple[float, float, float]:
    """Return rss, amplitude, correlation-like cosine score for y ~ a*t + b."""
    y0 = np.asarray(y, dtype=float)
    t0 = np.asarray(t, dtype=float)
    X = np.column_stack([t0, np.ones_like(t0)])
    beta, *_ = np.linalg.lstsq(X, y0, rcond=None)
    pred = X @ beta
    rss = float(np.sum((y0 - pred) ** 2))
    yn = normalize_unit(y0)
    tn = normalize_unit(t0)
    corr = float(np.dot(yn, tn))
    return rss, float(beta[0]), corr


def classify_profile(y: np.ndarray, templates: Dict[str, np.ndarray]) -> Tuple[str, Dict[str, float]]:
    # Frozen recovery rule: choose lowest RSS after amplitude+offset fit across templates.
    rss_by = {}
    corr_by = {}
    for k, t in templates.items():
        rss, amp, corr = fit_template_score(y, t)
        rss_by[k] = rss
        corr_by[k] = corr
    winner = min(rss_by, key=rss_by.get)
    return winner, {f"rss_{k}": v for k, v in rss_by.items()} | {f"corr_{k}": v for k, v in corr_by.items()}


def load_inputs() -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray, Dict[str, np.ndarray]]:
    if not FEATURE_PATH.exists():
        raise FileNotFoundError(f"Missing feature table: {FEATURE_PATH}")
    if not GRID_PATH.exists():
        raise FileNotFoundError(f"Missing Phase4AB residual-shape grid: {GRID_PATH}")
    features = pd.read_csv(FEATURE_PATH)
    grid = pd.read_csv(GRID_PATH)
    s_vals = np.array(sorted(grid["s"].dropna().unique()), dtype=float)
    templates = make_templates(s_vals)
    return features, grid, s_vals, templates


def build_actual_profile_map(grid: pd.DataFrame, s_vals: np.ndarray) -> Dict[str, np.ndarray]:
    profiles = {}
    for gal, sub in grid.groupby("galaxy"):
        sub = sub.sort_values("s")
        # The Phase4B grid should already be on a common s-grid; interpolate defensively.
        y = np.interp(s_vals, sub["s"].to_numpy(float), sub["residual_norm_v2_proxy"].to_numpy(float))
        profiles[str(gal)] = normalize_unit(y)
    return profiles


def run_injection_recovery() -> None:
    features, grid, s_vals, templates = load_inputs()
    profiles = build_actual_profile_map(grid, s_vals)

    feature_galaxies = [str(x) for x in features["galaxy"].tolist()]
    missing = [g for g in feature_galaxies if g not in profiles]
    if missing:
        raise RuntimeError(f"Missing Phase4B profile(s) for {len(missing)} galaxies, first={missing[:10]}")

    rows: List[dict] = []
    for _, fr in features.iterrows():
        galaxy = str(fr["galaxy"])
        zone = str(fr["dcrra7_residual_map_zone"])
        base = profiles[galaxy]
        # Use proxy-derived scale so all galaxies are not identical, but keep labels known.
        failure_score = float(fr.get("phase6_failure_boundary_score", 0.0)) if "phase6_failure_boundary_score" in fr else 0.0
        for inj_type in INJECTION_TYPES:
            tmpl = templates[inj_type]
            for noise_name, sigma in NOISE_LEVELS.items():
                mix = BACKGROUND_MIX[noise_name]
                # Phase8 synthetic residual: injected known pattern plus observed SPARC background.
                noise = rng.normal(0.0, sigma, size=len(s_vals))
                y = (1.0 - mix) * tmpl + mix * base + noise
                y = normalize_unit(y)
                pred, diagnostics = classify_profile(y, templates)
                rows.append({
                    "galaxy": galaxy,
                    "source_zone": zone,
                    "injection_type": inj_type,
                    "noise_level": noise_name,
                    "background_mix": mix,
                    "predicted_type": pred,
                    "recovered": bool(pred == inj_type),
                    "failure_boundary_score_proxy": failure_score,
                    **diagnostics,
                })

    results = pd.DataFrame(rows)
    results.to_csv(OUT / "phase8_injection_recovery_results.csv", index=False)

    confusion = pd.crosstab(results["injection_type"], results["predicted_type"], dropna=False)
    # Ensure complete square-ish matrix for downstream reading.
    confusion = confusion.reindex(index=INJECTION_TYPES, columns=INJECTION_TYPES, fill_value=0)
    confusion.to_csv(OUT / "phase8_injection_recovery_confusion_matrix.csv")

    by_type = results.groupby("injection_type").agg(
        n=("recovered", "size"),
        recall=("recovered", "mean"),
    ).reset_index()
    by_type.to_csv(OUT / "phase8_recovery_by_injection_type.csv", index=False)

    by_noise = results.groupby("noise_level").agg(
        n=("recovered", "size"),
        recovery_rate=("recovered", "mean"),
    ).reset_index()
    by_noise.to_csv(OUT / "phase8_recovery_by_noise_level.csv", index=False)

    by_zone = results.groupby(["source_zone", "injection_type"]).agg(
        n=("recovered", "size"),
        recovery_rate=("recovered", "mean"),
    ).reset_index()
    by_zone.to_csv(OUT / "phase8_recovery_by_zone_and_type.csv", index=False)

    non_response = results[results["injection_type"] != "RESPONSE_FAMILY_LIKE"]
    non_halo = results[results["injection_type"] != "HALO_LIKE"]
    false_response_family_rate = float((non_response["predicted_type"] == "RESPONSE_FAMILY_LIKE").mean())
    false_halo_like_rate = float((non_halo["predicted_type"] == "HALO_LIKE").mean())
    balanced_accuracy = float(by_type["recall"].mean())
    overall_recovery = float(results["recovered"].mean())
    min_class_recall = float(by_type["recall"].min())
    high_noise_recovery = float(by_noise.loc[by_noise["noise_level"] == "HIGH", "recovery_rate"].iloc[0])

    # Conservative decision logic. This is not physical validation; only synthetic protocol behavior.
    guards = {
        "balanced_accuracy_ge_0_70": balanced_accuracy >= 0.70,
        "overall_recovery_ge_0_70": overall_recovery >= 0.70,
        "min_class_recall_ge_0_45": min_class_recall >= 0.45,
        "false_response_family_rate_le_0_20": false_response_family_rate <= 0.20,
        "false_halo_like_rate_le_0_20": false_halo_like_rate <= 0.20,
        "high_noise_recovery_ge_0_50": high_noise_recovery >= 0.50,
    }
    guard_pass_count = int(sum(guards.values()))
    guard_count = len(guards)
    if guard_pass_count == guard_count:
        interpretation = "INJECTION-RECOVERY-SUPPORTED-WITH-SYNTHETIC-SCOPE-BOUNDARY"
        phase8_status = "PASS"
    elif guard_pass_count >= 4:
        interpretation = "INJECTION-RECOVERY-MIXED-SUPPORTED-WITH-FAILURE-BOUNDARIES"
        phase8_status = "MIXED_PASS"
    else:
        interpretation = "INJECTION-RECOVERY-NOT-SUFFICIENTLY-SUPPORTED"
        phase8_status = "FAIL_OR_NULL"

    summary = {
        "phase": "v3.0.0 Phase 8 Injection-Recovery Null Tests",
        "status": phase8_status,
        "interpretation": interpretation,
        "feature_rows": int(len(features)),
        "shape_grid_rows": int(len(grid)),
        "galaxy_count": int(len(feature_galaxies)),
        "injection_type_count": int(len(INJECTION_TYPES)),
        "noise_level_count": int(len(NOISE_LEVELS)),
        "synthetic_case_count": int(len(results)),
        "overall_recovery_rate": overall_recovery,
        "balanced_accuracy": balanced_accuracy,
        "min_class_recall": min_class_recall,
        "high_noise_recovery_rate": high_noise_recovery,
        "false_response_family_rate": false_response_family_rate,
        "false_halo_like_rate": false_halo_like_rate,
        "guard_pass_count": guard_pass_count,
        "guard_count": guard_count,
        "guards": guards,
        "external_validation": "HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE",
        "claim_boundary": "Synthetic internal SPARC protocol control only; not dark-matter exclusion, not NFW/MOND/RAR falsification, not non-SPARC external validation.",
        "random_seed": SEED,
    }
    (OUT / "phase8_metric_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")

    decision = dict(summary)
    decision["decision"] = f"{phase8_status}-PHASE8-INJECTION-RECOVERY-NULL-TESTS-LOCKED-WITH-CLAIM-BOUNDARY"
    (OUT / "phase8_decision.json").write_text(json.dumps(decision, indent=2, ensure_ascii=False), encoding="utf-8")

    # Human-readable reports.
    decision_txt = f"""{decision['decision']}
interpretation: {interpretation}
feature_rows: {len(features)}
shape_grid_rows: {len(grid)}
galaxy_count: {len(feature_galaxies)}
synthetic_case_count: {len(results)}
overall_recovery_rate: {overall_recovery:.6f}
balanced_accuracy: {balanced_accuracy:.6f}
min_class_recall: {min_class_recall:.6f}
high_noise_recovery_rate: {high_noise_recovery:.6f}
false_response_family_rate: {false_response_family_rate:.6f}
false_halo_like_rate: {false_halo_like_rate:.6f}
guards_passed: {guard_pass_count}/{guard_count}
external_validation: HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE
claim_boundary: synthetic internal protocol control only; no physical promotion.
"""
    (OUT / "V300_PHASE8_DECISION.txt").write_text(decision_txt, encoding="utf-8")

    report = f"""# Phase 8 Injection-Recovery Null Tests

## Decision

`{decision['decision']}`

Interpretation: **{interpretation}**

## Scope

Phase 8 is an internal synthetic-control audit. It uses the Phase 4AB SPARC residual-shape grid and injects known diagnostic residual-pattern families into observed SPARC residual-shape backgrounds. It is not non-SPARC external residual-level validation.

## Main metrics

- Feature rows: {len(features)}
- Shape-grid rows: {len(grid)}
- Galaxies: {len(feature_galaxies)}
- Synthetic cases: {len(results)}
- Overall recovery rate: {overall_recovery:.6f}
- Balanced accuracy: {balanced_accuracy:.6f}
- Minimum class recall: {min_class_recall:.6f}
- High-noise recovery rate: {high_noise_recovery:.6f}
- False response-family rate: {false_response_family_rate:.6f}
- False halo-like rate: {false_halo_like_rate:.6f}
- Guards passed: {guard_pass_count}/{guard_count}

## Claim boundary

This audit can support only the statement that the frozen synthetic injection-recovery protocol is able or unable to recover known injected diagnostic shape families under the tested settings. It does not establish a physical dark-sector model, does not exclude dark matter, does not falsify MOND/RAR or NFW, and does not remove the non-SPARC external-data HOLD.
"""
    (OUT / "PHASE8_REPORT.md").write_text(report, encoding="utf-8")

    print("LOCK-PHASE8-INJECTION-RECOVERY-NULL-TESTS-RUN")
    print(f"phase8_status={phase8_status}")
    print(f"feature_rows={len(features)}")
    print(f"shape_grid_rows={len(grid)}")
    print(f"galaxy_count={len(feature_galaxies)}")
    print(f"synthetic_case_count={len(results)}")
    print(f"overall_recovery_rate={overall_recovery:.6f}")
    print(f"balanced_accuracy={balanced_accuracy:.6f}")
    print(f"guard_pass_count={guard_pass_count}")
    print(f"guard_count={guard_count}")
    print(f"interpretation={interpretation}")
    print("external_validation=HOLD")


if __name__ == "__main__":
    run_injection_recovery()
