# SN-RRF-DCRRA v3.0.0 Phase 8 Injection-Recovery Null Tests Runner

This package continues the internal SPARC deepening branch after Phase 7.

Phase 8 performs synthetic injection-recovery null tests on the Phase 4AB SPARC residual-shape grid. It is a synthetic internal protocol-control audit, not non-SPARC external validation.

## Replay

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase8_injection_recovery_null_tests.py
python scripts/verify_v300_phase8_outputs.py
```

Expected output:

```text
PASS-MANIFEST-VERIFICATION
LOCK-PHASE8-INJECTION-RECOVERY-NULL-TESTS-RUN
PASS-V300-PHASE8-OUTPUT-VERIFICATION
```

## Claim boundary

The results are claim-bounded synthetic-control evidence for diagnostic recovery behavior only. They do not establish a physical dark-matter model and do not remove the non-SPARC external-data HOLD.
