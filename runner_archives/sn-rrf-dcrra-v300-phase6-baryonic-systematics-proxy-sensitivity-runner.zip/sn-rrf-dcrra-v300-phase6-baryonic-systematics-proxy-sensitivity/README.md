# SN-RRF-DCRRA v3.0.0 Phase 6 Runner

Phase 6 performs an internal SPARC **Baryonic-Systematics and Proxy Sensitivity Audit**.

It joins the locked Phase 0-3 feature table, Phase 4AB rotmod residual-shape metrics, Phase 5 expanded comparator winners, and Phase 5R overflex-null fairness outputs, then tests whether diagnostic zones, overflex/null absorption, SN-RRF-family survival, and residual-shape metrics are sensitive to baryonic/kinematic/quality proxies.

## Claim boundary

This is not non-SPARC external residual-level validation. It does not claim dark-matter exclusion, MOND/RAR/NFW refutation, Lambda-CDM replacement, or physical model-selection evidence.

## Run

```bash
python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase6_baryonic_systematics_proxy_sensitivity_audit.py
python scripts/verify_v300_phase6_outputs.py
```

Expected:

```text
PASS-PHASE6-BARYONIC-SYSTEMATICS-PROXY-SENSITIVITY-AUDIT-RUN
PASS-V300-PHASE6-OUTPUT-VERIFICATION
```
