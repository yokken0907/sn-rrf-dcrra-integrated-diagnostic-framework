# Phase 6 Scope and Claim Boundary

Allowed:

- Internal SPARC proxy/systematics sensitivity audit.
- Diagnostic association between zones, residual-shape metrics, overflex/null behavior, and proxies.
- Failure-boundary ledger construction.

Not claimed:

- Non-SPARC external residual-level validation.
- Dark-matter exclusion.
- Lambda-CDM replacement.
- MOND/RAR/NFW refutation.
- Physical dark-sector taxonomy.
- Physical model-selection victory.
