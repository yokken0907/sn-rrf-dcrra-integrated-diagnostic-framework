#!/usr/bin/env python3
from pathlib import Path
import csv, hashlib
root=Path('.').resolve(); manifest=root/'FILE_MANIFEST.csv'
if not manifest.exists():
    print('FAIL-MANIFEST-VERIFICATION')
    print('FILE_MANIFEST.csv not found')
    raise SystemExit(1)
errors=[]; verified=0
with manifest.open(newline='',encoding='utf-8') as f:
    for row in csv.DictReader(f):
        rel=row.get('path'); expected=row.get('sha256')
        if not rel or not expected: continue
        if rel in {'FILE_MANIFEST.csv','manifest.json'}: continue
        p=root/rel
        if not p.exists(): errors.append(f'missing: {rel}'); continue
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h!=expected: errors.append(f'sha256 mismatch: {rel}')
        else: verified+=1
if errors:
    print('FAIL-MANIFEST-VERIFICATION')
    for e in errors[:80]: print(e)
    raise SystemExit(1)
print('PASS-MANIFEST-VERIFICATION')
print(f'verified_files={verified}')
