# SN-RRF-DCRRA v3.0.0 Phase 7 Runner

Phase 7 performs a **Frozen Holdout Robustness Audit** on the locked internal SPARC branch.

It uses the Phase 0-6 outputs and evaluates whether zone distribution, response-family fraction, nuisance/pathology fraction, overflex/null absorption, and failure-boundary scores remain stable under pre-frozen holdout subsets.

## Claim boundary

This is not non-SPARC external residual-level validation. It does not claim dark-matter exclusion, MOND/RAR/NFW refutation, Lambda-CDM replacement, physical model-selection evidence, or a new physical law.

## Run

```bash
python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase7_frozen_holdout_robustness_audit.py
python scripts/verify_v300_phase7_outputs.py
```

Expected:

```text
PASS-PHASE7-FROZEN-HOLDOUT-ROBUSTNESS-AUDIT-RUN
PASS-V300-PHASE7-OUTPUT-VERIFICATION
```
