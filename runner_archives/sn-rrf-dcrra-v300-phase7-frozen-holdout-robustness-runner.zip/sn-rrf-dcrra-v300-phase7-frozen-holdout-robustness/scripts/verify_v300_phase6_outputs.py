#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
root=Path('.').resolve(); out=root/'outputs_v3_0_0_phase6'
required=[
 out/'phase6_joined_proxy_sensitivity_table.csv',
 out/'phase6_zone_proxy_summary.csv',
 out/'phase6_proxy_split_summary.csv',
 out/'phase6_proxy_association_scores.csv',
 out/'phase6_high_risk_failure_boundary_candidates.csv',
 out/'phase6_decision.json',
 out/'PHASE6_REPORT.md',
 out/'V300_PHASE6_DECISION.txt',
]
missing=[str(p) for p in required if not p.exists()]
if missing:
    print('FAIL-V300-PHASE6-OUTPUT-VERIFICATION')
    print('missing:', missing)
    raise SystemExit(1)
decision=json.loads((out/'phase6_decision.json').read_text(encoding='utf-8'))
joined=pd.read_csv(out/'phase6_joined_proxy_sensitivity_table.csv')
zone=pd.read_csv(out/'phase6_zone_proxy_summary.csv')
split=pd.read_csv(out/'phase6_proxy_split_summary.csv')
assoc=pd.read_csv(out/'phase6_proxy_association_scores.csv')
cand=pd.read_csv(out/'phase6_high_risk_failure_boundary_candidates.csv')
errors=[]
if decision.get('status')!='PASS-PHASE6-BARYONIC-SYSTEMATICS-PROXY-SENSITIVITY-AUDIT-RUN': errors.append('bad_status')
if joined.shape[0] != 143: errors.append('joined_rows_not_143')
if joined['zone'].nunique() != 7: errors.append('zone_count_not_7')
if zone.shape[0] != 7: errors.append('zone_summary_rows_not_7')
if cand.shape[0] != 143: errors.append('candidate_rows_not_143')
if int(decision.get('proxy_count_tested',0)) < 8: errors.append('too_few_proxies')
if 'HOLD' not in decision.get('external_validation_status',''): errors.append('external_validation_not_hold')
if split.empty: errors.append('split_summary_empty')
if assoc.empty: errors.append('association_scores_empty')
if errors:
    print('FAIL-V300-PHASE6-OUTPUT-VERIFICATION')
    for e in errors: print('error:', e)
    raise SystemExit(1)
print('PASS-V300-PHASE6-OUTPUT-VERIFICATION')
print(f'feature_rows={joined.shape[0]}')
print(f'zone_count={joined["zone"].nunique()}')
print(f'proxy_count_tested={decision.get("proxy_count_tested")}')
print(f'strong_proxy_split_association_count={decision.get("strong_proxy_split_association_count")}')
print(f'interpretation={decision.get("interpretation")}')
print('external_validation=HOLD')
