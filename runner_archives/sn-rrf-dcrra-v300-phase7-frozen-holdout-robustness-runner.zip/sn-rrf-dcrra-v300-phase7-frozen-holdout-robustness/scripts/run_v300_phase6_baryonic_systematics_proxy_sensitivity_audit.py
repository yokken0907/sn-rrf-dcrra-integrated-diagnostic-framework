#!/usr/bin/env python3
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import pandas as pd

RNG = np.random.default_rng(20260527)

PROXY_COLUMNS = [
    'n_points',
    'gas_fraction_proxy',
    'outer_baryon_fraction_proxy',
    'v_outer_kms',
    'v_max_kms',
    'best_n',
    'rrf_rc_over_rlast',
    'rrf_A_over_vouter2',
    'median_err_fraction',
    'roughness_rms_diff',
    'negative_vbar2_proxy_fraction',
    'negative_residual_v2_fraction',
    'kernel_curve_corr',
    'kernel_curve_rmse',
]

BINARY_OUTCOMES = [
    'response_family_zone_flag',
    'nuisance_or_pathology_zone_flag',
    'phase5_overflex_winner_flag',
    'existing_aicc_overflex_flag',
    'existing_bic_overflex_flag',
    'poly_aicc_high_flex_flag',
    'snrrf_existing_aicc_winner_flag',
]

CONTINUOUS_OUTCOMES = [
    'response_family_strength_axis',
    'halo_competitiveness_axis',
    'rar_competitiveness_axis',
    'median_abs_residual_norm',
    'roughness_rms_diff',
    'median_err_fraction',
    'kernel_curve_corr',
    'kernel_curve_rmse',
]


def safe_float(x):
    try:
        v=float(x)
        return v if math.isfinite(v) else np.nan
    except Exception:
        return np.nan


def spearman(x, y):
    dx = pd.Series(x).astype(float)
    dy = pd.Series(y).astype(float)
    mask = dx.notna() & dy.notna()
    if mask.sum() < 8:
        return np.nan
    rx = dx[mask].rank(method='average')
    ry = dy[mask].rank(method='average')
    sx = rx.std(ddof=0); sy = ry.std(ddof=0)
    if sx <= 0 or sy <= 0:
        return np.nan
    return float(np.corrcoef(rx, ry)[0,1])


def permutation_p_binary_split(group_high, outcome, n_perm=1000):
    g = np.asarray(group_high, dtype=bool)
    y = np.asarray(outcome, dtype=float)
    mask = np.isfinite(y)
    g = g[mask]; y = y[mask]
    if len(y) < 12 or g.sum() == 0 or (~g).sum() == 0:
        return np.nan
    obs = abs(float(y[g].mean() - y[~g].mean()))
    cnt = 0
    for _ in range(n_perm):
        yp = RNG.permutation(y)
        stat = abs(float(yp[g].mean() - yp[~g].mean()))
        if stat >= obs - 1e-15:
            cnt += 1
    return float((cnt+1)/(n_perm+1))


def eta_squared_numeric_vs_group(values, groups):
    v = pd.Series(values).astype(float)
    g = pd.Series(groups).astype(str)
    mask = v.notna() & g.notna()
    v = v[mask]; g = g[mask]
    if len(v) < 8:
        return np.nan
    grand = float(v.mean())
    ss_total = float(((v-grand)**2).sum())
    if ss_total <= 0:
        return np.nan
    ss_between = 0.0
    for _, vals in v.groupby(g):
        ss_between += len(vals) * (float(vals.mean()) - grand)**2
    return float(ss_between/ss_total)


def main():
    root = Path('.').resolve()
    out = root / 'outputs_v3_0_0_phase6'
    out.mkdir(exist_ok=True)

    feature_path = root/'outputs_v3_0_0'/'residual_response_feature_table.csv'
    shape_path = root/'outputs_v3_0_0_phase4ab'/'phase4b_rotmod_shape_metrics_by_galaxy.csv'
    phase5_path = root/'outputs_v3_0_0_phase5'/'expanded_comparator_winners.csv'
    phase5r_path = root/'outputs_v3_0_0_phase5r'/'phase5r_fairness_model_selection_by_galaxy.csv'
    for p in [feature_path, shape_path, phase5_path, phase5r_path]:
        if not p.exists():
            raise FileNotFoundError(p)

    feature = pd.read_csv(feature_path)
    shape = pd.read_csv(shape_path)
    phase5 = pd.read_csv(phase5_path)
    phase5r = pd.read_csv(phase5r_path)

    # Avoid duplicate zone suffix collisions; retain feature zone as canonical.
    shape_small = shape.drop(columns=[c for c in ['zone'] if c in shape.columns])
    p5_small = phase5.drop(columns=[c for c in ['zone','rotmod_points','Rlast_kpc'] if c in phase5.columns])
    p5r_small = phase5r.drop(columns=[c for c in ['zone'] if c in phase5r.columns])

    df = feature.merge(shape_small, on='galaxy', how='left')
    df = df.merge(p5_small, on='galaxy', how='left')
    df = df.merge(p5r_small, on='galaxy', how='left')
    df = df.rename(columns={'dcrra7_residual_map_zone':'zone'})

    # Derived flags.
    zone = df['zone'].astype(str)
    df['response_family_zone_flag'] = zone.str.contains('RESPONSE_FAMILY', na=False).astype(int)
    df['nuisance_or_pathology_zone_flag'] = (zone.str.contains('NUISANCE', na=False) | zone.str.contains('PATHOLOGY', na=False)).astype(int)
    df['halo_or_mixed_zone_flag'] = (zone.str.contains('HALO', na=False) | zone.str.contains('MIXED', na=False)).astype(int)
    df['phase5_overflex_winner_flag'] = df.get('phase5_overflex_winner', False).fillna(False).astype(bool).astype(int)
    df['existing_aicc_overflex_flag'] = df.get('winner_existing_aicc_family','').astype(str).eq('OVERFLEX_NULL').astype(int)
    df['existing_bic_overflex_flag'] = df.get('winner_existing_bic_family','').astype(str).eq('OVERFLEX_NULL').astype(int)
    df['poly_aicc_high_flex_flag'] = pd.to_numeric(df.get('winner_poly_degree_aicc_degree', np.nan), errors='coerce').ge(5).astype(int)
    df['snrrf_existing_aicc_winner_flag'] = df.get('winner_existing_aicc','').astype(str).str.contains('SN_RRF', na=False).astype(int)

    # Risk flags and combined failure-boundary score.
    n_points = pd.to_numeric(df['n_points'], errors='coerce')
    med_err = pd.to_numeric(df.get('median_err_fraction', np.nan), errors='coerce')
    rough = pd.to_numeric(df.get('roughness_rms_diff', np.nan), errors='coerce')
    neg_res = pd.to_numeric(df.get('negative_residual_v2_fraction', np.nan), errors='coerce')
    q_npoints = n_points.quantile(0.25)
    q_err = med_err.quantile(0.75)
    q_rough = rough.quantile(0.75)
    q_neg = neg_res.quantile(0.75)
    df['low_point_count_flag'] = n_points.le(q_npoints).astype(int)
    df['high_median_error_flag'] = med_err.ge(q_err).astype(int)
    df['high_roughness_flag'] = rough.ge(q_rough).astype(int)
    df['high_negative_residual_fraction_flag'] = neg_res.ge(q_neg).astype(int)
    df['phase6_failure_boundary_score'] = df[[
        'low_point_count_flag','high_median_error_flag','high_roughness_flag',
        'high_negative_residual_fraction_flag','phase5_overflex_winner_flag',
        'existing_aicc_overflex_flag','nuisance_or_pathology_zone_flag'
    ]].sum(axis=1)
    df.to_csv(out/'phase6_joined_proxy_sensitivity_table.csv', index=False)

    # Zone-level proxy medians/rates.
    zone_rows=[]
    for z, sub in df.groupby('zone'):
        row={'zone':z, 'galaxy_count':int(len(sub))}
        for c in PROXY_COLUMNS:
            if c in sub.columns:
                row[f'median_{c}'] = safe_float(pd.to_numeric(sub[c], errors='coerce').median())
        for b in BINARY_OUTCOMES:
            if b in sub.columns:
                row[f'rate_{b}'] = safe_float(pd.to_numeric(sub[b], errors='coerce').mean())
        row['median_phase6_failure_boundary_score'] = safe_float(sub['phase6_failure_boundary_score'].median())
        zone_rows.append(row)
    zone_summary = pd.DataFrame(zone_rows).sort_values('zone')
    zone_summary.to_csv(out/'phase6_zone_proxy_summary.csv', index=False)

    # Median-split proxy sensitivity summaries.
    split_rows=[]
    for proxy in PROXY_COLUMNS:
        if proxy not in df.columns:
            continue
        x = pd.to_numeric(df[proxy], errors='coerce')
        if x.notna().sum() < 20 or x.nunique(dropna=True) < 4:
            continue
        med = float(x.median())
        high = x.gt(med)
        low = x.le(med)
        for outcome in BINARY_OUTCOMES:
            if outcome not in df.columns:
                continue
            y = pd.to_numeric(df[outcome], errors='coerce')
            mask = x.notna() & y.notna() & (high | low)
            if mask.sum() < 20 or high[mask].sum() < 8 or low[mask].sum() < 8:
                continue
            high_rate = float(y[mask & high].mean())
            low_rate = float(y[mask & low].mean())
            diff = high_rate-low_rate
            p = permutation_p_binary_split(high[mask].values, y[mask].values, n_perm=1000)
            split_rows.append({
                'proxy':proxy,
                'split':'median',
                'threshold':med,
                'outcome':outcome,
                'n_low':int((mask & low).sum()),
                'n_high':int((mask & high).sum()),
                'low_rate':low_rate,
                'high_rate':high_rate,
                'high_minus_low_rate':diff,
                'abs_rate_difference':abs(diff),
                'permutation_p_two_sided':p,
                'strong_association_flag':bool(abs(diff) >= 0.20 and (not math.isnan(p)) and p <= 0.05),
            })
    split_summary = pd.DataFrame(split_rows).sort_values(['strong_association_flag','abs_rate_difference'], ascending=[False,False])
    split_summary.to_csv(out/'phase6_proxy_split_summary.csv', index=False)

    # Association scores across continuous outcomes and zones.
    assoc_rows=[]
    for proxy in PROXY_COLUMNS:
        if proxy not in df.columns:
            continue
        x = pd.to_numeric(df[proxy], errors='coerce')
        if x.notna().sum() < 20 or x.nunique(dropna=True) < 4:
            continue
        assoc_rows.append({
            'proxy':proxy,
            'target':'DCRRA_zone',
            'association_type':'eta_squared_numeric_vs_zone',
            'score':eta_squared_numeric_vs_group(x, df['zone']),
            'n':int(x.notna().sum())
        })
        for target in CONTINUOUS_OUTCOMES:
            if target in df.columns:
                assoc_rows.append({
                    'proxy':proxy,
                    'target':target,
                    'association_type':'spearman_rank_correlation',
                    'score':spearman(x, pd.to_numeric(df[target], errors='coerce')),
                    'n':int((x.notna() & pd.to_numeric(df[target], errors='coerce').notna()).sum())
                })
    assoc = pd.DataFrame(assoc_rows)
    if not assoc.empty:
        assoc['abs_score'] = assoc['score'].abs()
        assoc = assoc.sort_values('abs_score', ascending=False)
    assoc.to_csv(out/'phase6_proxy_association_scores.csv', index=False)

    # Failure-boundary candidates.
    candidates = df.sort_values(['phase6_failure_boundary_score','median_err_fraction','roughness_rms_diff'], ascending=[False,False,False])[[
        'galaxy','zone','n_points','gas_fraction_proxy','outer_baryon_fraction_proxy','v_max_kms',
        'median_err_fraction','roughness_rms_diff','negative_residual_v2_fraction',
        'phase5_overflex_winner_flag','existing_aicc_overflex_flag','poly_aicc_high_flex_flag',
        'nuisance_or_pathology_zone_flag','phase6_failure_boundary_score'
    ]]
    candidates.to_csv(out/'phase6_high_risk_failure_boundary_candidates.csv', index=False)

    strong_count = int(split_summary['strong_association_flag'].sum()) if not split_summary.empty else 0
    top_assoc = assoc.head(10).to_dict(orient='records') if not assoc.empty else []
    interpretation = 'PROXY-SENSITIVITY-STRUCTURE-DETECTED' if strong_count >= 3 else 'PROXY-SENSITIVITY-MIXED-OR-WEAK'
    decision = {
        'status':'PASS-PHASE6-BARYONIC-SYSTEMATICS-PROXY-SENSITIVITY-AUDIT-RUN',
        'version':'3.0.0-phase6-baryonic-systematics-proxy-sensitivity',
        'feature_rows':int(df.shape[0]),
        'zone_count':int(df['zone'].nunique()),
        'proxy_count_tested':int(len([p for p in PROXY_COLUMNS if p in df.columns])),
        'binary_outcome_count_tested':int(len([b for b in BINARY_OUTCOMES if b in df.columns])),
        'strong_proxy_split_association_count':strong_count,
        'top_associations':top_assoc,
        'median_failure_boundary_score':safe_float(df['phase6_failure_boundary_score'].median()),
        'high_risk_candidate_count_score_ge_4':int((df['phase6_failure_boundary_score']>=4).sum()),
        'interpretation':interpretation,
        'external_validation_status':'HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE',
        'claim_boundary': 'Internal SPARC proxy/systematics sensitivity audit only; not external residual-level validation and not physical model selection evidence.'
    }
    (out/'phase6_decision.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False), encoding='utf-8')

    report = []
    report.append('# Phase 6 Baryonic-Systematics and Proxy Sensitivity Audit')
    report.append('')
    report.append('## Decision')
    report.append('PASS-PHASE6-BARYONIC-SYSTEMATICS-PROXY-SENSITIVITY-AUDIT-RUN')
    report.append('')
    report.append('## Claim boundary')
    report.append('This is an internal SPARC proxy/systematics sensitivity audit. It does not constitute non-SPARC external residual-level validation, dark-matter exclusion, MOND/RAR/NFW refutation, or physical model-selection evidence.')
    report.append('')
    report.append('## Summary')
    report.append(f'- feature_rows: {df.shape[0]}')
    report.append(f'- zone_count: {df["zone"].nunique()}')
    report.append(f'- proxy_count_tested: {decision["proxy_count_tested"]}')
    report.append(f'- strong_proxy_split_association_count: {strong_count}')
    report.append(f'- interpretation: {interpretation}')
    report.append('- external_validation: HOLD')
    report.append('')
    report.append('## Main interpretation')
    report.append('Phase 6 tests whether DCRRA zones, overflex-null behavior, SN-RRF-family survival, and residual-shape metrics are sensitive to baryonic, kinematic, and quality/systematics proxies. Positive associations are treated as diagnostic structure and/or failure-boundary information, not causal physical classification.')
    report.append('')
    report.append('## Strong median-split proxy associations')
    if split_summary.empty or strong_count == 0:
        report.append('No strong median-split proxy associations passed the configured effect-size and permutation thresholds.')
    else:
        for _, r in split_summary[split_summary['strong_association_flag']].head(12).iterrows():
            report.append(f'- {r.proxy} -> {r.outcome}: high-low={r.high_minus_low_rate:.3f}, p={r.permutation_p_two_sided:.4f}')
    report.append('')
    report.append('## Failure-boundary use')
    report.append('High-risk rows are ledger candidates, not removals. They identify where low point count, high error, roughness, negative residual fractions, overflex absorption, and nuisance/pathology labels overlap.')
    (out/'PHASE6_REPORT.md').write_text('\n'.join(report)+'\n', encoding='utf-8')

    decision_txt = '\n'.join([
        'PASS-PHASE6-BARYONIC-SYSTEMATICS-PROXY-SENSITIVITY-AUDIT-RUN',
        f'feature_rows={df.shape[0]}',
        f'zone_count={df["zone"].nunique()}',
        f'proxy_count_tested={decision["proxy_count_tested"]}',
        f'strong_proxy_split_association_count={strong_count}',
        f'interpretation={interpretation}',
        'external_validation=HOLD',
        ''
    ])
    (out/'V300_PHASE6_DECISION.txt').write_text(decision_txt, encoding='utf-8')

    print('PASS-PHASE6-BARYONIC-SYSTEMATICS-PROXY-SENSITIVITY-AUDIT-RUN')
    print(f'feature_rows={df.shape[0]}')
    print(f'zone_count={df["zone"].nunique()}')
    print(f'proxy_count_tested={decision["proxy_count_tested"]}')
    print(f'strong_proxy_split_association_count={strong_count}')
    print(f'interpretation={interpretation}')
    print('external_validation=HOLD')

if __name__ == '__main__':
    main()
