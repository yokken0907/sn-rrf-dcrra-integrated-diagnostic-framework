#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
root=Path('.').resolve(); out=root/'outputs_v3_0_0_phase7'
required=[
 out/'phase7_holdout_summary.csv',
 out/'phase7_random_holdout_distribution.csv',
 out/'phase7_zone_leaveout_summary.csv',
 out/'phase7_frozen_holdout_protocol.json',
 out/'phase7_decision.json',
 out/'PHASE7_REPORT.md',
 out/'V300_PHASE7_DECISION.txt',
]
missing=[str(p) for p in required if not p.exists()]
if missing:
    print('FAIL-V300-PHASE7-OUTPUT-VERIFICATION')
    print('missing:', missing)
    raise SystemExit(1)
decision=json.loads((out/'phase7_decision.json').read_text(encoding='utf-8'))
summary=pd.read_csv(out/'phase7_holdout_summary.csv')
random=pd.read_csv(out/'phase7_random_holdout_distribution.csv')
zone=pd.read_csv(out/'phase7_zone_leaveout_summary.csv')
errors=[]
if decision.get('status')!='PASS-PHASE7-FROZEN-HOLDOUT-ROBUSTNESS-AUDIT-RUN': errors.append('bad_status')
if int(decision.get('feature_rows',0)) != 143: errors.append('feature_rows_not_143')
if int(decision.get('zone_count',0)) != 7: errors.append('zone_count_not_7')
if int(decision.get('random_holdout_count',0)) != 10: errors.append('random_holdout_count_not_10')
if int(decision.get('holdout_count_evaluated_excluding_baseline',0)) < 25: errors.append('too_few_holdouts')
if summary.empty: errors.append('summary_empty')
if random.shape[0] != 10: errors.append('random_summary_rows_not_10')
if zone.shape[0] != 7: errors.append('zone_leaveout_rows_not_7')
if 'HOLD' not in decision.get('external_validation_status',''): errors.append('external_validation_not_hold')
if decision.get('interpretation') not in {
    'FROZEN-HOLDOUT-ROBUSTNESS-SUPPORTED-WITH-BOUNDARY-CAUTIONS',
    'RANDOM-HOLDOUT-STABLE-BUT-PROXY-ZONE-STRESS-MIXED',
    'MIXED-HOLDOUT-ROBUSTNESS',
    'HOLDOUT-FRAGILITY-DETECTED',
}: errors.append('bad_interpretation')
if errors:
    print('FAIL-V300-PHASE7-OUTPUT-VERIFICATION')
    for e in errors: print('error:', e)
    raise SystemExit(1)
print('PASS-V300-PHASE7-OUTPUT-VERIFICATION')
print(f'feature_rows={decision.get("feature_rows")}')
print(f'zone_count={decision.get("zone_count")}')
print(f'evaluated_holdout_count={decision.get("holdout_count_evaluated_excluding_baseline")}')
print(f'random_stable_fraction={decision.get("random_stable_fraction"):.6f}')
print(f'stable_holdout_fraction={decision.get("stable_holdout_fraction"):.6f}')
print(f'interpretation={decision.get("interpretation")}')
print('external_validation=HOLD')
