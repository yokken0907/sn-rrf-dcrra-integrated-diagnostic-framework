#!/usr/bin/env python3
from pathlib import Path
import json
import math
import numpy as np
import pandas as pd

ROOT = Path('.').resolve()
OUT = ROOT / 'outputs_v3_0_0_phase7'
OUT.mkdir(exist_ok=True)
EXTERNAL_HOLD = 'HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE'


def _read_csv(path):
    if not path.exists():
        raise FileNotFoundError(str(path))
    return pd.read_csv(path)


def js_divergence(p, q, eps=1e-12):
    p = np.asarray(p, dtype=float) + eps
    q = np.asarray(q, dtype=float) + eps
    p = p / p.sum()
    q = q / q.sum()
    m = 0.5 * (p + q)
    return float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))


def bool_frac(df, col):
    if col not in df.columns or len(df)==0:
        return float('nan')
    return float(pd.to_numeric(df[col], errors='coerce').fillna(0).astype(float).mean())


def median_col(df, col):
    if col not in df.columns or len(df)==0:
        return float('nan')
    s = pd.to_numeric(df[col], errors='coerce')
    if s.dropna().empty:
        return float('nan')
    return float(s.median())


def qval(df, col, q):
    s = pd.to_numeric(df[col], errors='coerce').dropna()
    return float(s.quantile(q)) if len(s) else float('nan')


def safe_shift(a, b):
    if math.isnan(a) or math.isnan(b):
        return float('nan')
    return float(a-b)


def summarize_subset(name, subset, full, full_props, zones, reason):
    n = int(len(subset))
    zone_counts = subset['zone'].value_counts().reindex(zones, fill_value=0)
    zone_props = (zone_counts / max(n, 1)).values
    full_vec = np.array([full_props[z] for z in zones], dtype=float)
    js = js_divergence(zone_props, full_vec) if n else float('nan')
    zone_count = int((zone_counts > 0).sum())
    missing_zone_count = int((zone_counts == 0).sum())

    response_frac = bool_frac(subset, 'response_family_zone_flag')
    nuisance_frac = bool_frac(subset, 'nuisance_or_pathology_zone_flag')
    overflex_aic = bool_frac(subset, 'phase5_overflex_winner_flag')
    overflex_aicc = bool_frac(subset, 'existing_aicc_overflex_flag')
    overflex_bic = bool_frac(subset, 'existing_bic_overflex_flag')
    poly_highflex = bool_frac(subset, 'poly_aicc_high_flex_flag')
    snrrf_aicc = bool_frac(subset, 'snrrf_existing_aicc_winner_flag')
    high_failure = float((pd.to_numeric(subset.get('phase6_failure_boundary_score', pd.Series([], dtype=float)), errors='coerce').fillna(0) >= 4).mean()) if n else float('nan')
    median_failure = median_col(subset, 'phase6_failure_boundary_score')

    shifts = {
        'response_family_shift_abs': abs(safe_shift(response_frac, full_props['response_family_zone_fraction'])),
        'nuisance_pathology_shift_abs': abs(safe_shift(nuisance_frac, full_props['nuisance_pathology_fraction'])),
        'aicc_overflex_shift_abs': abs(safe_shift(overflex_aicc, full_props['existing_aicc_overflex_fraction'])),
        'high_failure_shift_abs': abs(safe_shift(high_failure, full_props['high_failure_score_ge4_fraction'])),
    }
    pass_flags = {
        'pass_min_sample_40': n >= 40,
        'pass_zone_count_ge5': zone_count >= 5,
        'pass_missing_zones_le2': missing_zone_count <= 2,
        'pass_js_le_0p25': (not math.isnan(js)) and js <= 0.25,
        'pass_response_shift_le_0p20': (not math.isnan(shifts['response_family_shift_abs'])) and shifts['response_family_shift_abs'] <= 0.20,
        'pass_aicc_overflex_shift_le_0p25': (not math.isnan(shifts['aicc_overflex_shift_abs'])) and shifts['aicc_overflex_shift_abs'] <= 0.25,
        'pass_high_failure_shift_le_0p25': (not math.isnan(shifts['high_failure_shift_abs'])) and shifts['high_failure_shift_abs'] <= 0.25,
    }
    pass_count = int(sum(pass_flags.values()))
    stable = pass_count >= 6
    mixed = (pass_count >= 4) and not stable
    fragile = pass_count < 4
    row = {
        'holdout_name': name,
        'holdout_reason': reason,
        'sample_count': n,
        'zone_count': zone_count,
        'missing_zone_count': missing_zone_count,
        'zone_js_divergence': js,
        'response_family_zone_fraction': response_frac,
        'nuisance_pathology_zone_fraction': nuisance_frac,
        'phase5_overflex_winner_fraction': overflex_aic,
        'existing_aicc_overflex_fraction': overflex_aicc,
        'existing_bic_overflex_fraction': overflex_bic,
        'poly_aicc_high_flex_fraction': poly_highflex,
        'snrrf_existing_aicc_winner_fraction': snrrf_aicc,
        'median_failure_boundary_score': median_failure,
        'high_failure_score_ge4_fraction': high_failure,
        'median_n_points': median_col(subset, 'n_points'),
        'median_v_max_kms': median_col(subset, 'v_max_kms'),
        'median_v_outer_kms': median_col(subset, 'v_outer_kms'),
        'median_gas_fraction_proxy': median_col(subset, 'gas_fraction_proxy'),
        'median_outer_baryon_fraction_proxy': median_col(subset, 'outer_baryon_fraction_proxy'),
        'median_kernel_curve_rmse': median_col(subset, 'kernel_curve_rmse'),
        'median_phase4b_shape_pc1': median_col(subset, 'phase4b_shape_pc1'),
        'median_phase4b_shape_pc2': median_col(subset, 'phase4b_shape_pc2'),
        **shifts,
        **{k:int(v) for k,v in pass_flags.items()},
        'stability_pass_count': pass_count,
        'holdout_stability_label': 'STABLE' if stable else ('MIXED' if mixed else 'FRAGILE'),
    }
    return row


def main():
    phase6 = _read_csv(ROOT/'outputs_v3_0_0_phase6'/'phase6_joined_proxy_sensitivity_table.csv')
    shape = _read_csv(ROOT/'outputs_v3_0_0_phase4ab'/'phase4b_shape_pca_coordinates.csv')
    manifold = _read_csv(ROOT/'outputs_v3_0_0'/'manifold_coordinates.csv')

    df = phase6.copy()
    if 'phase4b_shape_pc1' not in df.columns:
        df = df.merge(shape[['galaxy','phase4b_shape_pc1','phase4b_shape_pc2']], on='galaxy', how='left')
    if 'pc1' not in df.columns:
        df = df.merge(manifold[['galaxy','pc1','pc2','pc3']], on='galaxy', how='left')

    # Coerce flags to ints.
    for c in ['response_family_zone_flag','nuisance_or_pathology_zone_flag','phase5_overflex_winner_flag','existing_aicc_overflex_flag','existing_bic_overflex_flag','poly_aicc_high_flex_flag','snrrf_existing_aicc_winner_flag']:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors='coerce').fillna(0).astype(int)

    zones = sorted(df['zone'].dropna().unique().tolist())
    full_zone_counts = df['zone'].value_counts().reindex(zones, fill_value=0)
    full_zone_props = (full_zone_counts / len(df)).to_dict()

    full_props = dict(full_zone_props)
    full_props.update({
        'response_family_zone_fraction': bool_frac(df, 'response_family_zone_flag'),
        'nuisance_pathology_fraction': bool_frac(df, 'nuisance_or_pathology_zone_flag'),
        'existing_aicc_overflex_fraction': bool_frac(df, 'existing_aicc_overflex_flag'),
        'high_failure_score_ge4_fraction': float((pd.to_numeric(df['phase6_failure_boundary_score'], errors='coerce').fillna(0) >= 4).mean()),
    })

    thresholds = {
        'n_points_q25': qval(df,'n_points',0.25), 'n_points_q50': qval(df,'n_points',0.50), 'n_points_q75': qval(df,'n_points',0.75),
        'gas_fraction_q25': qval(df,'gas_fraction_proxy',0.25), 'gas_fraction_q75': qval(df,'gas_fraction_proxy',0.75),
        'outer_baryon_fraction_q25': qval(df,'outer_baryon_fraction_proxy',0.25), 'outer_baryon_fraction_q75': qval(df,'outer_baryon_fraction_proxy',0.75),
        'v_max_q25': qval(df,'v_max_kms',0.25), 'v_max_q75': qval(df,'v_max_kms',0.75),
        'v_outer_q25': qval(df,'v_outer_kms',0.25), 'v_outer_q75': qval(df,'v_outer_kms',0.75),
        'median_err_fraction_q75': qval(df,'median_err_fraction',0.75),
        'roughness_rms_diff_q75': qval(df,'roughness_rms_diff',0.75),
        'kernel_curve_rmse_q75': qval(df,'kernel_curve_rmse',0.75),
        'failure_boundary_high_score_threshold': 4.0,
    }

    holdouts = []
    # Baseline row for reference only.
    holdouts.append(('baseline_full_sample', df, 'full eligible 143-galaxy internal SPARC sample'))

    # Random 80% retained holdouts with frozen seeds.
    rng = np.random.default_rng(7307)
    galaxies = df['galaxy'].to_numpy()
    for i in range(10):
        selected = rng.choice(galaxies, size=int(round(0.80*len(galaxies))), replace=False)
        holdouts.append((f'random_keep80_seed_{i:02d}', df[df['galaxy'].isin(selected)].copy(), 'frozen random 80% retained subset'))

    # Proxy/quality exclusions using frozen baseline thresholds.
    holdouts.extend([
        ('exclude_low_point_count_q25', df[df['n_points'] >= thresholds['n_points_q25']], 'exclude bottom quartile of rotation-curve point count'),
        ('exclude_high_point_count_q75', df[df['n_points'] <= thresholds['n_points_q75']], 'exclude top quartile of rotation-curve point count'),
        ('exclude_high_error_q75', df[df['median_err_fraction'] <= thresholds['median_err_fraction_q75']], 'exclude top quartile median error fraction'),
        ('exclude_high_roughness_q75', df[df['roughness_rms_diff'] <= thresholds['roughness_rms_diff_q75']], 'exclude top quartile roughness'),
        ('exclude_high_kernel_rmse_q75', df[df['kernel_curve_rmse'] <= thresholds['kernel_curve_rmse_q75']], 'exclude top quartile kernel residual shape RMSE'),
        ('exclude_high_failure_score_ge4', df[pd.to_numeric(df['phase6_failure_boundary_score'], errors='coerce').fillna(0) < 4], 'exclude Phase 6 high-risk failure-boundary candidates'),
        ('high_quality_low_failure_only', df[(pd.to_numeric(df['phase6_failure_boundary_score'], errors='coerce').fillna(0) <= 2) & (df['nuisance_or_pathology_zone_flag'] == 0)], 'retain low failure-boundary score and non-nuisance/pathology galaxies'),
        ('exclude_gas_poor_q25', df[df['gas_fraction_proxy'] >= thresholds['gas_fraction_q25']], 'exclude bottom quartile gas-fraction proxy'),
        ('exclude_gas_rich_q75', df[df['gas_fraction_proxy'] <= thresholds['gas_fraction_q75']], 'exclude top quartile gas-fraction proxy'),
        ('exclude_outer_baryon_low_q25', df[df['outer_baryon_fraction_proxy'] >= thresholds['outer_baryon_fraction_q25']], 'exclude bottom quartile outer baryon-fraction proxy'),
        ('exclude_outer_baryon_high_q75', df[df['outer_baryon_fraction_proxy'] <= thresholds['outer_baryon_fraction_q75']], 'exclude top quartile outer baryon-fraction proxy'),
        ('exclude_low_vmax_q25', df[df['v_max_kms'] >= thresholds['v_max_q25']], 'exclude bottom quartile Vmax'),
        ('exclude_high_vmax_q75', df[df['v_max_kms'] <= thresholds['v_max_q75']], 'exclude top quartile Vmax'),
        ('exclude_low_vouter_q25', df[df['v_outer_kms'] >= thresholds['v_outer_q25']], 'exclude bottom quartile Vouter'),
        ('exclude_high_vouter_q75', df[df['v_outer_kms'] <= thresholds['v_outer_q75']], 'exclude top quartile Vouter'),
    ])

    # Leave-one-zone-out stress tests.
    for z in zones:
        holdouts.append((f'leaveout_zone__{z}', df[df['zone'] != z].copy(), f'leave out zone {z}'))

    rows = [summarize_subset(name, sub.copy(), df, full_props, zones, reason) for name, sub, reason in holdouts]
    summary = pd.DataFrame(rows)

    baseline = summary[summary['holdout_name']=='baseline_full_sample'].iloc[0].to_dict()
    eval_summary = summary[summary['holdout_name']!='baseline_full_sample'].copy()
    random_summary = eval_summary[eval_summary['holdout_name'].str.startswith('random_keep80')].copy()
    zone_leaveout = eval_summary[eval_summary['holdout_name'].str.startswith('leaveout_zone__')].copy()

    stable_fraction = float((eval_summary['holdout_stability_label']=='STABLE').mean())
    mixed_fraction = float((eval_summary['holdout_stability_label']=='MIXED').mean())
    fragile_fraction = float((eval_summary['holdout_stability_label']=='FRAGILE').mean())
    random_stable_fraction = float((random_summary['holdout_stability_label']=='STABLE').mean()) if len(random_summary) else float('nan')
    zone_leaveout_stable_fraction = float((zone_leaveout['holdout_stability_label']=='STABLE').mean()) if len(zone_leaveout) else float('nan')

    # Interpretation rule: random stable is primary; proxy and zone stress can be mixed.
    if random_stable_fraction >= 0.8 and stable_fraction >= 0.6:
        interpretation = 'FROZEN-HOLDOUT-ROBUSTNESS-SUPPORTED-WITH-BOUNDARY-CAUTIONS'
    elif random_stable_fraction >= 0.8:
        interpretation = 'RANDOM-HOLDOUT-STABLE-BUT-PROXY-ZONE-STRESS-MIXED'
    elif random_stable_fraction >= 0.5:
        interpretation = 'MIXED-HOLDOUT-ROBUSTNESS'
    else:
        interpretation = 'HOLDOUT-FRAGILITY-DETECTED'

    decision = {
        'status': 'PASS-PHASE7-FROZEN-HOLDOUT-ROBUSTNESS-AUDIT-RUN',
        'phase': 'Phase 7',
        'feature_rows': int(len(df)),
        'zone_count': int(len(zones)),
        'holdout_count_total_including_baseline': int(len(summary)),
        'holdout_count_evaluated_excluding_baseline': int(len(eval_summary)),
        'random_holdout_count': int(len(random_summary)),
        'zone_leaveout_count': int(len(zone_leaveout)),
        'stable_holdout_fraction': stable_fraction,
        'mixed_holdout_fraction': mixed_fraction,
        'fragile_holdout_fraction': fragile_fraction,
        'random_stable_fraction': random_stable_fraction,
        'zone_leaveout_stable_fraction': zone_leaveout_stable_fraction,
        'median_zone_js_divergence_evaluated': float(eval_summary['zone_js_divergence'].median()),
        'max_zone_js_divergence_evaluated': float(eval_summary['zone_js_divergence'].max()),
        'baseline_response_family_zone_fraction': float(baseline['response_family_zone_fraction']),
        'baseline_existing_aicc_overflex_fraction': float(baseline['existing_aicc_overflex_fraction']),
        'baseline_high_failure_score_ge4_fraction': float(baseline['high_failure_score_ge4_fraction']),
        'interpretation': interpretation,
        'external_validation_status': EXTERNAL_HOLD,
        'claim_boundary': 'Internal SPARC frozen holdout robustness audit only; not non-SPARC external residual-level validation and not physical model selection.',
    }

    summary.to_csv(OUT/'phase7_holdout_summary.csv', index=False)
    random_summary.to_csv(OUT/'phase7_random_holdout_distribution.csv', index=False)
    zone_leaveout.to_csv(OUT/'phase7_zone_leaveout_summary.csv', index=False)
    (OUT/'phase7_frozen_holdout_protocol.json').write_text(json.dumps({'thresholds':thresholds, 'zones':zones, 'pass_criteria':{
        'min_sample':40, 'zone_count_ge':5, 'missing_zones_le':2, 'zone_js_le':0.25, 'response_shift_le':0.20, 'aicc_overflex_shift_le':0.25, 'high_failure_shift_le':0.25
    }}, indent=2), encoding='utf-8')
    (OUT/'phase7_decision.json').write_text(json.dumps(decision, indent=2), encoding='utf-8')

    report = f"""# Phase 7 Frozen Holdout Robustness Audit Report

## Decision

`{decision['status']}`

Interpretation: `{interpretation}`

## Scope

This is an internal SPARC holdout robustness audit. It is not non-SPARC external residual-level validation and does not promote SN-RRF/DCRRA into a physical dark-matter model, dark-matter exclusion claim, MOND/RAR/NFW refutation, or Lambda-CDM replacement.

## Key counts

- Feature rows: {decision['feature_rows']}
- Zones: {decision['zone_count']}
- Evaluated holdouts excluding baseline: {decision['holdout_count_evaluated_excluding_baseline']}
- Random 80% holdouts: {decision['random_holdout_count']}
- Leave-one-zone-out holdouts: {decision['zone_leaveout_count']}

## Robustness summary

- Stable holdout fraction: {stable_fraction:.6f}
- Mixed holdout fraction: {mixed_fraction:.6f}
- Fragile holdout fraction: {fragile_fraction:.6f}
- Random stable fraction: {random_stable_fraction:.6f}
- Zone-leaveout stable fraction: {zone_leaveout_stable_fraction:.6f}
- Median evaluated zone JS divergence: {decision['median_zone_js_divergence_evaluated']:.6f}
- Maximum evaluated zone JS divergence: {decision['max_zone_js_divergence_evaluated']:.6f}

## Baseline internal fractions

- Response-family zone fraction: {decision['baseline_response_family_zone_fraction']:.6f}
- AICc overflex fraction: {decision['baseline_existing_aicc_overflex_fraction']:.6f}
- High failure-boundary score >= 4 fraction: {decision['baseline_high_failure_score_ge4_fraction']:.6f}

## Safe interpretation

The audit tests whether the internal Phase 0-6 diagnostic summaries survive frozen data-split and proxy/quality stress conditions. A stable or mixed result supports internal robustness of the diagnostic framework within SPARC only. It does not address the missing non-SPARC external component-curve validation branch.

External validation status: `{EXTERNAL_HOLD}`
"""
    (OUT/'PHASE7_REPORT.md').write_text(report, encoding='utf-8')
    (OUT/'V300_PHASE7_DECISION.txt').write_text(f"""{decision['status']}
interpretation: {interpretation}
feature_rows: {decision['feature_rows']}
zone_count: {decision['zone_count']}
evaluated_holdout_count: {decision['holdout_count_evaluated_excluding_baseline']}
random_stable_fraction: {random_stable_fraction:.6f}
stable_holdout_fraction: {stable_fraction:.6f}
external_validation: HOLD
""", encoding='utf-8')

    print(decision['status'])
    print(f"feature_rows={decision['feature_rows']}")
    print(f"zone_count={decision['zone_count']}")
    print(f"evaluated_holdout_count={decision['holdout_count_evaluated_excluding_baseline']}")
    print(f"random_stable_fraction={random_stable_fraction:.6f}")
    print(f"stable_holdout_fraction={stable_fraction:.6f}")
    print(f"interpretation={interpretation}")
    print('external_validation=HOLD')


if __name__ == '__main__':
    main()
