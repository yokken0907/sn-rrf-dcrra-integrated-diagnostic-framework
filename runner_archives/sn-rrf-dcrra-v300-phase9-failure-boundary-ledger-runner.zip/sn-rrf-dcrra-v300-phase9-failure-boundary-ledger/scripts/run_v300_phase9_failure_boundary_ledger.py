from pathlib import Path
import json
import pandas as pd
import numpy as np

OUTPUT_DIR = Path('outputs_v3_0_0_phase9')
OUTPUT_DIR.mkdir(exist_ok=True)

def find_dir(name: str) -> Path:
    candidates = [Path(name), Path('input_snapshots') / name, Path('..') / name, Path('..') / 'input_snapshots' / name]
    for c in candidates:
        if c.exists() and c.is_dir():
            return c
    raise FileNotFoundError(f'Could not locate required input directory: {name}')

def read_json(dir_name: str, file_name: str) -> dict:
    with (find_dir(dir_name) / file_name).open('r', encoding='utf-8') as f:
        return json.load(f)

def read_csv(dir_name: str, file_name: str) -> pd.DataFrame:
    return pd.read_csv(find_dir(dir_name) / file_name)

def val(x, nd=6):
    if isinstance(x, (int, np.integer)):
        return str(int(x))
    if isinstance(x, (float, np.floating)):
        return f'{float(x):.{nd}f}'
    return str(x)

feature = read_csv('outputs_v3_0_0', 'residual_response_feature_table.csv')
p4 = read_json('outputs_v3_0_0_phase4ab', 'phase4ab_decision.json')
p5 = read_json('outputs_v3_0_0_phase5', 'phase5_decision.json')
p5r = read_json('outputs_v3_0_0_phase5r', 'phase5r_decision.json')
p6 = read_json('outputs_v3_0_0_phase6', 'phase6_decision.json')
p7 = read_json('outputs_v3_0_0_phase7', 'phase7_decision.json')
p8 = read_json('outputs_v3_0_0_phase8', 'phase8_decision.json')
p8r = read_json('outputs_v3_0_0_phase8r', 'phase8r_decision.json')
p8_type = read_csv('outputs_v3_0_0_phase8', 'phase8_recovery_by_injection_type.csv')
p8_noise = read_csv('outputs_v3_0_0_phase8', 'phase8_recovery_by_noise_level.csv')
p8r_pair = read_csv('outputs_v3_0_0_phase8r', 'phase8r_pairwise_confusion_offdiagonal.csv')

ledger = []
def add(boundary_id, source_phase, category, severity, status, evidence_metric, evidence_value, threshold_or_context, interpretation, public_claim_effect, recommended_action):
    ledger.append({
        'boundary_id': boundary_id,
        'source_phase': source_phase,
        'category': category,
        'severity': severity,
        'status': status,
        'evidence_metric': evidence_metric,
        'evidence_value': evidence_value,
        'threshold_or_context': threshold_or_context,
        'interpretation': interpretation,
        'public_claim_effect': public_claim_effect,
        'recommended_action': recommended_action,
    })

add('FB-001','External branch','data_availability','CRITICAL','HOLD','external_validation_status','HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE','non-SPARC radius-resolved component-curve table unavailable','Full external residual-level validation remains unavailable.','No external-validation claim.','Keep external branch reopenable only if usable non-SPARC component curves arrive.')
add('FB-002','Phase 4AB','shape_zone_alignment','MEDIUM','CAUTION','phase4b_adjusted_rand_index',val(p4.get('phase4b_adjusted_rand_index')),'low ARI means shape clusters do not strongly reproduce seven-zone map','DCRRA zones are not simple residual-shape clusters.','Do not describe zones as direct shape-template classes.','Use shape audit as one diagnostic layer, not the full classification basis.')
pc = p4.get('phase4b_pca_explained_variance_ratio', [])
pc12 = sum(pc[:2]) if isinstance(pc, list) else None
add('FB-003','Phase 4AB','shape_low_dimensionality','LOW','INFORMATIVE','phase4b_PC1_PC2_explained_variance_sum',val(pc12) if pc12 is not None else 'NA','low-dimensional residual-shape structure exists but does not equal zone taxonomy','Residual-shape structure is real enough to audit, but not sufficient as taxonomy.','Permit internal diagnostic shape-language only.','Carry into synthesis as diagnostic support with taxonomy caution.')
add('FB-004','Phase 5','overflex_null_absorption','HIGH','CAUTION','AIC_overflex_winner_fraction',val(p5.get('overflex_winner_fraction')),'Phase 5 expanded comparator audit under AIC','Over-flexible null absorbs residual structure in many galaxies.','No physical model-selection winner claim.','Require fairness/complexity-penalty reporting whenever comparator wins are discussed.')
existing = p5r.get('existing_set_overflex_fractions', {})
add('FB-005','Phase 5R','complexity_penalty_sensitivity','HIGH','CAUTION','AIC/AICc/BIC overflex fractions',json.dumps(existing, sort_keys=True),'overflex dominance changes under AICc/BIC','Overflex dominance is penalty-sensitive; AIC-only conclusions are unsafe.','Do not treat AIC comparator dominance as physical evidence.','Report AIC, AICc, and BIC sensitivity together.')
add('FB-006','Phase 6','proxy_systematics_sensitivity','HIGH','SUPPORTED_BOUNDARY','strong_proxy_split_association_count',val(p6.get('strong_proxy_split_association_count')),f"proxy_count_tested={p6.get('proxy_count_tested')}",'Comparator and regime behavior is associated with observational / baryonic proxies.','Avoid causal physical classification language.','Stratify by n_points, velocity scale, and residual-shape error in downstream summaries.')
add('FB-007','Phase 6','high_risk_candidates','MEDIUM','CAUTION','high_risk_candidate_count_score_ge_4',val(p6.get('high_risk_candidate_count_score_ge_4')),'failure-boundary score >= 4','A nontrivial subset carries elevated failure-boundary risk.','Do not hide high-risk cases when reporting population-level structure.','Preserve high-risk ledgers and examples in repository.')
add('FB-008','Phase 7','holdout_robustness_boundary','LOW','SUPPORTED_WITH_CAUTION','stable_holdout_fraction',val(p7.get('stable_holdout_fraction')),f"evaluated_holdout_count={p7.get('holdout_count_evaluated_excluding_baseline')}",'Frozen holdouts are stable, but boundary cautions remain for restricted subsets and leaveout shifts.','Internal robustness may be stated only within SPARC protocol.','Keep holdout qualifier in abstract/conclusion.')
add('FB-009','Phase 8','injection_recovery_limitation','CRITICAL','FAIL_OR_NULL_LOCKED','balanced_accuracy',val(p8.get('balanced_accuracy')),f"guards={p8.get('guard_pass_count')}/{p8.get('guard_count')}",'Synthetic injection-recovery is not sufficiently supported by frozen rules.','Do not present DCRRA zones as strong classifiers.','Treat injection-recovery failure as a central no-go boundary.')

# Weakest synthetic type
cols_lower = {c.lower(): c for c in p8_type.columns}
type_col = cols_lower.get('injection_type') or cols_lower.get('true_type') or p8_type.columns[0]
recall_cols = [c for c in p8_type.columns if 'recall' in c.lower() or 'recovery' in c.lower()]
if recall_cols:
    rc = recall_cols[0]
    minrow = p8_type.sort_values(rc).iloc[0]
    add('FB-010','Phase 8','weak_injection_class','HIGH','CAUTION',f'min_recovery_by_type:{minrow[type_col]}',val(minrow[rc]),'weakest synthetic class under frozen recovery',f"{minrow[type_col]} is weakly recovered under the tested protocol.",'Do not infer stable physical-like template separability.','Carry weak-class details into failure-boundary examples.')

noise_name_col = 'noise_level' if 'noise_level' in p8_noise.columns else p8_noise.columns[0]
noise_recall_cols = [c for c in p8_noise.columns if 'recovery' in c.lower() or 'accuracy' in c.lower()]
if noise_recall_cols:
    nr = noise_recall_cols[0]
    high = p8_noise[p8_noise[noise_name_col].astype(str).str.upper().str.contains('HIGH')]
    if not high.empty:
        add('FB-011','Phase 8','noise_sensitivity','HIGH','CAUTION','high_noise_recovery_rate',val(float(high.iloc[0][nr])),'synthetic high-noise condition','Recovery degrades materially under high-noise injections.','Avoid general stable-classifier claims.','Report noise-stratified recovery in any synthesis paper.')

add('FB-012','Phase 8R','separability_limitation','CRITICAL','FAIL_OR_NULL_LOCKED','best_full_coverage_balanced_accuracy',val(p8r.get('best_full_coverage_operational_balanced_accuracy')),f"physical_like_mean_recall={val(p8r.get('physical_like_mean_recall'))}; pathology_nuisance_mean_recall={val(p8r.get('pathology_nuisance_mean_recall'))}",'Separability limitation persists after diagnostic repair audit.','DCRRA is not a physical-category classifier.','Lock separability limitation in claim boundary and future manuscript reader guidance.')
add('FB-013','Phase 8R','top_confusion_pair','HIGH','CAUTION','top_offdiagonal_pair',f"{p8r.get('top_offdiagonal_pair')} count={p8r.get('top_offdiagonal_count')} fraction={val(p8r.get('top_offdiagonal_fraction'))}",'largest off-diagonal confusion in synthetic separability audit','Physical-like / comparator-like adjacent types remain confusable.','Do not use synthetic results to promote response/halo/RAR/mixed labels into physical classes.','Use pairwise confusion table as no-go evidence.')
if {'true_type','predicted_type','count'}.issubset(p8r_pair.columns):
    rm = p8r_pair[((p8r_pair.true_type=='RESPONSE_FAMILY_LIKE') & (p8r_pair.predicted_type=='MIXED_RESPONSE_HALO')) | ((p8r_pair.true_type=='MIXED_RESPONSE_HALO') & (p8r_pair.predicted_type=='RESPONSE_FAMILY_LIKE'))]
    if not rm.empty:
        add('FB-014','Phase 8R','response_mixed_confusion','HIGH','CAUTION','response_mixed_offdiagonal_total',str(int(rm['count'].sum())),'bidirectional RESPONSE_FAMILY_LIKE / MIXED_RESPONSE_HALO confusion','Response-like and mixed-like classes are not cleanly separable by current rules.','Avoid strong response-vs-mixed categorical claims.','Keep mixed zone as a diagnostic ambiguity class.')
try:
    old = read_csv('outputs_v3_0_0', 'failure_boundary_ledger.csv')
    add('FB-015','Phase 0-3','preexisting_failure_boundary_ledger','LOW','CARRIED_FORWARD','prior_failure_boundary_rows',str(len(old)),'legacy / Phase0-3 failure-boundary ledger carried forward','Earlier boundary notes remain part of v3.0.0 ledger.','Do not overwrite earlier caveats when integrating new phases.','Retain version-aware provenance.')
except Exception:
    pass

ledger_df = pd.DataFrame(ledger)
ledger_df.to_csv(OUTPUT_DIR / 'phase9_failure_boundary_ledger.csv', index=False)

priority_rows = [
    {'priority_rank':1,'priority':'Obtain non-SPARC radius-resolved component-curve table','reason':'External validation remains HOLD.','unblocks':'external residual-level validation branch','current_status':'HOLD'},
    {'priority_rank':2,'priority':'Comparator fairness with complexity-penalty reporting','reason':'Overflex-null dominance is AIC/AICc/BIC-sensitive.','unblocks':'safe comparator discussion','current_status':'INTERNAL_REQUIRED'},
    {'priority_rank':3,'priority':'Synthetic separability improvement or explicit no-go lock','reason':'Phase 8/8R remain FAIL_OR_NULL.','unblocks':'classifier-language boundary','current_status':'FAILURE_BOUNDARY'},
    {'priority_rank':4,'priority':'Proxy-stratified reporting','reason':'Phase 6 detects proxy/systematics structure.','unblocks':'less misleading population summaries','current_status':'REQUIRED_FOR_MANUSCRIPT'},
    {'priority_rank':5,'priority':'High-noise and low-point-count caution','reason':'Recovery and comparator behavior degrade by noise / quality proxies.','unblocks':'failure-boundary examples','current_status':'REQUIRED_FOR_LEDGER'},
    {'priority_rank':6,'priority':'Holdout qualifiers','reason':'Phase 7 supports frozen holdout robustness with boundary cautions.','unblocks':'bounded internal robustness claim','current_status':'SUPPORTED_WITH_CAUTION'},
]
pd.DataFrame(priority_rows).to_csv(OUTPUT_DIR / 'phase9_validation_priority_ledger.csv', index=False)

no_go_claims = ['dark-matter exclusion','ΛCDM replacement','MOND/RAR falsification or defeat','NFW-halo falsification','Bullet Cluster explanation','dark-matter particle identity inference','Hubble-tension solution','SN-RRF/DCRRA as a physical dark-matter substitute','DCRRA zones as physical dark-sector classes','DCRRA zones as a stable synthetic classifier under current Phase 8/8R tests','non-SPARC external residual-level validation']
(OUTPUT_DIR / 'PHASE9_NO_GO_CLAIMS.md').write_text('\n'.join(['# Phase 9 No-Go Claims',''] + [f'- {x}' for x in no_go_claims] + ['','These no-go claims remain locked unless a future external-data and expert-review branch justifies a separate revision.']), encoding='utf-8')

severity_counts = ledger_df['severity'].value_counts().to_dict()
status_counts = ledger_df['status'].value_counts().to_dict()
summary = {
    'phase':'v3.0.0 Phase 9 Failure-Boundary Ledger',
    'status':'PASS-PHASE9-FAILURE-BOUNDARY-LEDGER-COMPILE',
    'interpretation':'FAILURE-BOUNDARY-LEDGER-LOCKED-WITH-CLAIM-BOUNDARY',
    'feature_rows':int(len(feature)),
    'source_phases_included':['Phase 0-3','Phase 4AB','Phase 5','Phase 5R','Phase 6','Phase 7','Phase 8','Phase 8R','External HOLD branch'],
    'failure_boundary_row_count':int(len(ledger_df)),
    'critical_boundary_count':int((ledger_df['severity']=='CRITICAL').sum()),
    'high_boundary_count':int((ledger_df['severity']=='HIGH').sum()),
    'fail_or_null_boundary_count':int(ledger_df['status'].astype(str).str.contains('FAIL_OR_NULL').sum()),
    'severity_counts':severity_counts,
    'status_counts':status_counts,
    'phase8_status':p8.get('status'),
    'phase8r_status':p8r.get('status'),
    'phase8r_interpretation':p8r.get('interpretation'),
    'external_validation':'HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE',
    'public_claim_mode':'claim-bounded diagnostic framework only',
    'safe_positive_claim':'Within the internal SPARC diagnostic protocol, SN-RRF/DCRRA provides a structured residual-regime diagnostic framework with explicit comparator, proxy, holdout, injection-recovery, and failure-boundary limitations.',
    'locked_no_go_claim_count':len(no_go_claims),
    'decision':'LOCK-PHASE9-FAILURE-BOUNDARY-LEDGER-WITH-NO-GO-CLAIMS',
}
with (OUTPUT_DIR / 'phase9_decision.json').open('w', encoding='utf-8') as f:
    json.dump(summary, f, indent=2, ensure_ascii=False)

report = f"""# Phase 9 Failure-Boundary Ledger Report

## Decision

`{summary['decision']}`

Status: `{summary['status']}`

Interpretation: `{summary['interpretation']}`

External validation: `{summary['external_validation']}`

## Ledger summary

- feature rows: {summary['feature_rows']}
- failure-boundary rows: {summary['failure_boundary_row_count']}
- critical boundaries: {summary['critical_boundary_count']}
- high-severity boundaries: {summary['high_boundary_count']}
- FAIL_OR_NULL boundaries: {summary['fail_or_null_boundary_count']}

## Central locked boundaries

1. Non-SPARC external residual-level validation remains HOLD.
2. Phase 5 overflex-null absorption requires comparator-fairness caution.
3. Phase 5R shows overflex dominance is complexity-penalty sensitive.
4. Phase 6 detects proxy/systematics sensitivity.
5. Phase 7 supports frozen holdout robustness only with boundary cautions.
6. Phase 8 injection-recovery is not sufficiently supported.
7. Phase 8R separability limitation persists.

## Safe synthesis

SN-RRF/DCRRA v3.0.0 may be described as an internal SPARC residual-regime diagnostic framework with explicit failure-boundary ledgers. It must not be described as a physical dark-matter taxonomy, dark-matter exclusion, MOND/RAR or NFW falsification, Lambda-CDM replacement, or non-SPARC external validation.
"""
(OUTPUT_DIR / 'PHASE9_REPORT.md').write_text(report, encoding='utf-8')
(OUTPUT_DIR / 'V300_PHASE9_DECISION.txt').write_text(f"""PASS-PHASE9-FAILURE-BOUNDARY-LEDGER-COMPILE
====================================================================================================
decision: {summary['decision']}
interpretation: {summary['interpretation']}
feature_rows: {summary['feature_rows']}
failure_boundary_row_count: {summary['failure_boundary_row_count']}
critical_boundary_count: {summary['critical_boundary_count']}
high_boundary_count: {summary['high_boundary_count']}
fail_or_null_boundary_count: {summary['fail_or_null_boundary_count']}
external_validation: {summary['external_validation']}
public_claim_mode: {summary['public_claim_mode']}
next: PHASE10-INTEGRATED-MANUSCRIPT-AND-REPOSITORY-PACKAGE or WAIT-FOR-NON-SPARC-DATA
""", encoding='utf-8')
print('PASS-PHASE9-FAILURE-BOUNDARY-LEDGER-COMPILE')
print(f"feature_rows={summary['feature_rows']}")
print(f"failure_boundary_row_count={summary['failure_boundary_row_count']}")
print(f"critical_boundary_count={summary['critical_boundary_count']}")
print(f"high_boundary_count={summary['high_boundary_count']}")
print(f"fail_or_null_boundary_count={summary['fail_or_null_boundary_count']}")
print(f"interpretation={summary['interpretation']}")
print(f"external_validation={summary['external_validation']}")
