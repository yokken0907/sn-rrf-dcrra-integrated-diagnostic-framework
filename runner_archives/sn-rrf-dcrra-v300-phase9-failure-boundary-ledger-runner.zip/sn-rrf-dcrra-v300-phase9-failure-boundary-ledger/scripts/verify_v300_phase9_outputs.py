from pathlib import Path
import json
import pandas as pd
out = Path('outputs_v3_0_0_phase9')
required = ['phase9_decision.json','phase9_failure_boundary_ledger.csv','phase9_validation_priority_ledger.csv','PHASE9_NO_GO_CLAIMS.md','PHASE9_REPORT.md','V300_PHASE9_DECISION.txt']
missing = [x for x in required if not (out/x).exists()]
if missing:
    raise SystemExit('ERROR: missing required Phase 9 outputs: ' + ', '.join(missing))
d = json.load(open(out/'phase9_decision.json', encoding='utf-8'))
ledger = pd.read_csv(out/'phase9_failure_boundary_ledger.csv')
priority = pd.read_csv(out/'phase9_validation_priority_ledger.csv')
errors = []
if d.get('status') != 'PASS-PHASE9-FAILURE-BOUNDARY-LEDGER-COMPILE': errors.append('bad phase9 status')
if d.get('external_validation') != 'HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE': errors.append('external validation not HOLD')
if len(ledger) < 12: errors.append('failure boundary ledger too small')
if int((ledger['severity'] == 'CRITICAL').sum()) < 2: errors.append('critical boundaries too few')
if not any(ledger['source_phase'].astype(str).str.contains('Phase 8R')): errors.append('Phase 8R boundary missing')
if not any(ledger['category'].astype(str).str.contains('data_availability')): errors.append('external HOLD boundary missing')
if len(priority) < 5: errors.append('validation priority ledger too small')
if errors:
    raise SystemExit('ERROR: ' + '; '.join(errors))
print('PASS-V300-PHASE9-OUTPUT-VERIFICATION')
print(f"feature_rows={d.get('feature_rows')}")
print(f"failure_boundary_row_count={d.get('failure_boundary_row_count')}")
print(f"critical_boundary_count={d.get('critical_boundary_count')}")
print(f"high_boundary_count={d.get('high_boundary_count')}")
print(f"fail_or_null_boundary_count={d.get('fail_or_null_boundary_count')}")
print(f"interpretation={d.get('interpretation')}")
print(f"external_validation={d.get('external_validation')}")
