from pathlib import Path
import csv, hashlib, sys
root = Path('.').resolve()
manifest = root / 'FILE_MANIFEST.csv'
if not manifest.exists():
    print('ERROR: FILE_MANIFEST.csv not found')
    sys.exit(1)
errors=[]
with manifest.open(newline='', encoding='utf-8') as f:
    reader=csv.DictReader(f)
    count=0
    for row in reader:
        rel=row['path']
        if rel in {'FILE_MANIFEST.csv','FILE_MANIFEST.json'}:
            continue
        p=root/rel
        if not p.exists():
            errors.append(f'missing: {rel}')
            continue
        sha=hashlib.sha256(p.read_bytes()).hexdigest()
        if sha != row['sha256']:
            errors.append(f'sha256 mismatch: {rel}')
        count+=1
if errors:
    print('FAIL-MANIFEST-VERIFICATION')
    for e in errors[:50]: print(e)
    sys.exit(1)
print('PASS-MANIFEST-VERIFICATION')
print(f'verified_files={count}')
