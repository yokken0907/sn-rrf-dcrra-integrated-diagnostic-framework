# SN-RRF-DCRRA v3.0.0 Phase 9 Failure-Boundary Ledger Runner

This package compiles the failure-boundary ledger for the SN-RRF-DCRRA v3.0.0 internal SPARC diagnostic branch.

It does **not** perform non-SPARC external residual-level validation. External validation remains `HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE`.

## Standard replay

```bash
python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase9_failure_boundary_ledger.py
python scripts/verify_v300_phase9_outputs.py
```

Expected status:

```text
PASS-PHASE9-FAILURE-BOUNDARY-LEDGER-COMPILE
PASS-V300-PHASE9-OUTPUT-VERIFICATION
```

Phase 9 consolidates the limitations and no-go boundaries observed in Phases 4AB, 5, 5R, 6, 7, 8, and 8R.
It is a synthesis / ledger-lock phase, not a new physical discovery phase.
