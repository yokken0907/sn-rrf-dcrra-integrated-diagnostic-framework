# Source materials

This runner includes Phase 0-3 output tables needed for Phase 4A. SPARC Rotmod data are not bundled by default; place them under `data_external/sparc_public_rotmod/Rotmod_LTG/` or use the provided downloader script.
