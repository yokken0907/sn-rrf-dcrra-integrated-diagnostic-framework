#!/usr/bin/env python3
"""
SN-RRF-DCRRA v3.0.0 Phase 4AB functional residual-shape audit.

This is an internal SPARC diagnostic audit. It does not perform non-SPARC
external residual-level validation and does not promote physical dark-matter,
modified-gravity, or cosmological claims.
"""
from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, adjusted_mutual_info_score, normalized_mutual_info_score, silhouette_score

PROJECT_VERSION = "3.0.0-phase4ab-functional-residual-shape-audit-runner"
EXTERNAL_VALIDATION_STATUS = "HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE"
FORBIDDEN_CLAIMS = [
    "dark_matter_exclusion",
    "lcdm_replacement",
    "mond_rar_falsification",
    "nfw_falsification",
    "new_physics_discovery",
    "non_sparc_external_validation_claim",
]


def signed_square(x: np.ndarray | pd.Series) -> np.ndarray:
    arr = np.asarray(x, dtype=float)
    return np.sign(arr) * arr * arr


def safe_name_from_rotmod(path: Path) -> str:
    name = path.name
    return re.sub(r"_rotmod\.dat$", "", name)


def find_feature_table(root: Path, explicit: Optional[str]) -> Path:
    candidates = []
    if explicit:
        candidates.append(Path(explicit))
    candidates.extend([
        root / "outputs_v3_0_0" / "residual_response_feature_table.csv",
        root / "v3_0_0_phase0_3_internal_deepening_replay" / "outputs_v3_0_0" / "residual_response_feature_table.csv",
        root.parent / "v3_0_0_phase0_3_internal_deepening_replay" / "outputs_v3_0_0" / "residual_response_feature_table.csv",
        root.parent / "outputs_v3_0_0" / "residual_response_feature_table.csv",
    ])
    for p in candidates:
        if p.exists():
            return p.resolve()
    raise FileNotFoundError("residual_response_feature_table.csv not found. Pass --feature-table explicitly.")


def find_rotmod_dir(root: Path, explicit: Optional[str]) -> Optional[Path]:
    candidates = []
    if explicit:
        candidates.append(Path(explicit))
    env = None
    try:
        import os
        env = os.environ.get("SPARC_ROTMOD_DIR")
    except Exception:
        env = None
    if env:
        candidates.append(Path(env))
    candidates.extend([
        root / "data_external" / "sparc_public_rotmod" / "Rotmod_LTG",
        root.parent / "data_external" / "sparc_public_rotmod" / "Rotmod_LTG",
        root.parent.parent / "data_external" / "sparc_public_rotmod" / "Rotmod_LTG",
        Path.home() / "a10_projects" / "a10-galaxy-residual-response-diagnostics" / "data_external" / "sparc_public_rotmod" / "Rotmod_LTG",
    ])
    for p in candidates:
        if p.exists() and list(p.glob("*_rotmod.dat")):
            return p.resolve()
    return None


def read_rotmod_file(path: Path) -> pd.DataFrame:
    cols = ["Rad", "Vobs", "errV", "Vgas", "Vdisk", "Vbul", "SBdisk", "SBbul"]
    df = pd.read_csv(path, comment="#", sep=r"\s+", names=cols, engine="python")
    df = df.dropna(how="all")
    for c in cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["Rad", "Vobs", "errV", "Vgas", "Vdisk", "Vbul"])
    df = df.sort_values("Rad").reset_index(drop=True)
    return df


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def numeric_feature_columns(df: pd.DataFrame) -> list[str]:
    preferred = [
        "best_n",
        "rrf_rc_over_rlast",
        "rrf_A_over_vouter2",
        "v_outer_kms",
        "v_max_kms",
        "gas_fraction_proxy",
        "outer_baryon_fraction_proxy",
        "n_points",
        "estimated_family_delta_aic_minus_nfw_like",
        "estimated_family_delta_aic_minus_rar_like",
        "rrf_aic_v2",
        "curve_level_rrf_A_kms2",
        "curve_level_rrf_rc_kpc",
        "delta_aic_rrf_minus_best_destructive_null",
        "delta_aic_rrf_minus_best_neighbor_null",
        "delta_aic_locked_minus_best_continuum",
        "grid_count_within_2_of_best",
        "grid_count_within_10_of_best",
        "response_family_strength_axis",
        "halo_competitiveness_axis",
        "rar_competitiveness_axis",
        "nuisance_or_pathology_flag",
        "overflex_neighbor_risk_flag",
        "destructive_null_pass_flag",
    ]
    return [c for c in preferred if c in df.columns and pd.api.types.is_numeric_dtype(df[c])]


def cluster_metrics(X: np.ndarray, labels: list[str], n_clusters: int, seed: int = 3004) -> dict:
    unique_labels = sorted(set(labels))
    k = min(n_clusters, max(2, len(unique_labels)))
    km = KMeans(n_clusters=k, random_state=seed, n_init=25)
    pred = km.fit_predict(X)
    out = {
        "kmeans_cluster_count": int(k),
        "adjusted_rand_index": float(adjusted_rand_score(labels, pred)),
        "adjusted_mutual_info": float(adjusted_mutual_info_score(labels, pred)),
        "normalized_mutual_info": float(normalized_mutual_info_score(labels, pred)),
    }
    try:
        if len(set(pred)) > 1 and len(set(pred)) < len(pred):
            out["silhouette_score"] = float(silhouette_score(X, pred))
        else:
            out["silhouette_score"] = None
    except Exception:
        out["silhouette_score"] = None
    return out


def eta_squared_by_zone(values: np.ndarray, zones: list[str]) -> float:
    v = np.asarray(values, dtype=float)
    z = np.asarray(zones)
    grand = np.nanmean(v)
    total = np.nansum((v - grand) ** 2)
    if total <= 0:
        return 0.0
    between = 0.0
    for zone in sorted(set(z)):
        mask = z == zone
        if mask.any():
            between += mask.sum() * (np.nanmean(v[mask]) - grand) ** 2
    return float(between / total)


def run_phase4a(feature: pd.DataFrame, outdir: Path, figdir: Path) -> dict:
    zone_col = "dcrra7_residual_map_zone"
    gal_col = "galaxy"
    cols = numeric_feature_columns(feature)
    if not cols:
        raise RuntimeError("No numeric residual-shape proxy columns available.")
    Xdf = feature[[gal_col, zone_col] + cols].copy()
    for c in cols:
        Xdf[c] = pd.to_numeric(Xdf[c], errors="coerce")
    # Median imputation for robust reduced audit.
    for c in cols:
        Xdf[c] = Xdf[c].fillna(Xdf[c].median())
    X = Xdf[cols].to_numpy(dtype=float)
    Xs = StandardScaler().fit_transform(X)
    pca = PCA(n_components=2, random_state=3004)
    coords = pca.fit_transform(Xs)
    labels = Xdf[zone_col].astype(str).tolist()
    met = cluster_metrics(coords, labels, n_clusters=len(set(labels)), seed=3004)
    Xdf["phase4a_proxy_pc1"] = coords[:, 0]
    Xdf["phase4a_proxy_pc2"] = coords[:, 1]
    Xdf.to_csv(outdir / "phase4a_proxy_pca_coordinates.csv", index=False)
    summary = {
        "phase": "4A",
        "status": "PASS-PHASE4A-REDUCED-RESIDUAL-SHAPE-PROXY-AUDIT-RUN",
        "feature_rows": int(len(feature)),
        "proxy_feature_count": int(len(cols)),
        "proxy_features": cols,
        "pca_explained_variance_ratio": [float(x) for x in pca.explained_variance_ratio_],
        "pc1_zone_eta_squared": eta_squared_by_zone(coords[:, 0], labels),
        "pc2_zone_eta_squared": eta_squared_by_zone(coords[:, 1], labels),
        **{f"phase4a_{k}": v for k, v in met.items()},
    }
    (outdir / "phase4a_shape_proxy_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    plt.figure(figsize=(8, 6))
    for zone, sub in Xdf.groupby(zone_col):
        plt.scatter(sub["phase4a_proxy_pc1"], sub["phase4a_proxy_pc2"], label=zone, s=28, alpha=0.75)
    plt.xlabel("Phase 4A proxy PC1")
    plt.ylabel("Phase 4A proxy PC2")
    plt.title("Phase 4A residual-shape proxy PCA by DCRRA zone")
    plt.legend(fontsize=7, loc="best")
    plt.tight_layout()
    plt.savefig(figdir / "v300_phase4a_proxy_pca_zone_overlay.png", dpi=180)
    plt.close()
    return summary


def run_phase4b(feature: pd.DataFrame, rotmod_dir: Optional[Path], outdir: Path, figdir: Path) -> dict:
    if rotmod_dir is None:
        summary = {
            "phase": "4B",
            "status": "HOLD-PHASE4B-ROTMOD-DATA-NOT-FOUND",
            "rotmod_file_count": 0,
            "matched_rotmod_count": 0,
            "missing_rotmod_count": int(len(feature)),
            "external_validation_status": EXTERNAL_VALIDATION_STATUS,
        }
        (outdir / "phase4b_rotmod_shape_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return summary

    gal_col = "galaxy"
    zone_col = "dcrra7_residual_map_zone"
    feature_galaxies = set(feature[gal_col].astype(str))
    files = sorted(rotmod_dir.glob("*_rotmod.dat"))
    rotmod_map = {safe_name_from_rotmod(f): f for f in files}
    matched = sorted(feature_galaxies & set(rotmod_map.keys()))
    missing = sorted(feature_galaxies - set(rotmod_map.keys()))

    s_grid = np.round(np.linspace(0.05, 1.00, 40), 5)
    long_rows = []
    metrics_rows = []
    wide_rows = []

    feat_idx = feature.set_index(gal_col, drop=False)
    for galaxy in matched:
        path = rotmod_map[galaxy]
        rdf = read_rotmod_file(path)
        if len(rdf) < 3:
            continue
        rlast = float(rdf["Rad"].max())
        vouter = float(feat_idx.loc[galaxy].get("v_outer_kms", rdf["Vobs"].iloc[-1]))
        if not np.isfinite(vouter) or abs(vouter) < 1e-9:
            vouter = float(rdf["Vobs"].iloc[-1])
        denom = max(vouter * vouter, 1e-9)
        s = rdf["Rad"].to_numpy(dtype=float) / max(rlast, 1e-12)
        vbar2_proxy = signed_square(rdf["Vgas"]) + rdf["Vdisk"].to_numpy(dtype=float) ** 2 + rdf["Vbul"].to_numpy(dtype=float) ** 2
        residual_v2 = rdf["Vobs"].to_numpy(dtype=float) ** 2 - vbar2_proxy
        residual_norm = residual_v2 / denom
        vobs_norm = rdf["Vobs"].to_numpy(dtype=float) / max(abs(vouter), 1e-9)
        err_frac = rdf["errV"].to_numpy(dtype=float) / np.maximum(np.abs(rdf["Vobs"].to_numpy(dtype=float)), 1e-9)

        # Interpolation with boundary carry: diagnostic only.
        order = np.argsort(s)
        s_sorted = s[order]
        y_sorted = residual_norm[order]
        interp = np.interp(s_grid, s_sorted, y_sorted)
        vobs_interp = np.interp(s_grid, s_sorted, vobs_norm[order])

        best_n = float(feat_idx.loc[galaxy].get("best_n", np.nan))
        sc = float(feat_idx.loc[galaxy].get("rrf_rc_over_rlast", np.nan))
        amp = float(feat_idx.loc[galaxy].get("rrf_A_over_vouter2", np.nan))
        if np.isfinite(best_n) and np.isfinite(sc) and sc > 0 and np.isfinite(amp):
            x = s_grid / sc
            kernel = amp * (x ** best_n) / (1.0 + x ** best_n)
        else:
            kernel = np.full_like(s_grid, np.nan, dtype=float)
        if np.all(np.isfinite(kernel)) and np.std(interp) > 1e-12 and np.std(kernel) > 1e-12:
            corr = float(np.corrcoef(interp, kernel)[0, 1])
            rmse = float(np.sqrt(np.mean((interp - kernel) ** 2)))
        else:
            corr, rmse = None, None

        zone = str(feat_idx.loc[galaxy][zone_col])
        wide = {"galaxy": galaxy, "zone": zone}
        for ss, yy, vv, kk in zip(s_grid, interp, vobs_interp, kernel):
            wide[f"residual_norm_s_{ss:.5f}"] = float(yy)
            long_rows.append({
                "galaxy": galaxy,
                "zone": zone,
                "s": float(ss),
                "residual_norm_v2_proxy": float(yy),
                "vobs_norm": float(vv),
                "snrrf_kernel_proxy_norm": None if not np.isfinite(kk) else float(kk),
            })
        wide_rows.append(wide)
        metrics_rows.append({
            "galaxy": galaxy,
            "zone": zone,
            "rotmod_points": int(len(rdf)),
            "Rlast_kpc": rlast,
            "median_abs_residual_norm": float(np.nanmedian(np.abs(residual_norm))),
            "max_abs_residual_norm": float(np.nanmax(np.abs(residual_norm))),
            "roughness_rms_diff": float(np.sqrt(np.nanmean(np.diff(interp) ** 2))),
            "median_err_fraction": float(np.nanmedian(err_frac)),
            "negative_vbar2_proxy_fraction": float(np.mean(vbar2_proxy < 0)),
            "negative_residual_v2_fraction": float(np.mean(residual_v2 < 0)),
            "kernel_curve_corr": corr,
            "kernel_curve_rmse": rmse,
        })

    long_df = pd.DataFrame(long_rows)
    metrics_df = pd.DataFrame(metrics_rows)
    wide_df = pd.DataFrame(wide_rows)
    long_df.to_csv(outdir / "phase4b_rotmod_residual_shape_grid_long.csv", index=False)
    metrics_df.to_csv(outdir / "phase4b_rotmod_shape_metrics_by_galaxy.csv", index=False)

    if wide_df.empty or len(wide_df) < 3:
        summary = {
            "phase": "4B",
            "status": "HOLD-PHASE4B-INSUFFICIENT-MATCHED-ROTMOD-CURVES",
            "rotmod_dir": str(rotmod_dir),
            "rotmod_file_count": int(len(files)),
            "matched_rotmod_count": int(len(matched)),
            "missing_rotmod_count": int(len(missing)),
            "missing_rotmod_galaxies": missing,
            "external_validation_status": EXTERNAL_VALIDATION_STATUS,
        }
        (outdir / "phase4b_rotmod_shape_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        return summary

    shape_cols = [c for c in wide_df.columns if c.startswith("residual_norm_s_")]
    X = wide_df[shape_cols].to_numpy(dtype=float)
    # Guard against non-finite values.
    col_medians = np.nanmedian(X, axis=0)
    inds = np.where(~np.isfinite(X))
    if inds[0].size:
        X[inds] = np.take(col_medians, inds[1])
    Xs = StandardScaler().fit_transform(X)
    pca = PCA(n_components=2, random_state=4004)
    coords = pca.fit_transform(Xs)
    labels = wide_df["zone"].astype(str).tolist()
    met = cluster_metrics(coords, labels, n_clusters=len(set(labels)), seed=4004)
    wide_df["phase4b_shape_pc1"] = coords[:, 0]
    wide_df["phase4b_shape_pc2"] = coords[:, 1]
    wide_df[["galaxy", "zone", "phase4b_shape_pc1", "phase4b_shape_pc2"]].to_csv(outdir / "phase4b_shape_pca_coordinates.csv", index=False)

    zone_summary = metrics_df.groupby("zone", dropna=False).agg(
        galaxy_count=("galaxy", "count"),
        median_abs_residual_norm=("median_abs_residual_norm", "median"),
        median_roughness_rms_diff=("roughness_rms_diff", "median"),
        median_err_fraction=("median_err_fraction", "median"),
        median_kernel_curve_corr=("kernel_curve_corr", "median"),
        median_kernel_curve_rmse=("kernel_curve_rmse", "median"),
    ).reset_index()
    zone_summary.to_csv(outdir / "phase4b_zone_shape_alignment.csv", index=False)

    # Failure-boundary candidates: top roughness / high err / weak kernel correlation.
    fbc = metrics_df.copy()
    fbc["failure_boundary_candidate_score"] = (
        fbc["roughness_rms_diff"].rank(pct=True)
        + fbc["median_err_fraction"].rank(pct=True)
        + fbc["negative_residual_v2_fraction"].rank(pct=True)
        + (1.0 - fbc["kernel_curve_corr"].fillna(0.0).clip(-1, 1)).rank(pct=True)
    )
    fbc = fbc.sort_values("failure_boundary_candidate_score", ascending=False)
    fbc.to_csv(outdir / "phase4b_failure_boundary_candidates.csv", index=False)

    summary = {
        "phase": "4B",
        "status": "PASS-PHASE4B-SPARC-ROTMOD-FUNCTIONAL-RESIDUAL-SHAPE-AUDIT-RUN",
        "rotmod_dir": str(rotmod_dir),
        "rotmod_file_count": int(len(files)),
        "feature_rows": int(len(feature)),
        "matched_rotmod_count": int(len(matched)),
        "missing_rotmod_count": int(len(missing)),
        "missing_rotmod_galaxies": missing,
        "s_grid_count": int(len(s_grid)),
        "residual_curve_model": "unit_ML_signed_gas_reduced_v2_residual_proxy",
        "pca_explained_variance_ratio": [float(x) for x in pca.explained_variance_ratio_],
        "pc1_zone_eta_squared": eta_squared_by_zone(coords[:, 0], labels),
        "pc2_zone_eta_squared": eta_squared_by_zone(coords[:, 1], labels),
        **{f"phase4b_{k}": v for k, v in met.items()},
        "external_validation_status": EXTERNAL_VALIDATION_STATUS,
        "claim_boundary": "SPARC-internal diagnostic residual-shape audit only; no non-SPARC external validation claim.",
    }
    (outdir / "phase4b_rotmod_shape_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    plt.figure(figsize=(8, 6))
    plot_df = wide_df[["galaxy", "zone", "phase4b_shape_pc1", "phase4b_shape_pc2"]].copy()
    for zone, sub in plot_df.groupby("zone"):
        plt.scatter(sub["phase4b_shape_pc1"], sub["phase4b_shape_pc2"], label=zone, s=28, alpha=0.75)
    plt.xlabel("Phase 4B shape PC1")
    plt.ylabel("Phase 4B shape PC2")
    plt.title("Phase 4B SPARC Rotmod residual-shape PCA by DCRRA zone")
    plt.legend(fontsize=7, loc="best")
    plt.tight_layout()
    plt.savefig(figdir / "v300_phase4b_shape_pca_zone_overlay.png", dpi=180)
    plt.close()

    plt.figure(figsize=(9, 6))
    if not long_df.empty:
        for zone, sub in long_df.groupby("zone"):
            med = sub.groupby("s")["residual_norm_v2_proxy"].median().reset_index()
            plt.plot(med["s"], med["residual_norm_v2_proxy"], label=zone, linewidth=1.6)
    plt.axhline(0.0, linewidth=0.8)
    plt.xlabel("s = Rad / Rlast")
    plt.ylabel("median reduced residual proxy")
    plt.title("Phase 4B median residual-shape proxy by DCRRA zone")
    plt.legend(fontsize=7, loc="best")
    plt.tight_layout()
    plt.savefig(figdir / "v300_phase4b_median_residual_shape_by_zone.png", dpi=180)
    plt.close()
    return summary


def write_markdown_report(outdir: Path, figdir: Path, phase4a: dict, phase4b: dict, decision: dict) -> None:
    report = f"""# SN-RRF-DCRRA v3.0.0 Phase 4AB Report

## Status

```text
{decision.get('status')}
```

## Phase 4A

- Status: `{phase4a.get('status')}`
- Feature rows: `{phase4a.get('feature_rows')}`
- Proxy feature count: `{phase4a.get('proxy_feature_count')}`
- PCA explained variance ratio: `{phase4a.get('pca_explained_variance_ratio')}`
- ARI vs DCRRA zones: `{phase4a.get('phase4a_adjusted_rand_index')}`

## Phase 4B

- Status: `{phase4b.get('status')}`
- Rotmod files: `{phase4b.get('rotmod_file_count')}`
- Matched rotmod curves: `{phase4b.get('matched_rotmod_count')}`
- Missing rotmod curves: `{phase4b.get('missing_rotmod_count')}`
- PCA explained variance ratio: `{phase4b.get('pca_explained_variance_ratio')}`
- ARI vs DCRRA zones: `{phase4b.get('phase4b_adjusted_rand_index')}`

## Claim boundary

This is an internal SPARC residual-shape diagnostic audit. It is not non-SPARC external validation and not a physical dark-matter, MOND/RAR, NFW, ΛCDM, or new-physics claim.

## Main generated outputs

- `phase4a_proxy_pca_coordinates.csv`
- `phase4a_shape_proxy_summary.json`
- `phase4b_rotmod_residual_shape_grid_long.csv`
- `phase4b_rotmod_shape_metrics_by_galaxy.csv`
- `phase4b_shape_pca_coordinates.csv`
- `phase4b_zone_shape_alignment.csv`
- `phase4b_failure_boundary_candidates.csv`
- `phase4b_rotmod_shape_summary.json`
- `phase4ab_decision.json`
"""
    (outdir / "PHASE4AB_REPORT.md").write_text(report, encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--feature-table", default=None)
    ap.add_argument("--rotmod-dir", default=None)
    ap.add_argument("--output-dir", default="outputs_v3_0_0_phase4ab")
    args = ap.parse_args()

    root = Path.cwd()
    outdir = root / args.output_dir
    figdir = root / "paper" / "figs"
    ensure_dir(outdir)
    ensure_dir(figdir)

    feature_path = find_feature_table(root, args.feature_table)
    feature = pd.read_csv(feature_path)
    if "galaxy" not in feature.columns or "dcrra7_residual_map_zone" not in feature.columns:
        raise RuntimeError("Feature table must contain galaxy and dcrra7_residual_map_zone columns.")

    rotmod_dir = find_rotmod_dir(root, args.rotmod_dir)
    phase4a = run_phase4a(feature, outdir, figdir)
    phase4b = run_phase4b(feature, rotmod_dir, outdir, figdir)

    full_coverage = phase4b.get("matched_rotmod_count", 0) == len(feature) and phase4b.get("missing_rotmod_count", 1) == 0
    if phase4b.get("status", "").startswith("PASS") and full_coverage:
        status = "PASS-PHASE4AB-FUNCTIONAL-RESIDUAL-SHAPE-AUDIT-RUN"
    elif phase4b.get("status", "").startswith("PASS"):
        status = "MIXED-PHASE4AB-RUN-WITH-PARTIAL-ROTMOD-COVERAGE"
    else:
        status = "HOLD-PHASE4AB-ROTMOD-DATA-NOT-AVAILABLE"

    decision = {
        "version": PROJECT_VERSION,
        "status": status,
        "feature_table": str(feature_path),
        "feature_rows": int(len(feature)),
        "phase4a_status": phase4a.get("status"),
        "phase4b_status": phase4b.get("status"),
        "rotmod_dir": None if rotmod_dir is None else str(rotmod_dir),
        "rotmod_file_count": int(phase4b.get("rotmod_file_count", 0)),
        "matched_rotmod_count": int(phase4b.get("matched_rotmod_count", 0)),
        "missing_rotmod_count": int(phase4b.get("missing_rotmod_count", len(feature))),
        "phase4a_adjusted_rand_index": phase4a.get("phase4a_adjusted_rand_index"),
        "phase4b_adjusted_rand_index": phase4b.get("phase4b_adjusted_rand_index"),
        "phase4a_pca_explained_variance_ratio": phase4a.get("pca_explained_variance_ratio"),
        "phase4b_pca_explained_variance_ratio": phase4b.get("pca_explained_variance_ratio"),
        "external_validation_status": EXTERNAL_VALIDATION_STATUS,
        "forbidden_claims": FORBIDDEN_CLAIMS,
        "claim_boundary": "Internal SPARC residual-shape diagnostic audit only. No non-SPARC external validation claim.",
    }
    (outdir / "phase4ab_decision.json").write_text(json.dumps(decision, indent=2), encoding="utf-8")
    (outdir / "V300_PHASE4AB_DECISION.txt").write_text(
        f"{status}\nfeature_rows={len(feature)}\nmatched_rotmod_count={decision['matched_rotmod_count']}\nmissing_rotmod_count={decision['missing_rotmod_count']}\nexternal_validation=HOLD\n",
        encoding="utf-8",
    )
    write_markdown_report(outdir, figdir, phase4a, phase4b, decision)

    print(status)
    print(f"feature_rows={len(feature)}")
    print(f"rotmod_file_count={decision['rotmod_file_count']}")
    print(f"matched_rotmod_count={decision['matched_rotmod_count']}")
    print(f"missing_rotmod_count={decision['missing_rotmod_count']}")
    print("external_validation=HOLD")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
