#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

OUT = Path("outputs_v3_0_0_phase4ab")
required = [
    OUT / "phase4a_proxy_pca_coordinates.csv",
    OUT / "phase4a_shape_proxy_summary.json",
    OUT / "phase4b_rotmod_residual_shape_grid_long.csv",
    OUT / "phase4b_rotmod_shape_metrics_by_galaxy.csv",
    OUT / "phase4b_shape_pca_coordinates.csv",
    OUT / "phase4b_zone_shape_alignment.csv",
    OUT / "phase4b_failure_boundary_candidates.csv",
    OUT / "phase4b_rotmod_shape_summary.json",
    OUT / "phase4ab_decision.json",
    OUT / "V300_PHASE4AB_DECISION.txt",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("FAIL-V300-PHASE4AB-OUTPUT-VERIFICATION")
    print("missing_files=")
    for m in missing:
        print("  " + m)
    raise SystemExit(1)

decision = json.loads((OUT / "phase4ab_decision.json").read_text(encoding="utf-8"))
shape = pd.read_csv(OUT / "phase4b_shape_pca_coordinates.csv")
feature_rows = int(decision.get("feature_rows", -1))
matched = int(decision.get("matched_rotmod_count", -1))
missing_count = int(decision.get("missing_rotmod_count", -1))
external = decision.get("external_validation_status", "")

errors = []
if feature_rows <= 0:
    errors.append("feature_rows must be positive")
if len(shape) != matched:
    errors.append(f"shape_pca row count {len(shape)} != matched_rotmod_count {matched}")
if matched + missing_count != feature_rows:
    errors.append(f"matched + missing ({matched}+{missing_count}) != feature_rows {feature_rows}")
if "HOLD" not in external:
    errors.append("external_validation_status must remain HOLD")
if "dark_matter_exclusion" not in decision.get("forbidden_claims", []):
    errors.append("forbidden claim ledger missing dark_matter_exclusion")

if errors:
    print("FAIL-V300-PHASE4AB-OUTPUT-VERIFICATION")
    for e in errors:
        print("error:", e)
    raise SystemExit(1)

print("PASS-V300-PHASE4AB-OUTPUT-VERIFICATION")
print(f"feature_rows={feature_rows}")
print(f"matched_rotmod_count={matched}")
print(f"missing_rotmod_count={missing_count}")
print("external_validation=HOLD")
print("phase4ab_status=" + str(decision.get("status")))
