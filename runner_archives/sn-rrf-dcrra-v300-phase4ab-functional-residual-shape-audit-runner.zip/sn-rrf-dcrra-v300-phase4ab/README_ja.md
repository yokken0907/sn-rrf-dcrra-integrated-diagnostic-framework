# SN-RRF-DCRRA v3.0.0 Phase 4AB：残差曲線形状監査

このパッケージは、Phase 0-3 の内部統合深化branchに続く Phase 4AB 実行パッケージです。

実行する内容は以下です。

- **Phase 4A**：既存の `outputs_v3_0_0/residual_response_feature_table.csv` を用いた reduced residual-shape proxy audit。
- **Phase 4B**：SPARC公開Rotmodファイル `*_rotmod.dat` を用いた、半径別・曲線形状ベースの internal functional residual-shape audit。

これは **SPARC内部監査** であり、非SPARC外部残差検証ではありません。DiskMass/THINGS等の非SPARC radius-resolved baryonic component-curve table が得られるまで、external residual-level validation は HOLD のままです。

## 境界

本パッケージは、暗黒物質否定、ΛCDM置換、MOND/RAR反証、NFW反証、新物理発見、外部検証成功を主張しません。曲線形状・比較器依存性・失敗境界を診断するための内部SPARC監査です。
