#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json
from pathlib import Path

ROOT = Path.cwd()
EXCLUDE = {"FILE_MANIFEST.csv", "manifest.json", "SHA256SUMS.txt", "MANIFEST_VERIFY_PASS.txt"}
manifest_path = ROOT / "FILE_MANIFEST.csv"
if not manifest_path.exists():
    print("FAIL-MANIFEST-VERIFICATION")
    print("missing FILE_MANIFEST.csv")
    raise SystemExit(1)
rows = []
with manifest_path.open(newline='', encoding='utf-8') as f:
    reader = csv.DictReader(f)
    for row in reader:
        rows.append(row)
errors = []
verified = 0
for row in rows:
    rel = row.get('path') or row.get('relative_path')
    if not rel or rel in EXCLUDE:
        continue
    p = ROOT / rel
    if not p.exists():
        errors.append(f"missing: {rel}")
        continue
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    expected = row.get('sha256')
    if expected and h != expected:
        errors.append(f"sha256 mismatch: {rel}")
    verified += 1
if errors:
    print("FAIL-MANIFEST-VERIFICATION")
    for e in errors:
        print(e)
    raise SystemExit(1)
print("PASS-MANIFEST-VERIFICATION")
print(f"verified_files={verified}")
