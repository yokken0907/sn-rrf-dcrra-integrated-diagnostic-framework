# Phase 4AB Decision Template

Expected key fields in `outputs_v3_0_0_phase4ab/phase4ab_decision.json`:

- `phase4a_status`
- `phase4b_status`
- `feature_rows`
- `rotmod_file_count`
- `matched_rotmod_count`
- `missing_rotmod_count`
- `phase4a_adjusted_rand_index`
- `phase4b_adjusted_rand_index`
- `phase4b_shape_pca_explained_variance_ratio`
- `external_validation_status`
- `claim_boundary`

Decision language:

```text
Phase 4AB is an internal SPARC residual-shape audit. It may strengthen or weaken the internal residual-regime interpretation, but it does not constitute non-SPARC external residual-level validation.
```
