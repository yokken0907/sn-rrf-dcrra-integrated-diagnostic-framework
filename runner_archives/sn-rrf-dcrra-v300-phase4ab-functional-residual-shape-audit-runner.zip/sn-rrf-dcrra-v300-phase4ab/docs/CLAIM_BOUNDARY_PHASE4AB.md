# Claim Boundary — Phase 4AB

Phase 4AB is an internal SPARC residual-shape diagnostic audit.

Allowed:

- audit of residual-shape proxy features;
- audit of SPARC public Rotmod radius-resolved curves;
- reduced unit-M/L baryonic-residual proxy construction;
- feature-space and functional-shape PCA / clustering diagnostics;
- zone-shape alignment diagnostics;
- failure-boundary candidate logging.

Not allowed:

- dark-matter exclusion;
- ΛCDM replacement;
- MOND/RAR falsification;
- NFW-halo falsification;
- external residual-level validation claim;
- physical dark-sector taxonomy;
- new-physics discovery;
- claim that the unit-M/L reduced residual is the final physical residual.

Important limitation:

The Phase 4B residual curve is a diagnostic reduced residual constructed from public SPARC rotmod components using a fixed unit-M/L baryonic proxy. It is not a full physical mass-model refit and not a replacement for expert galaxy-dynamics analysis.
