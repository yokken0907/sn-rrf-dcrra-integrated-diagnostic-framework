# Phase 4AB Protocol

## Purpose

Phase 4AB tests whether the SN-RRF/DCRRA residual-regime map has corresponding residual-shape structure when examined through:

1. galaxy-level residual-shape proxy descriptors; and
2. SPARC public Rotmod radius-resolved residual-curve proxies.

## Phase 4A

Uses selected numerical columns from `residual_response_feature_table.csv`, including response-shape, response-radius, amplitude, comparator margins, and null-control margins. These are standardized and projected by PCA; a k-means diagnostic cluster comparison is reported against DCRRA zones.

## Phase 4B

Reads `*_rotmod.dat` files with columns:

```text
Rad Vobs errV Vgas Vdisk Vbul SBdisk SBbul
```

For each galaxy, it computes a reduced diagnostic residual:

```text
Vbar2_proxy = signed_square(Vgas) + Vdisk^2 + Vbul^2
residual_v2_proxy = Vobs^2 - Vbar2_proxy
residual_norm = residual_v2_proxy / max(Vouter^2, epsilon)
```

The gas term is treated with signed-square convention to preserve negative gas contributions. This is a diagnostic residual proxy, not a final physical fit.

The residual curve is interpolated onto a common dimensionless grid `s = Rad / Rlast`. PCA and cluster/zone alignment diagnostics are then computed.

## PASS / MIXED / NULL / HOLD interpretation

- PASS means the audit ran with full expected coverage and produced internally consistent outputs.
- MIXED means some zone-shape alignment exists but remains limited or comparator-dependent.
- NULL means residual-shape structure does not align with DCRRA zones under this diagnostic protocol.
- HOLD means required data are missing.

No status promotes the result into a physical dark-matter claim.
