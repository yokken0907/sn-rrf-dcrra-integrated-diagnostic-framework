# Release title
SN-RRF-DCRRA v3.0.0 Phase 4AB — Functional Residual-Shape Audit Runner

# Release notes
This release adds the Phase 4AB internal SPARC residual-shape audit runner for the SN-RRF/DCRRA v3.0.0 integrated diagnostic branch.

It includes:

- Phase 4A reduced residual-shape proxy audit;
- Phase 4B SPARC public Rotmod functional residual-shape audit;
- strict claim boundary documentation;
- WSL replay scripts;
- manifest verification tooling.

External residual-level validation remains on data-availability HOLD. This release does not claim dark-matter exclusion, ΛCDM replacement, MOND/RAR falsification, NFW falsification, new physics, or non-SPARC validation.

Suggested tag:

```text
v3.0.0-phase4ab-functional-residual-shape-audit-runner
```
