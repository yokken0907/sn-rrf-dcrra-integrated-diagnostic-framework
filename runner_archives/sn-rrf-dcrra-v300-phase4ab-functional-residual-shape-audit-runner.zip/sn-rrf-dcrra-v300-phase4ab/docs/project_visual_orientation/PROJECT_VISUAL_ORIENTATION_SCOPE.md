The visual orientation page summarizes workflow and claim boundaries only. It is not evidence beyond the generated audit outputs.
