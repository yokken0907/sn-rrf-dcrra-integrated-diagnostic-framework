# Project visual orientation

Open `index.html` in a browser for a local static overview of the Phase 4AB workflow.
