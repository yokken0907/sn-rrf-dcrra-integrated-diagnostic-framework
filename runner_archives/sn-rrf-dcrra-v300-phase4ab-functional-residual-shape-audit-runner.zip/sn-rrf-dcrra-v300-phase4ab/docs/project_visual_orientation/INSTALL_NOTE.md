No server is required. Open `index.html` directly in a browser.
