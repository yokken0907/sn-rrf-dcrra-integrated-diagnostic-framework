# SN-RRF-DCRRA v3.0.0 Phase 4AB: Functional Residual-Shape Audit

This package continues the SN-RRF/DCRRA v3.0.0 internal deepening branch after Phase 0-3.

It performs two internal SPARC-only audits:

- **Phase 4A — Reduced residual-shape proxy audit** using the existing `outputs_v3_0_0/residual_response_feature_table.csv`.
- **Phase 4B — SPARC public Rotmod functional residual-shape audit** using radius-resolved SPARC rotmod files such as `data_external/sparc_public_rotmod/Rotmod_LTG/*_rotmod.dat`.

This package does **not** perform non-SPARC external residual-level validation. The external validation branch remains on data-availability HOLD until a non-SPARC radius-resolved baryonic component-curve table is available.

## Claim boundary

The result is a diagnostic residual-shape audit. It is not a dark-matter exclusion claim, not a ΛCDM replacement, not a MOND/RAR falsification, not an NFW falsification, not a new-physics discovery, and not an external validation claim.

## Expected WSL replay

Place or keep the SPARC rotmod data at one of the following locations:

- `../data_external/sparc_public_rotmod/Rotmod_LTG/`
- `data_external/sparc_public_rotmod/Rotmod_LTG/`
- or pass it explicitly with `--rotmod-dir`.

Then run:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase4ab_functional_residual_shape_audit.py   --rotmod-dir ../data_external/sparc_public_rotmod/Rotmod_LTG
python scripts/verify_v300_phase4ab_outputs.py
```

Expected final status on the current 143-galaxy eligible sample with 143/143 rotmod coverage:

```text
PASS-PHASE4AB-FUNCTIONAL-RESIDUAL-SHAPE-AUDIT-RUN
PASS-V300-PHASE4AB-OUTPUT-VERIFICATION
```
