# SPARC public Rotmod data location

Place or download the SPARC public Rotmod files here:

```text
data_external/sparc_public_rotmod/Rotmod_LTG/*_rotmod.dat
```

The Phase 4B script also searches the parent project directory, so if the data already exist at:

```text
../data_external/sparc_public_rotmod/Rotmod_LTG/*_rotmod.dat
```

the script can use them without copying.
