#!/usr/bin/env bash
set -euo pipefail
mkdir -p data_external/sparc_public_rotmod
cd data_external/sparc_public_rotmod
curl -L -o Rotmod_LTG.zip https://astroweb.case.edu/SPARC/Rotmod_LTG.zip
rm -rf Rotmod_LTG
unzip -q Rotmod_LTG.zip -d Rotmod_LTG
find Rotmod_LTG -type f | head -n 20
