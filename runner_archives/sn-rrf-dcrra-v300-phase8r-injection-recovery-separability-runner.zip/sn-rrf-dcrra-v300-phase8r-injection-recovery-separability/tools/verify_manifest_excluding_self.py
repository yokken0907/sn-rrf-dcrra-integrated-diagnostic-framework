#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json
from pathlib import Path

root = Path('.').resolve()
manifest_csv = root / 'FILE_MANIFEST.csv'
manifest_json = root / 'manifest.json'
if not manifest_csv.exists():
    raise SystemExit('FAIL: FILE_MANIFEST.csv not found')
rows = []
with manifest_csv.open(newline='', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        rows.append(row)
errors = []
for row in rows:
    rel = row['path']
    if rel in {'FILE_MANIFEST.csv', 'manifest.json'}:
        continue
    p = root / rel
    if not p.exists():
        errors.append(f'missing: {rel}')
        continue
    h = hashlib.sha256(p.read_bytes()).hexdigest()
    if h != row['sha256']:
        errors.append(f'sha256 mismatch: {rel}')
if errors:
    print('FAIL-MANIFEST-VERIFICATION')
    for e in errors:
        print(e)
    raise SystemExit(1)
print('PASS-MANIFEST-VERIFICATION')
print(f'verified_files={sum(1 for r in rows if r["path"] not in {"FILE_MANIFEST.csv", "manifest.json"})}')
