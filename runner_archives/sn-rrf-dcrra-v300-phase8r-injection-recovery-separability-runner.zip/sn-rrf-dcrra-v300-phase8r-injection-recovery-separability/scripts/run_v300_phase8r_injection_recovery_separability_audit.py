#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd

TYPES = [
    "RESPONSE_FAMILY_LIKE",
    "HALO_LIKE",
    "RAR_LIKE",
    "NUISANCE_GRADIENT",
    "PATHOLOGY_OUTLIER",
    "MIXED_RESPONSE_HALO",
]
PHYSICAL_LIKE = ["RESPONSE_FAMILY_LIKE", "HALO_LIKE", "RAR_LIKE", "MIXED_RESPONSE_HALO"]


def find_phase8_dir() -> Path:
    candidates = [
        Path("outputs_v3_0_0_phase8"),
        Path("../outputs_v3_0_0_phase8"),
        Path("../v3_0_0_phase8_injection_recovery_null_tests_replay/outputs_v3_0_0_phase8"),
        Path("../v3_0_0_phase8_injection_recovery_null_tests_replay/outputs_v3_0_0_phase8"),
    ]
    for p in candidates:
        if (p / "phase8_injection_recovery_results.csv").exists():
            return p
    raise FileNotFoundError("Could not locate outputs_v3_0_0_phase8/phase8_injection_recovery_results.csv")


def ensure_out() -> Path:
    out = Path("outputs_v3_0_0_phase8r")
    out.mkdir(parents=True, exist_ok=True)
    return out


def add_score_margins(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    rss_cols = [f"rss_{t}" for t in TYPES]
    corr_cols = [f"corr_{t}" for t in TYPES]
    rss = df[rss_cols].to_numpy(float)
    corr = df[corr_cols].to_numpy(float)

    order = np.argsort(rss, axis=1)
    min1 = np.take_along_axis(rss, order[:, :1], axis=1).ravel()
    min2 = np.take_along_axis(rss, order[:, 1:2], axis=1).ravel()
    df["rss_winner"] = [TYPES[i] for i in order[:, 0]]
    df["rss_margin_best_vs_second"] = min2 - min1

    corr_order = np.argsort(-corr, axis=1)
    max1 = np.take_along_axis(corr, corr_order[:, :1], axis=1).ravel()
    max2 = np.take_along_axis(corr, corr_order[:, 1:2], axis=1).ravel()
    df["corr_winner"] = [TYPES[i] for i in corr_order[:, 0]]
    df["corr_margin_best_vs_second"] = max1 - max2

    true_rss = []
    best_wrong_rss = []
    true_corr = []
    best_wrong_corr = []
    for _, row in df.iterrows():
        t = row["injection_type"]
        true_rss.append(float(row[f"rss_{t}"]))
        best_wrong_rss.append(min(float(row[f"rss_{x}"]) for x in TYPES if x != t))
        true_corr.append(float(row[f"corr_{t}"]))
        best_wrong_corr.append(max(float(row[f"corr_{x}"]) for x in TYPES if x != t))
    df["rss_true_minus_best_wrong"] = np.array(true_rss) - np.array(best_wrong_rss)
    df["rss_correct_margin"] = np.array(best_wrong_rss) - np.array(true_rss)
    df["corr_true_minus_best_wrong"] = np.array(true_corr) - np.array(best_wrong_corr)
    df["rss_margin_positive"] = df["rss_correct_margin"] > 0
    df["corr_margin_positive"] = df["corr_true_minus_best_wrong"] > 0
    return df


def confusion_pairwise(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby(["injection_type", "predicted_type"]).size().reset_index(name="n")
    totals = df.groupby("injection_type").size().to_dict()
    g["row_fraction"] = g.apply(lambda r: r["n"] / totals[r["injection_type"]], axis=1)
    off = g[g["injection_type"] != g["predicted_type"]].copy()
    off = off.sort_values(["n", "row_fraction"], ascending=False)
    return off


def classifier_variant_results(df: pd.DataFrame) -> pd.DataFrame:
    records = []

    def score_variant(name: str, pred: pd.Series | np.ndarray, subset: pd.Series | None = None):
        if subset is None:
            subset = pd.Series(True, index=df.index)
        d = df.loc[subset].copy()
        p = pd.Series(pred, index=df.index).loc[subset]
        if len(d) == 0:
            return
        acc = float((p.to_numpy() == d["injection_type"].to_numpy()).mean())
        recalls = []
        for t in TYPES:
            dd = d[d["injection_type"] == t]
            if len(dd):
                pp = p.loc[dd.index]
                recalls.append(float((pp.to_numpy() == dd["injection_type"].to_numpy()).mean()))
        records.append({
            "variant": name,
            "n": int(len(d)),
            "coverage": float(len(d) / len(df)),
            "accuracy": acc,
            "balanced_accuracy": float(np.mean(recalls)) if recalls else np.nan,
            "min_class_recall": float(np.min(recalls)) if recalls else np.nan,
        })

    score_variant("phase8_reported_predicted_type", df["predicted_type"])
    score_variant("rss_minimum_type", df["rss_winner"])
    score_variant("corr_maximum_type", df["corr_winner"])

    # Hybrid: use pathology/nuisance correlation winners when confidently top-ranked, else RSS.
    pred = df["rss_winner"].copy()
    corr_margin = df["corr_margin_best_vs_second"]
    pred[(df["corr_winner"] == "PATHOLOGY_OUTLIER") & (corr_margin >= corr_margin.quantile(0.50))] = "PATHOLOGY_OUTLIER"
    pred[(df["corr_winner"] == "NUISANCE_GRADIENT") & (corr_margin >= corr_margin.quantile(0.50))] = "NUISANCE_GRADIENT"
    score_variant("hybrid_corr_pathology_nuisance_then_rss", pred)

    for noise in ["LOW", "MEDIUM", "HIGH"]:
        score_variant(f"reported_only_noise_{noise}", df["predicted_type"], df["noise_level"] == noise)

    # Selective confidence by RSS margin quantiles: abstain from low margin cases.
    qs = [0.00, 0.25, 0.50, 0.75]
    for q in qs:
        threshold = float(df["rss_margin_best_vs_second"].quantile(q))
        subset = df["rss_margin_best_vs_second"] >= threshold
        score_variant(f"selective_rss_margin_q{q:.2f}", df["predicted_type"], subset)

    # Selective correct-margin is not usable operationally because it uses true label; record as diagnostic upper-bound.
    for q in [0.25, 0.50, 0.75]:
        threshold = float(df["rss_correct_margin"].quantile(q))
        subset = df["rss_correct_margin"] >= threshold
        score_variant(f"oracle_diagnostic_correct_margin_q{q:.2f}", df["predicted_type"], subset)

    return pd.DataFrame(records)


def by_type_margins(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for t, d in df.groupby("injection_type"):
        rows.append({
            "injection_type": t,
            "n": int(len(d)),
            "reported_recall": float(d["recovered"].mean()),
            "rss_margin_positive_fraction": float(d["rss_margin_positive"].mean()),
            "corr_margin_positive_fraction": float(d["corr_margin_positive"].mean()),
            "median_rss_correct_margin": float(d["rss_correct_margin"].median()),
            "median_corr_true_minus_best_wrong": float(d["corr_true_minus_best_wrong"].median()),
            "median_rss_best_second_margin": float(d["rss_margin_best_vs_second"].median()),
            "median_corr_best_second_margin": float(d["corr_margin_best_vs_second"].median()),
        })
    return pd.DataFrame(rows).sort_values("reported_recall")


def by_noise_background(df: pd.DataFrame) -> pd.DataFrame:
    group_cols = ["noise_level", "background_mix"]
    rows = []
    for keys, d in df.groupby(group_cols):
        noise, bg = keys
        rows.append({
            "noise_level": noise,
            "background_mix": bg,
            "n": int(len(d)),
            "recovery_rate": float(d["recovered"].mean()),
            "median_rss_correct_margin": float(d["rss_correct_margin"].median()),
            "rss_margin_positive_fraction": float(d["rss_margin_positive"].mean()),
        })
    return pd.DataFrame(rows).sort_values(["noise_level", "background_mix"])


def confidence_tradeoff(df: pd.DataFrame) -> pd.DataFrame:
    records = []
    for metric in ["rss_margin_best_vs_second", "corr_margin_best_vs_second"]:
        for q in np.linspace(0, 0.9, 10):
            thr = float(df[metric].quantile(q))
            sub = df[df[metric] >= thr]
            records.append({
                "confidence_metric": metric,
                "quantile_threshold": float(q),
                "threshold_value": thr,
                "n": int(len(sub)),
                "coverage": float(len(sub) / len(df)),
                "recovery_rate": float(sub["recovered"].mean()) if len(sub) else np.nan,
                "balanced_accuracy_proxy": float(sub.groupby("injection_type")["recovered"].mean().mean()) if len(sub) else np.nan,
            })
    return pd.DataFrame(records)


def write_report(out: Path, decision: dict, weakest_pairs: pd.DataFrame, type_margins: pd.DataFrame, variants: pd.DataFrame):
    lines = []
    lines.append("# Phase 8R Injection-Recovery Diagnostic Separability Audit\n")
    lines.append("## Decision\n")
    lines.append(f"`{decision['decision']}`\n")
    lines.append(f"Interpretation: **{decision['interpretation']}**\n")
    lines.append("## Main metrics\n")
    for k in [
        "phase8_overall_recovery_rate", "phase8_balanced_accuracy", "best_operational_variant", "best_operational_variant_balanced_accuracy", "best_full_coverage_operational_variant", "best_full_coverage_operational_balanced_accuracy",
        "low_noise_recovery_rate", "high_noise_recovery_rate", "physical_like_mean_recall", "pathology_nuisance_mean_recall",
        "top_offdiagonal_pair", "top_offdiagonal_fraction", "guard_pass_count", "guard_count", "external_validation",
    ]:
        lines.append(f"- {k}: {decision.get(k)}")
    lines.append("\n## Weakest confusion pairs\n")
    lines.append(weakest_pairs.head(10).to_markdown(index=False))
    lines.append("\n## By-type margins\n")
    lines.append(type_margins.to_markdown(index=False))
    lines.append("\n## Classifier variants\n")
    lines.append(variants.to_markdown(index=False))
    lines.append("\n## Claim boundary\n")
    lines.append("Phase 8R is an internal synthetic-control separability audit. It does not establish a physical dark-sector model, does not exclude dark matter, does not falsify MOND/RAR or NFW, and does not remove the non-SPARC external-data HOLD.\n")
    (out / "PHASE8R_REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    phase8 = find_phase8_dir()
    out = ensure_out()
    df = pd.read_csv(phase8 / "phase8_injection_recovery_results.csv")
    metric = json.loads((phase8 / "phase8_metric_summary.json").read_text(encoding="utf-8"))
    df = add_score_margins(df)

    pair = confusion_pairwise(df)
    type_m = by_type_margins(df)
    noise_bg = by_noise_background(df)
    variants = classifier_variant_results(df)
    tradeoff = confidence_tradeoff(df)

    pair.to_csv(out / "phase8r_pairwise_confusion_offdiagonal.csv", index=False)
    type_m.to_csv(out / "phase8r_type_margin_separability.csv", index=False)
    noise_bg.to_csv(out / "phase8r_noise_background_sensitivity.csv", index=False)
    variants.to_csv(out / "phase8r_classifier_variant_results.csv", index=False)
    tradeoff.to_csv(out / "phase8r_confidence_coverage_tradeoff.csv", index=False)
    df.to_csv(out / "phase8r_casewise_margin_table.csv", index=False)

    recall_by_type = df.groupby("injection_type")["recovered"].mean().to_dict()
    physical_mean = float(np.mean([recall_by_type[t] for t in PHYSICAL_LIKE]))
    pn_mean = float(np.mean([recall_by_type[t] for t in ["PATHOLOGY_OUTLIER", "NUISANCE_GRADIENT"]]))
    top_pair = pair.iloc[0] if len(pair) else None
    operational_variants = variants[~variants["variant"].str.startswith("oracle_")].copy()
    best_variant_row = operational_variants.sort_values("balanced_accuracy", ascending=False).iloc[0]
    full_coverage_variants = operational_variants[operational_variants["coverage"] >= 0.99].copy()
    best_full_coverage_row = full_coverage_variants.sort_values("balanced_accuracy", ascending=False).iloc[0]
    selective_ok = operational_variants[(operational_variants["coverage"] >= 0.50) & (operational_variants["balanced_accuracy"] >= 0.70)]

    guards = {
        "best_full_coverage_operational_balanced_accuracy_ge_0_65": bool(best_full_coverage_row["balanced_accuracy"] >= 0.65),
        "best_operational_balanced_accuracy_ge_0_70_at_coverage_ge_0_50": bool(len(selective_ok) > 0),
        "low_noise_recovery_ge_0_70": bool(df[df["noise_level"] == "LOW"]["recovered"].mean() >= 0.70),
        "physical_like_mean_recall_ge_0_50": bool(physical_mean >= 0.50),
        "pathology_nuisance_mean_recall_ge_0_75": bool(pn_mean >= 0.75),
        "high_noise_recovery_ge_0_45": bool(metric.get("high_noise_recovery_rate", 0) >= 0.45),
        "top_offdiagonal_fraction_le_0_25": bool((top_pair["row_fraction"] if top_pair is not None else 0) <= 0.25),
    }
    guard_pass_count = int(sum(guards.values()))
    guard_count = len(guards)

    if guard_pass_count >= 5:
        status = "PASS_WITH_BOUNDARY_CAUTIONS"
        interpretation = "DIAGNOSTIC-SEPARABILITY-PARTIALLY-REPAIRED"
    elif guard_pass_count >= 3:
        status = "MIXED"
        interpretation = "LIMITED-SEPARABILITY-WITH-PERSISTENT-CONFUSION"
    else:
        status = "FAIL_OR_NULL"
        interpretation = "SEPARABILITY-LIMITATION-PERSISTS"

    decision = {
        "phase": "v3.0.0 Phase 8R Injection-Recovery Diagnostic Separability Audit",
        "status": status,
        "interpretation": interpretation,
        "phase8_status": metric.get("status"),
        "feature_rows": 143,
        "synthetic_case_count": int(len(df)),
        "phase8_overall_recovery_rate": float(metric.get("overall_recovery_rate")),
        "phase8_balanced_accuracy": float(metric.get("balanced_accuracy")),
        "low_noise_recovery_rate": float(df[df["noise_level"] == "LOW"]["recovered"].mean()),
        "medium_noise_recovery_rate": float(df[df["noise_level"] == "MEDIUM"]["recovered"].mean()),
        "high_noise_recovery_rate": float(df[df["noise_level"] == "HIGH"]["recovered"].mean()),
        "physical_like_mean_recall": physical_mean,
        "pathology_nuisance_mean_recall": pn_mean,
        "best_operational_variant": str(best_variant_row["variant"]),
        "best_operational_variant_balanced_accuracy": float(best_variant_row["balanced_accuracy"]),
        "best_operational_variant_accuracy": float(best_variant_row["accuracy"]),
        "best_full_coverage_operational_variant": str(best_full_coverage_row["variant"]),
        "best_full_coverage_operational_balanced_accuracy": float(best_full_coverage_row["balanced_accuracy"]),
        "best_full_coverage_operational_accuracy": float(best_full_coverage_row["accuracy"]),
        "top_offdiagonal_pair": None if top_pair is None else f"{top_pair['injection_type']}->{top_pair['predicted_type']}",
        "top_offdiagonal_count": None if top_pair is None else int(top_pair["n"]),
        "top_offdiagonal_fraction": None if top_pair is None else float(top_pair["row_fraction"]),
        "guard_pass_count": guard_pass_count,
        "guard_count": guard_count,
        "guards": guards,
        "external_validation": "HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE",
        "claim_boundary": "Internal synthetic-control separability audit only; not a physical classification and not non-SPARC external validation.",
        "decision": f"LOCK-PHASE8R-INJECTION-RECOVERY-SEPARABILITY-AUDIT-{status}",
    }

    (out / "phase8r_decision.json").write_text(json.dumps(decision, indent=2), encoding="utf-8")
    summary = {
        **decision,
        "by_type_recall": {k: float(v) for k, v in recall_by_type.items()},
    }
    (out / "phase8r_metric_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    text = [decision["decision"], f"interpretation: {interpretation}"]
    for k in ["synthetic_case_count", "phase8_overall_recovery_rate", "phase8_balanced_accuracy", "best_operational_variant", "best_operational_variant_balanced_accuracy", "best_full_coverage_operational_variant", "best_full_coverage_operational_balanced_accuracy", "physical_like_mean_recall", "pathology_nuisance_mean_recall", "top_offdiagonal_pair", "top_offdiagonal_fraction", "guard_pass_count", "guard_count", "external_validation"]:
        text.append(f"{k}: {decision.get(k)}")
    (out / "V300_PHASE8R_DECISION.txt").write_text("\n".join(text)+"\n", encoding="utf-8")
    write_report(out, decision, pair, type_m, variants)

    print(decision["decision"])
    print(f"phase8r_status={status}")
    print(f"interpretation={interpretation}")
    print(f"synthetic_case_count={len(df)}")
    print(f"phase8_balanced_accuracy={decision['phase8_balanced_accuracy']:.6f}")
    print(f"best_operational_variant={decision['best_operational_variant']}")
    print(f"best_operational_variant_balanced_accuracy={decision['best_operational_variant_balanced_accuracy']:.6f}")
    print(f"best_full_coverage_operational_variant={decision['best_full_coverage_operational_variant']}")
    print(f"best_full_coverage_operational_balanced_accuracy={decision['best_full_coverage_operational_balanced_accuracy']:.6f}")
    print(f"physical_like_mean_recall={physical_mean:.6f}")
    print(f"pathology_nuisance_mean_recall={pn_mean:.6f}")
    print(f"guards_passed={guard_pass_count}/{guard_count}")
    print(f"external_validation={decision['external_validation']}")


if __name__ == "__main__":
    main()
