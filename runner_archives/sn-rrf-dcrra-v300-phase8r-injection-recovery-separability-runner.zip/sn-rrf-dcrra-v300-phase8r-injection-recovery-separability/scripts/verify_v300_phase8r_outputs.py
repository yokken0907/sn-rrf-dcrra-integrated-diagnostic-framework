#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

out = Path("outputs_v3_0_0_phase8r")
required = [
    "phase8r_decision.json",
    "phase8r_metric_summary.json",
    "phase8r_pairwise_confusion_offdiagonal.csv",
    "phase8r_type_margin_separability.csv",
    "phase8r_noise_background_sensitivity.csv",
    "phase8r_classifier_variant_results.csv",
    "phase8r_confidence_coverage_tradeoff.csv",
    "phase8r_casewise_margin_table.csv",
    "PHASE8R_REPORT.md",
    "V300_PHASE8R_DECISION.txt",
]
missing = [f for f in required if not (out/f).exists()]
if missing:
    raise SystemExit(f"FAIL: missing Phase8R output files: {missing}")

decision = json.loads((out/"phase8r_decision.json").read_text(encoding="utf-8"))
case = pd.read_csv(out/"phase8r_casewise_margin_table.csv")
variants = pd.read_csv(out/"phase8r_classifier_variant_results.csv")
if len(case) != int(decision["synthetic_case_count"]):
    raise SystemExit("FAIL: casewise row count mismatch")
if len(variants) < 5:
    raise SystemExit("FAIL: too few classifier variants")
if decision.get("external_validation") != "HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE":
    raise SystemExit("FAIL: external validation status unexpectedly changed")
if decision.get("status") not in {"PASS_WITH_BOUNDARY_CAUTIONS", "MIXED", "FAIL_OR_NULL"}:
    raise SystemExit("FAIL: invalid status")
print("PASS-V300-PHASE8R-OUTPUT-VERIFICATION")
print(f"phase8r_status={decision['status']}")
print(f"interpretation={decision['interpretation']}")
print(f"synthetic_case_count={decision['synthetic_case_count']}")
print(f"best_operational_variant={decision['best_operational_variant']}")
print(f"best_operational_variant_balanced_accuracy={decision['best_operational_variant_balanced_accuracy']:.6f}")
print(f"best_full_coverage_operational_variant={decision['best_full_coverage_operational_variant']}")
print(f"best_full_coverage_operational_balanced_accuracy={decision['best_full_coverage_operational_balanced_accuracy']:.6f}")
print(f"guards_passed={decision['guard_pass_count']}/{decision['guard_count']}")
print(f"external_validation={decision['external_validation']}")
