# Phase 8R Scope and Claim Boundary

Phase 8R is an internal diagnostic separability audit of the Phase 8 synthetic injection-recovery outputs. It does not create new non-SPARC external evidence and does not revise the Phase 8 result into a physical-model claim.

Allowed interpretation:
- Determine whether the Phase 8 FAIL_OR_NULL result is driven by template proximity, noise sensitivity, background mixing, confidence-margin weakness, or classifier-rule limitations.
- Record whether limited repair variants improve diagnostic separability.
- Convert persistent failure modes into explicit failure-boundary evidence.

Forbidden interpretation:
- Dark matter exclusion.
- NFW, MOND, or RAR falsification.
- Physical dark-sector classification.
- Non-SPARC external validation.
- Promotion of SN-RRF/DCRRA into a physical model-selection winner.

The external residual-level validation branch remains HOLD until a non-SPARC radius-resolved baryonic component-curve table is available and passes manual source-material acceptance.
