# SN-RRF-DCRRA v3.0.0 Phase 8R Runner

## Phase 8R: Injection-Recovery Diagnostic Separability Audit

This package analyzes the Phase 8 `FAIL_OR_NULL` injection-recovery output and asks why recovery was insufficient.

It tests:
- pairwise confusion concentration;
- RSS/correlation margin separability;
- noise-level and background-mix sensitivity;
- confidence/abstention tradeoff;
- simple classifier variants using already-produced Phase 8 score columns.

This is an internal synthetic-control audit only. It does not remove the non-SPARC external-validation HOLD.

## Replay

```bash
python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase8r_injection_recovery_separability_audit.py
python scripts/verify_v300_phase8r_outputs.py
```

Expected final status is `LOCK-PHASE8R-INJECTION-RECOVERY-SEPARABILITY-AUDIT` with a PASS, MIXED, or FAIL_OR_NULL decision depending on reproduced metrics.
