# SN-RRF-DCRRA v3.0.0 Phase 5R: Overflex-Null Fairness Audit

Phase 5R audits whether the Phase 5 over-flexible null dominance remains stable after complexity penalties and radial predictive checks.

## Replay

```bash
python tools/verify_manifest_excluding_self.py
python scripts/run_v300_phase5r_overflex_null_fairness_audit.py
python scripts/verify_v300_phase5r_outputs.py
```

This package is an internal SPARC diagnostic audit. External residual-level validation remains HOLD.
