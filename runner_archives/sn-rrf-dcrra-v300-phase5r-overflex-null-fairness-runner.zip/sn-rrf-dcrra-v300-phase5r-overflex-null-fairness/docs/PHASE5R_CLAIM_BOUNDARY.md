# Phase 5R Claim Boundary

Allowed: internal SPARC overflex-null fairness audit, complexity sensitivity, predictive radial checks.

Not claimed: dark-matter exclusion, MOND/RAR falsification, NFW falsification, Lambda-CDM replacement, new physics discovery, or non-SPARC external validation.
