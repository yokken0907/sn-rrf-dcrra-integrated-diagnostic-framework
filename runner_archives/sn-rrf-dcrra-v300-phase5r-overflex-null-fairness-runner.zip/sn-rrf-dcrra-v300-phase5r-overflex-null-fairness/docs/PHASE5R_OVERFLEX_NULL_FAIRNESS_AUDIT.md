# Phase 5R Overflex-Null Fairness and Complexity-Penalty Audit

This phase tests polynomial-null dominance under degree sweep, AIC/AICc/BIC, contiguous radial cross-validation, and odd-even radial split checks.

The purpose is failure-boundary refinement, not physical model selection.
