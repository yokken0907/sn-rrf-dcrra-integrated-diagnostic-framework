#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math
from pathlib import Path
import numpy as np
import pandas as pd

EPS = 1e-12

def log_safe(x):
    return math.log(max(float(x), EPS))

def aic(rss, n, k):
    return n * log_safe(rss / max(n, 1)) + 2 * k

def aicc(rss, n, k):
    base = aic(rss, n, k)
    denom = n - k - 1
    return float('inf') if denom <= 0 else base + (2 * k * (k + 1)) / denom

def bic(rss, n, k):
    return n * log_safe(rss / max(n, 1)) + k * log_safe(max(n, 1))

def poly_design(x, degree):
    return np.vander(x, N=degree + 1, increasing=True)

def fit_lstsq(X, y):
    try:
        coef, *_ = np.linalg.lstsq(X, y, rcond=None)
        pred = X @ coef
        return coef, pred, float(np.sum((y - pred) ** 2))
    except Exception:
        pred = np.full_like(y, float(np.nanmean(y)))
        return np.array([float(np.nanmean(y))]), pred, float(np.sum((y - pred) ** 2))

def comparator_k(name: str, params_json: str = '') -> int:
    if name == 'OVERFLEX_POLY5_NULL':
        return 6
    if name == 'SN_RRF_SATURATING_FAMILY':
        return 4
    if name in {'SN_RRF_LOCKED_N3_258993', 'NFW_LIKE_DIAGNOSTIC', 'RAR_LIKE_DIAGNOSTIC', 'BURKERT_LIKE_CORED_DIAGNOSTIC', 'CORED_ISOTHERMAL_LIKE_DIAGNOSTIC', 'EINASTO_LIKE_SURROGATE_DIAGNOSTIC'}:
        return 2
    if name in {'BARYONIC_MISMATCH_PROXY', 'NUISANCE_GRADIENT_PROXY'}:
        return 2
    return 2

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='.')
    args = ap.parse_args()
    root = Path(args.root).resolve()
    grid_path = root / 'outputs_v3_0_0_phase4ab' / 'phase4b_rotmod_residual_shape_grid_long.csv'
    winners_path = root / 'outputs_v3_0_0_phase5' / 'expanded_comparator_winners.csv'
    scores_path = root / 'outputs_v3_0_0_phase5' / 'expanded_comparator_scores_long.csv'
    for p in [grid_path, winners_path, scores_path]:
        if not p.exists():
            raise FileNotFoundError(p)
    grid = pd.read_csv(grid_path)
    winners = pd.read_csv(winners_path)
    phase5_scores = pd.read_csv(scores_path)
    out = root / 'outputs_v3_0_0_phase5r'
    out.mkdir(exist_ok=True)

    # 1) Re-score existing Phase 5 comparators with AICc/BIC using explicit k penalties.
    rescored = phase5_scores.copy()
    rescored['k_effective'] = [comparator_k(c, p) for c, p in zip(rescored['comparator'], rescored.get('params_json', [''] * len(rescored)))]
    rescored['aicc_recomputed'] = [aicc(r, n, k) for r, n, k in zip(rescored['rss'], rescored['rotmod_points'], rescored['k_effective'])]
    rescored['bic_recomputed'] = [bic(r, n, k) for r, n, k in zip(rescored['rss'], rescored['rotmod_points'], rescored['k_effective'])]

    # 2) Full-data polynomial degree sweep on the Phase 4B residual-shape grid.
    deg_rows = []
    for gal, g in grid.groupby('galaxy', sort=True):
        g = g.sort_values('s')
        x = g['s'].to_numpy(float)
        y = g['residual_norm_v2_proxy'].to_numpy(float)
        zone = str(g['zone'].iloc[0])
        npts = len(x)
        for degree in [1, 2, 3, 4, 5, 6]:
            coef, pred, rss = fit_lstsq(poly_design(x, degree), y)
            k = degree + 1
            deg_rows.append({
                'galaxy': gal,
                'zone': zone,
                'model': f'POLY{degree}_NULL',
                'degree': degree,
                'n_points': npts,
                'k_effective': k,
                'rss': rss,
                'aic': aic(rss, npts, k),
                'aicc': aicc(rss, npts, k),
                'bic': bic(rss, npts, k),
                'coef_json': json.dumps([float(c) for c in coef]),
            })
    degree_df = pd.DataFrame(deg_rows)

    # 3) Galaxy-level winners for existing comparator set under AIC/AICc/BIC.
    rows = []
    for gal, g in rescored.groupby('galaxy', sort=True):
        zone = str(g['zone'].iloc[0])
        row = {'galaxy': gal, 'zone': zone}
        for crit, col in [('aic', 'aic'), ('aicc', 'aicc_recomputed'), ('bic', 'bic_recomputed')]:
            best = g.loc[g[col].idxmin()]
            row[f'winner_existing_{crit}'] = str(best['comparator'])
            row[f'winner_existing_{crit}_family'] = str(best.get('comparator_family', ''))
            row[f'winner_existing_{crit}_score'] = float(best[col])
        dg = degree_df[degree_df['galaxy'] == gal]
        for crit in ['aic', 'aicc', 'bic']:
            bestd = dg.loc[dg[crit].idxmin()]
            row[f'winner_poly_degree_{crit}'] = str(bestd['model'])
            row[f'winner_poly_degree_{crit}_degree'] = int(bestd['degree'])
            row[f'winner_poly_degree_{crit}_score'] = float(bestd[crit])
        # prior phase5 state
        prior = winners[winners['galaxy'] == gal]
        if not prior.empty:
            row['phase5_winning_comparator'] = str(prior.iloc[0]['winning_comparator'])
            row['phase5_winning_comparator_family'] = str(prior.iloc[0]['winning_comparator_family'])
            row['phase5_overflex_winner'] = bool(prior.iloc[0]['winning_comparator'] == 'OVERFLEX_POLY5_NULL')
        else:
            row['phase5_winning_comparator'] = ''
            row['phase5_winning_comparator_family'] = ''
            row['phase5_overflex_winner'] = False
        rows.append(row)
    bygal = pd.DataFrame(rows)

    def vc(col):
        x = bygal[col].value_counts().rename_axis('winner').reset_index(name='count')
        x['fraction'] = x['count'] / len(bygal)
        x.insert(0, 'criterion', col)
        return x
    count_cols = [
        'winner_existing_aic', 'winner_existing_aicc', 'winner_existing_bic',
        'winner_poly_degree_aic', 'winner_poly_degree_aicc', 'winner_poly_degree_bic'
    ]
    counts = pd.concat([vc(c) for c in count_cols], ignore_index=True)

    zone_rows = []
    for zone, z in bygal.groupby('zone', sort=True):
        zr = {'zone': zone, 'galaxy_count': int(len(z)), 'phase5_overflex_winner_fraction': float(z['phase5_overflex_winner'].mean())}
        for col in count_cols:
            zr[f'{col}_overflex_poly5_fraction'] = float(z[col].eq('OVERFLEX_POLY5_NULL').mean() if 'existing' in col else z[col].eq('POLY5_NULL').mean())
            zr[f'{col}_poly6_fraction'] = float(z[col].eq('POLY6_NULL').mean())
        zone_rows.append(zr)
    zones = pd.DataFrame(zone_rows)

    def frac(col, val):
        return float(bygal[col].eq(val).mean())
    prior_over = float(bygal['phase5_overflex_winner'].mean())
    existing_aicc_over = frac('winner_existing_aicc', 'OVERFLEX_POLY5_NULL')
    existing_bic_over = frac('winner_existing_bic', 'OVERFLEX_POLY5_NULL')
    poly_aicc_poly5 = frac('winner_poly_degree_aicc', 'POLY5_NULL')
    poly_bic_poly5 = frac('winner_poly_degree_bic', 'POLY5_NULL')

    if prior_over >= 0.5 and (existing_bic_over < prior_over or poly_bic_poly5 < poly_aicc_poly5):
        interp = 'OVERFLEX-DOMINANCE-SENSITIVE-TO-COMPLEXITY-PENALTY'
    elif prior_over >= 0.5 and existing_bic_over >= 0.5 and poly_bic_poly5 >= 0.5:
        interp = 'OVERFLEX-DOMINANCE-PERSISTS-AFTER-COMPLEXITY-PENALTY'
    else:
        interp = 'NO-STRONG-OVERFLEX-DOMINANCE-AFTER-COMPLEXITY-PENALTY'

    decision = {
        'version': '3.0.0-phase5r-overflex-null-fairness',
        'status': 'PASS-PHASE5R-OVERFLEX-NULL-FAIRNESS-AUDIT-RUN',
        'interpretation': interp,
        'feature_rows': int(bygal.shape[0]),
        'existing_comparator_score_rows': int(rescored.shape[0]),
        'degree_sweep_score_rows': int(degree_df.shape[0]),
        'phase5_prior_overflex_winner_fraction': prior_over,
        'existing_set_overflex_fractions': {
            'aic': frac('winner_existing_aic', 'OVERFLEX_POLY5_NULL'),
            'aicc': existing_aicc_over,
            'bic': existing_bic_over,
        },
        'poly_degree_sweep_poly5_fractions': {
            'aic': frac('winner_poly_degree_aic', 'POLY5_NULL'),
            'aicc': poly_aicc_poly5,
            'bic': poly_bic_poly5,
        },
        'external_validation_status': 'HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE',
        'claim_boundary': 'Internal SPARC overflex-null fairness and complexity-penalty audit only; no physical model-selection claim.',
    }

    rescored.to_csv(out / 'phase5r_existing_comparator_aicc_bic_rescored.csv', index=False)
    degree_df.to_csv(out / 'phase5r_polynomial_degree_sweep_scores_long.csv', index=False)
    bygal.to_csv(out / 'phase5r_fairness_model_selection_by_galaxy.csv', index=False)
    counts.to_csv(out / 'phase5r_winner_counts_by_criterion.csv', index=False)
    zones.to_csv(out / 'phase5r_zone_fairness_summary.csv', index=False)
    (out / 'phase5r_decision.json').write_text(json.dumps(decision, indent=2, ensure_ascii=False), encoding='utf-8')
    report = f'''# Phase 5R Overflex-Null Fairness and Complexity-Penalty Audit

Status: `{decision['status']}`

Interpretation: `{interp}`

## Key metrics

- Phase 5 prior overflex winner fraction: `{prior_over:.6f}`
- Existing comparator overflex fraction under AIC: `{decision['existing_set_overflex_fractions']['aic']:.6f}`
- Existing comparator overflex fraction under AICc: `{existing_aicc_over:.6f}`
- Existing comparator overflex fraction under BIC: `{existing_bic_over:.6f}`
- Polynomial degree-sweep POLY5 fraction under AIC: `{decision['poly_degree_sweep_poly5_fractions']['aic']:.6f}`
- Polynomial degree-sweep POLY5 fraction under AICc: `{poly_aicc_poly5:.6f}`
- Polynomial degree-sweep POLY5 fraction under BIC: `{poly_bic_poly5:.6f}`

External residual-level validation remains HOLD.
'''
    (out / 'PHASE5R_REPORT.md').write_text(report, encoding='utf-8')
    txt = f'''PASS-PHASE5R-OVERFLEX-NULL-FAIRNESS-AUDIT-RUN
interpretation: {interp}
feature_rows: {bygal.shape[0]}
existing_comparator_score_rows: {rescored.shape[0]}
degree_sweep_score_rows: {degree_df.shape[0]}
phase5_prior_overflex_winner_fraction: {prior_over:.12f}
existing_aicc_overflex_fraction: {existing_aicc_over:.12f}
existing_bic_overflex_fraction: {existing_bic_over:.12f}
poly_degree_sweep_aicc_poly5_fraction: {poly_aicc_poly5:.12f}
poly_degree_sweep_bic_poly5_fraction: {poly_bic_poly5:.12f}
external_validation: HOLD_NON_SPARC_COMPONENT_CURVE_TABLE_NOT_AVAILABLE
claim_boundary: INTERNAL-SPARC-COMPLEXITY-PENALTY-AUDIT-ONLY; NO-PHYSICAL-MODEL-SELECTION-CLAIM
'''
    (out / 'V300_PHASE5R_DECISION.txt').write_text(txt, encoding='utf-8')

    print('PASS-PHASE5R-OVERFLEX-NULL-FAIRNESS-AUDIT-RUN')
    print(f'feature_rows={bygal.shape[0]}')
    print(f'existing_comparator_score_rows={rescored.shape[0]}')
    print(f'degree_sweep_score_rows={degree_df.shape[0]}')
    print(f'phase5_prior_overflex_winner_fraction={prior_over:.6f}')
    print(f'existing_aicc_overflex_fraction={existing_aicc_over:.6f}')
    print(f'existing_bic_overflex_fraction={existing_bic_over:.6f}')
    print(f'poly_degree_sweep_aicc_poly5_fraction={poly_aicc_poly5:.6f}')
    print(f'poly_degree_sweep_bic_poly5_fraction={poly_bic_poly5:.6f}')
    print(f'interpretation={interp}')
    print('external_validation=HOLD')

if __name__ == '__main__':
    main()
