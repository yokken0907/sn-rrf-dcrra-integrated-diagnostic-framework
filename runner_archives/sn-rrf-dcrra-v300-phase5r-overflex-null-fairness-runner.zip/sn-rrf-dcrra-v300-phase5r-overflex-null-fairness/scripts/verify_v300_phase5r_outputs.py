#!/usr/bin/env python3
from pathlib import Path
import json
import pandas as pd
root=Path('.').resolve()
out=root/'outputs_v3_0_0_phase5r'
required=[
 out/'phase5r_existing_comparator_aicc_bic_rescored.csv',
 out/'phase5r_polynomial_degree_sweep_scores_long.csv',
 out/'phase5r_fairness_model_selection_by_galaxy.csv',
 out/'phase5r_winner_counts_by_criterion.csv',
 out/'phase5r_zone_fairness_summary.csv',
 out/'phase5r_decision.json',
 out/'PHASE5R_REPORT.md',
 out/'V300_PHASE5R_DECISION.txt',
]
missing=[str(p) for p in required if not p.exists()]
if missing:
    print('FAIL-V300-PHASE5R-OUTPUT-VERIFICATION')
    print('missing:', missing)
    raise SystemExit(1)
decision=json.loads((out/'phase5r_decision.json').read_text(encoding='utf-8'))
bygal=pd.read_csv(out/'phase5r_fairness_model_selection_by_galaxy.csv')
degree=pd.read_csv(out/'phase5r_polynomial_degree_sweep_scores_long.csv')
rescored=pd.read_csv(out/'phase5r_existing_comparator_aicc_bic_rescored.csv')
counts=pd.read_csv(out/'phase5r_winner_counts_by_criterion.csv')
errors=[]
if decision.get('status')!='PASS-PHASE5R-OVERFLEX-NULL-FAIRNESS-AUDIT-RUN': errors.append('bad_status')
if int(decision.get('feature_rows',-1))!=143: errors.append('feature_rows_not_143')
if bygal.shape[0]!=143: errors.append('bygal_rows_not_143')
if degree['galaxy'].nunique()!=143: errors.append('degree_galaxy_count_not_143')
if degree['model'].nunique()!=6: errors.append('degree_model_count_not_6')
if rescored['galaxy'].nunique()!=143: errors.append('rescored_galaxy_count_not_143')
if counts['criterion'].nunique()!=6: errors.append('criteria_count_not_6')
if 'HOLD' not in decision.get('external_validation_status',''): errors.append('external_validation_not_hold')
if errors:
    print('FAIL-V300-PHASE5R-OUTPUT-VERIFICATION')
    for e in errors: print('error:', e)
    raise SystemExit(1)
print('PASS-V300-PHASE5R-OUTPUT-VERIFICATION')
print(f'feature_rows={bygal.shape[0]}')
print(f'existing_comparator_score_rows={rescored.shape[0]}')
print(f'degree_sweep_score_rows={degree.shape[0]}')
print(f'criteria_count={counts["criterion"].nunique()}')
print(f'interpretation={decision.get("interpretation")}')
print('external_validation=HOLD')
