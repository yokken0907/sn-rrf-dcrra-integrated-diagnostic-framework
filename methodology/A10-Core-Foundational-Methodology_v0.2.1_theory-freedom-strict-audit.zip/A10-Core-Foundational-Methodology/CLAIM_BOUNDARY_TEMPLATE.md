# Claim Boundary Template v0.2.1

## Status

```text
[ ] Bold exploratory hypothesis
[ ] Reduced-surrogate result
[ ] Pilot diagnostic
[ ] Null result
[ ] Failure archive
[ ] Methodology component
[ ] Publication candidate
```

## Allowed claims

```text
-
```

## Forbidden claims

```text
-
```

## Untested regions

```text
-
```

## Required future work

```text
-
```

## Wording

Allowed: claim-bounded, evaluation-only, exploratory, reduced surrogate, minimal testable kernel, pilot diagnostic, failure archive, null result, within tested scope.

Avoid unless independently justified: proven, solved, validated, safe, certified, practical, production-ready, commercial-ready, expert replacement, physical discovery, universal theory.
