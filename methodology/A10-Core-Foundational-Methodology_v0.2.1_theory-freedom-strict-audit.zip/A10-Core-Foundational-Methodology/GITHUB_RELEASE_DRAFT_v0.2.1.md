# GitHub Release Draft v0.2.1

## Tag

```text
v0.2.1
```

## Release title

```text
A10 Core Foundational Methodology v0.2.1 — Theory-Freedom / Claim-Boundary Clarification
```

## Release notes

This release clarifies the A10 Core operating principle for future theory-construction threads.

A10 Core permits bold and speculative theory construction, but it does not permit unsupported public claims. The added directive is:

```text
This directive expands theory-construction freedom, not claim-making permission.
Speculative hypotheses may enter the protocol, but only evidence-bounded claims may exit it.
```

Japanese:

```text
本指令は、理論構築の自由度を拡張するものであり、未検証主張の許可ではない。
投機的仮説はプロトコルへ入れてよいが、外へ出せるのは証拠範囲に限定された主張だけである。
```

### Added

- `A10_THEORY_FREEDOM_STRICT_AUDIT_DIRECTIVE_v0.2.1.md`
- reusable thread-start directive block
- manifest verification helper

### Updated

- README and operational-principle wording
- theory-construction template
- claim-boundary publication gate
- release metadata and Zenodo helper metadata

### Claim boundary

This repository is a methodology package. It does not validate any specific theory, establish physical discovery, certify safety, prove practical readiness, replace domain expertise, or authorize unsupported claims.

### Release consistency checks

```text
GitHub release tag = v0.2.1
CITATION.cff version = "0.2.1"
manifest.json version = "0.2.1"
zenodo_v0.2.1.json version = "0.2.1"
No DOI field in Zenodo helper metadata
```
