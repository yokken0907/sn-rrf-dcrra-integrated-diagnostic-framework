# Relationship between A10 Core v0.2.1 and A10-ELP

A10 Core is the foundational methodology. A10-ELP is the downstream evidence-led protocol for reading, auditing, and triaging artifacts.

Version 0.2.1 does not make A10-ELP more permissive about public claims. Instead, it gives A10-ELP a clearer distinction:

```text
Bold exploration may be acceptable upstream.
Unsupported public claims remain unacceptable downstream.
```

## A10-ELP review targets

A10-ELP should inspect whether an artifact identifies exploratory status, defines mission variables, maps failure boundaries, uses comparators or nulls, preserves failures and nulls, and avoids unsupported practical, safety, expert-replacement, or discovery claims.


---

## v0.2.1 clarification

The v0.2.1 directive expands entry-side theory-construction freedom. It does not relax evidence handling, moderation, audit discipline, or public claim boundaries.
