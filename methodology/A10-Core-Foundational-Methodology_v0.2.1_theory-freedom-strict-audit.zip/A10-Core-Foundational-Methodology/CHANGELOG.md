# Changelog

## v0.2.1

- Added explicit theory-freedom / strict-audit startup directive.
- Clarified that A10 expands theory-construction freedom, not claim-making permission.
- Added reusable prompt block for new A10 theory-construction threads.
- Updated theory-construction template and publication gate to prevent confusion between exploratory inputs and established outputs.
- Preserved strict PASS / FAIL / NULL / HOLD / ARCHIVE separation.
- Regenerated manifest, checksums, Zenodo helper metadata, and release draft with aligned version `0.2.1`.

## v0.2.0

- Reframed A10 Core as Bold Hypothesis + Strict Process + Bounded Claim.
- Added exploratory validation protocol.
- Added failure/null/archive policy.
- Added claim-boundary publication gate.
- Updated templates and relation documents.
- Added methodology manuscript draft in Markdown and LaTeX.
- Added Zenodo release guide emphasizing CITATION.cff / release tag version alignment.
