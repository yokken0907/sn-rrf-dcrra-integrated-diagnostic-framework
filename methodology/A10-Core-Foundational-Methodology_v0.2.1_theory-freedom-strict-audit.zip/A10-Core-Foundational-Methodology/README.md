# A10 Core Foundational Methodology

**Version:** 0.2.1  
**Core principle:** Bold Hypothesis + Strict Process + Bounded Claim  
**Japanese:** 大胆な仮説 + 厳格な工程 + 限定された主張  
**Author:** Keiji Yoshimura  
**Repository archive history:** `10.5281/zenodo.20343694`

---

## Overview

A10 Core is a claim-bounded methodology for constructing, testing, failing, archiving, and communicating theory candidates under uncertainty.

Version 0.2.1 is a clarification revision of the v0.2.x A10 Core operating standard. It preserves the v0.2.x separation between bold exploration and bounded public claims, while making the startup directive explicit for new theory-construction threads:

```text
A10 does not suppress bold hypotheses.
A10 suppresses uncontrolled claims.
```


Version 0.2.1 adds an explicit directive:

```text
This directive expands theory-construction freedom, not claim-making permission.
Speculative hypotheses may enter the protocol, but only evidence-bounded claims may exit it.
```

Japanese:

```text
本指令は、理論構築の自由度を拡張するものであり、未検証主張の許可ではない。
投機的仮説はプロトコルへ入れてよいが、外へ出せるのは証拠範囲に限定された主張だけである。
```

Therefore, A10 permits ambitious theory proposal, exploratory validation, failure-prone reduced-surrogate modeling, AI-assisted hypothesis generation, and risky pilot testing, provided that all such work remains inside strict process control, evidence logging, failure/null archiving, and bounded public claims.

---

## What A10 Core does

A10 Core transforms uncertain targets into auditable candidates by defining:

- mission variables;
- failure boundaries and dominant bottlenecks;
- reduced surrogates / minimal testable kernels;
- structured priors, gates, and barriers;
- comparator, null, negative-control, destructive-null, and stress-test plans;
- evidence ledgers;
- failure / null / hold / archive records;
- claim-boundary publication gates;
- human-margin-oriented final synthesis.
- reusable thread-start directive for high-freedom theory construction under strict audit.

---

## What changed in v0.2.1

| Layer | Previous tendency | v0.2.1 standard |
|---|---|---|
| Hypothesis generation | restrained early | bold exploration permitted |
| Risky theory candidates | often avoided | accepted into controlled protocol |
| Exploratory validation | conservative | active and failure-tolerant |
| Failure / NULL | preserved | first-class epistemic output |
| Process control | strict | strict |
| Evidence handling | strict | strict |
| Public claims | bounded | bounded |
| Public wording | conservative | conservative |

This is not a relaxation of claim boundaries. It is a separation between exploration freedom and publication discipline.

---

## Non-claims

This repository does not claim that A10 Core:

- is a universal theory;
- validates any generated theory automatically;
- replaces domain expertise;
- replaces experiments, measurements, peer review, safety review, or regulatory judgment;
- proves practical readiness;
- proves production readiness;
- proves safety;
- provides certification;
- establishes physical discovery;
- solves social or political problems;
- justifies unsafe deployment or human exhaustion.

---

## Relation to A10-ROS and A10-ELP

```text
A10 Core = foundational methodology
A10-ROS  = upstream research-construction protocol
A10-ELP  = downstream evidence-led audit / moderation protocol
Applied A10 theories = implementation examples
```

A10-ROS may intake bold hypotheses into controlled exploratory construction. A10-ELP remains strict about evidence-claim correspondence and public claim boundaries.

---

## Critical Zenodo release rule

Before release, verify:

```text
GitHub release tag = v0.2.1
CITATION.cff version = "0.2.1"
manifest.json version = "0.2.1"
```

Do **not** include a `doi` field in Zenodo metadata. If using GitHub-Zenodo integration, align `CITATION.cff` version, helper metadata version, and GitHub release tag before release. This package includes `zenodo_v0.2.1.json` as a helper metadata file, not as a mandatory `.zenodo.json`.
