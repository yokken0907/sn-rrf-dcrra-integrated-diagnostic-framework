# Jxiv Submission Metadata Draft for A10 Core v0.2.1

## 1. ファイル名

```text
a10_core_v0_2_1_methodology_note.pdf
```

## 2. タイトル

### 日本語

```text
A10 Core：大胆な理論探索と厳格な主張境界を両立する理論構築方法論
```

### English

```text
A10 Core: A Claim-Bounded Methodology for Bold Theory Exploration under Strict Process Control
```

## 3. サブタイトル

### 日本語

```text
Bold Hypothesis + Strict Process + Bounded Claim に基づくA10基礎方法論
```

### English

```text
An A10 Foundational Methodology Based on Bold Hypothesis + Strict Process + Bounded Claim
```

## 4. 抄録

### 日本語

```text
本稿は、A10 Coreを「大胆な理論探索」と「厳格な工程管理・主張境界」を両立させるための理論構築方法論として提示する。

従来のA10運用では、言えることと言えないことを厳密に切り分ける姿勢が強く、その結果として、可能性を持つが危うい理論候補を探索段階から抑制し過ぎる危険があった。

本改訂では、A10の役割を「大胆な仮説を抑制すること」ではなく、「制御されていない主張を抑制すること」として再定義する。

A10 Coreは、大胆な理論提唱、探索的検証、危うさを含む縮約モデル構築、AI支援による仮説生成、失敗可能性の高いパイロット検証を許容する。ただし、それらは監査可能な工程管理の内部に隔離されなければならない。

A10 Coreは万能理論でも専門家代替でもなく、大胆な理論可能性を、限定され、監査可能で、責任ある研究候補へ変換するための方法論的文法である。
```

### English

```text
This paper presents A10 Core as a claim-bounded methodology for bold theory exploration under strict process control.

Earlier formulations of A10 emphasized the separation between what may and may not be claimed, sometimes risking the premature suppression of speculative but potentially valuable theory candidates.

This revision clarifies a different operational distinction: A10 does not suppress bold hypotheses; it suppresses uncontrolled claims.

A10 Core allows ambitious theory proposal, exploratory validation, risky reduced-surrogate construction, AI-assisted hypothesis generation, and failure-prone pilot testing, provided that these activities are isolated within auditable process control.

A10 Core is neither a universal theory nor a replacement for domain expertise. It is a methodological grammar for converting bold theoretical possibility into bounded, inspectable, and responsibly communicated research candidates.
```

## 5. COI

### 日本語

```text
本稿に関して申告すべき利益相反はない。
```

### English

```text
The author declares no conflicts of interest regarding this manuscript.
```

## 6. キーワード

### 日本語

```text
A10 Core、理論構築、主張境界、大胆な仮説、工程管理、縮約モデル、null比較、証拠台帳、失敗アーカイブ、AI支援研究、人間の余白
```

### English

```text
A10 Core; theory construction; claim boundary; bold hypothesis; strict process control; reduced surrogate; null comparator; evidence ledger; failure archive; AI-assisted research; human margin
```

## 7. 参考文献

```text
[1] Yoshimura, K.,
A10 Core Foundational Methodology: A Claim-Bounded Framework for Verifiable Theory Construction under Uncertainty,
independent research repository package, 2026.
DOI: 10.5281/zenodo.20343694.

[2] Yoshimura, K.,
A10-Core-Foundational-Methodology,
GitHub repository, 2026.
URL: repository URL to be supplied in final submission metadata.
```


## v0.2.1 revision note

This revision clarifies that A10 Core expands theory-construction freedom while preserving strict audit discipline and bounded public claims. It does not authorize unsupported claims or relax validation requirements.
