# A10 Core: A Claim-Bounded Methodology for Bold Theory Exploration under Strict Process Control

**Draft version:** 0.2.1  
**Author:** Keiji Yoshimura  
**Known Zenodo DOI record:** 10.5281/zenodo.20343694

## Japanese Title

A10 Core：大胆な理論探索と厳格な主張境界を両立する理論構築方法論

## English Title

A10 Core: A Claim-Bounded Methodology for Bold Theory Exploration under Strict Process Control

## Abstract

This paper presents A10 Core as a claim-bounded methodology for bold theory exploration under strict process control. Earlier formulations of A10 emphasized the separation between what may and may not be claimed, sometimes risking the premature suppression of speculative but potentially valuable theory candidates. This revision clarifies a different operational distinction: A10 does not suppress bold hypotheses; it suppresses uncontrolled claims.

The proposed methodology allows ambitious theory proposal, exploratory validation, risky reduced-surrogate construction, AI-assisted hypothesis generation, and failure-prone pilot testing, provided that these activities are isolated within auditable process control. A10 Core requires mission-variable definition, failure-boundary extraction, reduced-surrogate or minimal-testable-kernel design, structured priors, gates, barriers, comparator and null design, evidence ledgers, failure/null archives, and claim-boundary publication gates.

A10 therefore treats failure, null, hold, and archive outcomes as first-class epistemic outputs. A failed exploratory route may still produce a useful failure boundary, negative control, rejected mechanism, or future comparator. Conversely, a successful exploratory result does not authorize practical readiness, safety certification, expert replacement, physical discovery, or field validation claims unless those claims are independently supported.

The paper positions A10 Core as the methodological nucleus of A10-ROS, an upstream research-construction protocol, and A10-ELP, a downstream evidence-led audit protocol. The ethical orientation of the method is human margin: preserving room for verification, correction, expert judgment, refusal, and non-exhaustive decision-making. A10 Core is not a universal theory or a replacement for domain expertise. It is a disciplined grammar for converting bold theoretical possibility into bounded, inspectable, and responsibly communicated research candidates.

## 日本語抄録

本稿は、A10 Coreを「大胆な理論探索」と「厳格な工程管理・主張境界」を両立させるための理論構築方法論として提示する。従来のA10運用では、言えることと言えないことを厳密に切り分ける姿勢が強く、その結果として、可能性を持つが危うい理論候補を探索段階から抑制し過ぎる危険があった。本改訂では、A10の役割を「大胆な仮説を抑制すること」ではなく、「制御されていない主張を抑制すること」として再定義する。

A10 Coreは、大胆な理論提唱、探索的検証、危うさを含む縮約モデル構築、AI支援による仮説生成、失敗可能性の高いパイロット検証を許容する。ただし、それらは監査可能な工程管理の内部に隔離されなければならない。具体的には、mission variableの定義、failure boundaryの抽出、reduced surrogateまたはminimal testable kernelの設計、structured prior / gate / barrier、比較対象・null条件・negative control、証拠台帳、失敗・nullアーカイブ、公開前のclaim boundary gateを要求する。

A10において、失敗、null、保留、archiveは副産物ではなく、第一級の認識論的成果である。失敗した探索経路であっても、破綻境界、negative control、棄却された機構、将来の比較対象を与える可能性がある。一方で、探索的成功は、それだけでは実用性、安全認証、専門家代替、物理発見、実地検証済みであることを意味しない。

本稿では、A10 Coreを、上流の研究構築プロトコルであるA10-ROS、および下流の証拠主導監査プロトコルであるA10-ELPの方法論的中核として位置づける。また、A10の倫理的方向性をhuman margin、すなわち検証・訂正・専門家判断・拒否・非消耗的意思決定の余白を保存することとして定義する。A10 Coreは万能理論でも専門家代替でもない。大胆な理論可能性を、限定され、監査可能で、責任ある研究候補へ変換するための方法論的文法である。

## Keywords

A10 Core; bold hypothesis; claim boundary; strict process control; reduced surrogate; minimal testable kernel; null comparator; evidence ledger; failure archive; human margin; AI-assisted research; research methodology

# 1. Introduction

Early-stage theory construction often faces a dilemma. If speculative hypotheses are suppressed too early, potentially valuable mechanisms may never be examined. If they are promoted too quickly, unsupported claims may enter public or technical discourse as if they were established knowledge.

A10 Core addresses this dilemma by separating **exploration permission** from **claim permission**. A theory candidate may be bold, speculative, cross-domain, or even likely to fail during exploration. However, it may not be publicly declared as validated, practical, safe, certified, or discovered unless the evidence supports that exact claim.

The guiding principle is:

```text
A10 does not suppress bold hypotheses.
A10 suppresses uncontrolled claims.
```

# 2. Motivation

The earlier restraint-centered posture of A10 helped prevent overclaiming. It also protected against dangerous transitions from incomplete analysis to public certainty. However, excessive restraint at the hypothesis stage can unintentionally destroy theoretical possibility.

A candidate may appear risky because it is underdeveloped, cross-domain, or dependent on uncertain mechanisms. Yet that is precisely why it should be examined under controlled conditions rather than dismissed before testing.

# 3. Core Method

The A10 Core method consists of the following sequence:

```text
bold hypothesis
  ↓
mission variable
  ↓
failure boundary / bottleneck
  ↓
minimal testable kernel
  ↓
structured prior / gate / barrier
  ↓
comparator / null / negative control
  ↓
exploratory validation
  ↓
evidence ledger
  ↓
failure / null / archive record
  ↓
claim boundary
  ↓
bounded public synthesis
```

# 4. Failure as Knowledge

A10 treats failure and null results as reusable knowledge. A failed route may identify a false-positive mechanism, hidden bottleneck, destructive-null condition, future negative control, invalidated mechanism, stronger limitation statement, or required expert review boundary.

# 5. Relation to A10-ROS and A10-ELP

A10 Core is the foundational methodology. A10-ROS is the upstream research-construction protocol. A10-ELP is the downstream evidence-led audit protocol. Under v0.2.1, A10-ROS should accept bold hypotheses into controlled exploratory construction rather than reject them prematurely, while A10-ELP remains strict about evidence-claim correspondence.

# 6. Non-Claims

This paper does not claim that A10 Core is a universal theory, validates generated theories automatically, replaces domain expertise, replaces experiments or peer review, proves practical readiness, proves safety, provides certification, establishes physical discovery, or solves social or political problems.

# 7. Human Margin

A10 Core is oriented toward human margin: room for verification, correction, refusal, expert review, and non-exhaustive decision-making. Bold exploration is justified only when it increases clarity and prevents false confidence.

# 8. Discussion

The revised A10 principle may be summarized as:

```text
Theory generation: bold
Exploratory validation: active
Process control: strict
Evidence handling: strict
Final claims: bounded
Public wording: conservative
```

This distinction is especially important for AI-assisted research. AI systems can generate plausible theoretical structures, but plausibility is not evidence.

# 9. Limitations

A10 Core is itself a methodology. It does not prove its own effectiveness merely by being defined. Future work should evaluate whether A10 templates improve claim discipline, whether failure archives improve reviewability, and whether the bold-exploration/strict-claims split helps preserve useful hypotheses without increasing public overclaim risk.

# 10. Conclusion

A10 Core v0.2.1 formalizes a revised operating principle:

```text
A10 = Bold Hypothesis + Strict Process + Bounded Claim
```

The method permits bold theory exploration while requiring strict process control, evidence logging, failure preservation, and bounded public claims.

# Acknowledgements

The author acknowledges the use of AI assistance in drafting, structuring, revising, and quality-checking this manuscript and the associated repository materials. All final responsibility for the content, claim boundaries, and release decisions remains with the author.

# References

Yoshimura, K. (2026). *A10 Core Foundational Methodology: A Claim-Bounded Framework for Verifiable Theory Construction under Uncertainty*. Independent research repository package. DOI record: 10.5281/zenodo.20343694.

Yoshimura, K. (2026). *A10-Core-Foundational-Methodology*. GitHub repository. Repository URL to be supplied in final submission metadata.


## v0.2.1 clarification

This revision adds a thread-start directive for A10 theory construction. The directive is intentionally asymmetric: it increases freedom at the hypothesis-construction entrance and maintains strict control at the evidence, audit, and public-claim exits.

```text
Speculative hypotheses may enter the protocol, but only evidence-bounded claims may exit it.
```
