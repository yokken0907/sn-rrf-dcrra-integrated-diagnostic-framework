# Zenodo Release Guide for A10 Core v0.2.1

## Critical rule

For GitHub-Zenodo integration:

```text
CITATION.cff version must match the GitHub release tag version.
```

For this release:

```text
GitHub release tag: v0.2.1
CITATION.cff version: "0.2.1"
```

Do not mismatch these fields.

## Recommended strategy

Use `CITATION.cff`. Do not include `.zenodo.json` unless a specific override is needed.

The prior successful workflow was achieved by aligning `CITATION.cff` version with the GitHub release tag.

## Known DOI

```text
10.5281/zenodo.20343694
```

If Zenodo assigns a new version-specific DOI to v0.2.1, record it after release and update future references.


## v0.2.1 safety note

Do not include a `doi` field in Zenodo helper metadata. Let Zenodo assign the new repository-archive DOI from the GitHub Release. Old DOI records may be described as repository archive history, not fixed into `CITATION.cff` as the current release DOI.
