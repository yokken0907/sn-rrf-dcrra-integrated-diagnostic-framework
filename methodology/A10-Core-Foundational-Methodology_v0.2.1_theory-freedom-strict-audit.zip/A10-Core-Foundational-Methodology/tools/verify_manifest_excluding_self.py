#!/usr/bin/env python3
"""Verify FILE_MANIFEST.csv hashes for A10 Core package.

The manifest intentionally excludes FILE_MANIFEST.csv, manifest.json,
SHA256SUMS.txt, and MANIFEST_VERIFY_PASS.txt so that verification can be
performed after manifest regeneration.
"""
from __future__ import annotations
import csv
import hashlib
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "FILE_MANIFEST.csv"

if not MANIFEST.exists():
    print("FAIL-MANIFEST-MISSING")
    sys.exit(1)

errors: list[str] = []
with MANIFEST.open("r", encoding="utf-8", newline="") as f:
    reader = csv.DictReader(f)
    for row in reader:
        rel = row["path"]
        p = ROOT / rel
        if not p.exists():
            errors.append(f"missing: {rel}")
            continue
        data = p.read_bytes()
        size = len(data)
        digest = hashlib.sha256(data).hexdigest()
        if size != int(row["bytes"]):
            errors.append(f"size mismatch: {rel}: {size} != {row['bytes']}")
        if digest != row["sha256"]:
            errors.append(f"sha256 mismatch: {rel}: {digest} != {row['sha256']}")

if errors:
    print("FAIL-MANIFEST-VERIFICATION")
    for e in errors:
        print(e)
    sys.exit(1)

print("PASS-MANIFEST-VERIFICATION")
print(f"verified_files={sum(1 for _ in csv.DictReader(MANIFEST.open('r', encoding='utf-8')))}")
