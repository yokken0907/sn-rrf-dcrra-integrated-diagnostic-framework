# Release Notes

## v0.2.1 — Theory-Freedom / Claim-Boundary Clarification

This is a clarification revision of the A10 Core v0.2.x methodology package.

### Main principle

```text
A10 = Bold Hypothesis + Strict Process + Bounded Claim
```

Japanese:

```text
A10 = 大胆な仮説 + 厳格な工程 + 限定された主張
```

### Clarification

```text
This directive expands theory-construction freedom, not claim-making permission.
Speculative hypotheses may enter the protocol, but only evidence-bounded claims may exit it.
```

### Added

- `A10_THEORY_FREEDOM_STRICT_AUDIT_DIRECTIVE_v0.2.1.md`
- `tools/verify_manifest_excluding_self.py`
- `MANIFEST_VERIFY_PASS.txt`

### Updated

- `README.md`
- `A10_OPERATIONAL_PRINCIPLE_v0.2.1.md`
- `A10_CORE_FOUNDATIONAL_THEORY.md`
- `BOLD_EXPLORATION_STRICT_CLAIMS.md`
- `A10_THEORY_CONSTRUCTION_TEMPLATE.md`
- `CLAIM_BOUNDARY_PUBLICATION_GATE.md`
- release / Zenodo helper metadata

### Zenodo / GitHub release requirement

```text
GitHub release tag = v0.2.1
CITATION.cff version = "0.2.1"
manifest.json version = "0.2.1"
zenodo_v0.2.1.json version = "0.2.1"
```

No DOI field is included in the Zenodo helper metadata.
