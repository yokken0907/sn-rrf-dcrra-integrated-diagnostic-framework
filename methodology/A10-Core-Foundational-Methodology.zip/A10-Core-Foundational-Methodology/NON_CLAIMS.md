# Non-Claims for A10 Core v0.2.0

A10 Core permits bold exploration. It does not permit uncontrolled claims.

This repository does **not** claim that A10 Core:

- is a universal theory;
- proves the correctness of any theory generated under it;
- replaces domain experts;
- replaces experiments, field measurements, peer review, safety review, or regulatory judgment;
- proves practical readiness;
- proves production readiness;
- proves safety;
- provides certification;
- establishes physical discovery;
- solves social or political problems;
- automatically validates AI-generated ideas;
- converts speculative hypotheses into accepted knowledge.

## Exploration non-claim

```text
explored ≠ accepted
tested ≠ validated
simulated ≠ practical
reduced surrogate ≠ real system
AI-assisted ≠ true
interesting ≠ publishable as fact
```

## Japanese summary

A10 Coreは大胆な理論探索を許容するが、未検証の断定を許容しない。探索段階では、危うい仮説や大胆な理論候補を扱ってよい。ただし、その結果を公開する際には、証拠範囲・失敗記録・null条件・主張境界・専門家評価の必要性を明示しなければならない。
