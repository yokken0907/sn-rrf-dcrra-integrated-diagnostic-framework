# Failure / Null / Archive Policy

A10 treats failure, null results, and archived routes as first-class outputs.

```text
A failed theory route may still protect future reasoning.
```

## Categories

- PASS: criteria satisfied within tested scope.
- FAIL: criteria not satisfied under tested conditions.
- NULL: no discriminative evidence.
- HOLD: necessary data, expert review, or validation context is missing.
- ARCHIVE: preserved as negative, incomplete, superseded, or cautionary record.

## Required archive fields

Every FAIL / NULL / HOLD / ARCHIVE record should include route name, version, date, hypothesis, mission variable, tested scope, failure or null condition, metrics, comparator outcome, claim implication, reason for archive, and reopening condition.

## Prohibited behavior

Do not delete failed branches, convert NULL into positive evidence, silently relax thresholds, omit negative controls from summaries, claim general success from a narrow pass, or hide fragility conditions.
