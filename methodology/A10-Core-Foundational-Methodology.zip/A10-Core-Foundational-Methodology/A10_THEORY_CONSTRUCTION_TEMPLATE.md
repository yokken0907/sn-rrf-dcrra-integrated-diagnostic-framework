# A10 Theory Construction Template v0.2.0

## 0. Entry classification

```text
[ ] Bold exploratory hypothesis
[ ] Reduced-surrogate diagnostic
[ ] Engineering feasibility surrogate
[ ] Evidence-audit protocol
[ ] Research OS / workflow component
[ ] Conceptual methodology
[ ] Archive / null-result report
```

## 1. Raw hypothesis

State the bold hypothesis freely. Do not weaken it merely to sound safe.

```text
Hypothesis:
```

## 2. Mission variable

```text
Mission variable:
```

## 3. Failure boundary / bottleneck

```text
Primary failure boundary:
Dominant bottleneck:
False-positive route:
Misuse risk:
```

## 4. Minimal testable kernel

```text
Inputs:
Assumptions:
Outputs:
Metrics:
Decision rules:
```

## 5. Comparator / null / negative control

```text
Baseline comparator:
Null comparator:
Negative control:
Destructive null:
Stress condition:
```

## 6. Exploratory validation plan

```text
Run ID:
Frozen thresholds:
Random seed:
Data source:
Expected failure modes:
Stop condition:
```

## 7. Failure / null archive

```text
Outcome:
[ ] PASS
[ ] FAIL
[ ] NULL
[ ] HOLD
[ ] ARCHIVE
[ ] REVISE

Reason:
Future reopening condition:
```

## 8. Claim boundary

```text
Allowed claims:
Forbidden claims:
Untested regions:
Required next validation:
```

## 9. Public wording gate

```text
[ ] Title bounded
[ ] Abstract bounded
[ ] Conclusion bounded
[ ] README bounded
[ ] Release notes bounded
[ ] No practical readiness claim
[ ] No safety certification claim
[ ] No expert replacement claim
[ ] No physical discovery claim unless independently validated
```
