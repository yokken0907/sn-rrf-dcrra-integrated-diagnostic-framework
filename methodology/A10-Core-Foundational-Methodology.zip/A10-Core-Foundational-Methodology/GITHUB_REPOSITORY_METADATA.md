# GitHub Repository Metadata v0.2.0

## Repository name

```text
A10-Core-Foundational-Methodology
```

## Description

```text
Claim-bounded methodology for bold theory exploration under strict process control.
```

## Topics

```text
a10
bold-hypothesis
claim-boundary
strict-process
theory-construction
research-methodology
reduced-surrogate
null-comparator
evidence-ledger
failure-archive
human-margin
ai-assisted-research
research-os
preprint-triage
independent-research
```

## Required version alignment

```text
GitHub release tag: v0.2.0
CITATION.cff version: "0.2.0"
manifest.json version: "0.2.0"
```
