# Null Comparator Template v0.2.0

## Candidate

```text
Hypothesis:
Mission variable:
Tested scope:
```

## Comparator design

| Type | Description | Expected role |
|---|---|---|
| Baseline comparator |  |  |
| Null comparator |  |  |
| Negative control |  |  |
| Destructive null |  |  |
| Stress condition |  |  |
| Holdout condition |  |  |

## Decision rule

```text
PASS if:
FAIL if:
NULL if:
HOLD if:
ARCHIVE if:
```
