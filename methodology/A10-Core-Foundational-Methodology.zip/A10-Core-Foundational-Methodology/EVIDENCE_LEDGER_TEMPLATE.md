# Evidence Ledger Template v0.2.0

## Project metadata

| Field | Entry |
|---|---|
| Project name |  |
| Version |  |
| Date |  |
| Hypothesis status | Bold exploratory / pilot / reduced-surrogate / audit / publication-ready |
| Mission variable |  |
| Claim boundary status | draft / frozen / revised |

## Evidence items

| ID | Evidence type | Condition | Metric | Result | Comparator/null | Decision | Claim implication |
|---|---|---|---|---|---|---|---|
| E001 |  |  |  |  |  | PASS / FAIL / NULL / HOLD / ARCHIVE |  |

## Failure / null / archive records

| ID | Route | Outcome | Failure/null condition | Why it matters | Future reuse |
|---|---|---|---|---|---|
| F001 |  | FAIL / NULL / HOLD / ARCHIVE |  |  |  |
