# GitHub Release Draft

## Tag

```text
v0.2.0
```

## Release title

```text
A10 Core Foundational Methodology v0.2.0 — Bold Exploration / Strict Claims Revision
```

## Release description

```markdown
# A10 Core Foundational Methodology v0.2.0 — Bold Exploration / Strict Claims Revision

This release updates A10 Core into a clearer operating framework:

**Bold Hypothesis + Strict Process + Bounded Claim**

A10 Core v0.2.0 clarifies that A10 does not suppress bold hypotheses. It suppresses uncontrolled claims.

## Main changes

- Added `A10_OPERATIONAL_PRINCIPLE_v0.2.0.md`
- Added `BOLD_EXPLORATION_STRICT_CLAIMS.md`
- Added `EXPLORATORY_VALIDATION_PROTOCOL.md`
- Added `FAILURE_NULL_ARCHIVE_POLICY.md`
- Added `CLAIM_BOUNDARY_PUBLICATION_GATE.md`
- Updated A10 Core theory, templates, A10-ROS relation, A10-ELP relation, and human-margin ethics
- Added manuscript drafts under `paper/`

## Core principle

```text
A10 = Bold Hypothesis + Strict Process + Bounded Claim
```

Japanese:

```text
A10 = 大胆な仮説 + 厳格な工程 + 限定された主張
```

## Non-claims

This release does not claim practical readiness, safety certification, expert replacement, field validation, physical discovery, universal theory status, or automatic validation of AI-assisted hypotheses.

## Zenodo release note

Before triggering GitHub-Zenodo archiving, confirm:

```text
GitHub release tag = v0.2.0
CITATION.cff version = "0.2.0"
```

Known prior DOI record: `10.5281/zenodo.20343694`. If Zenodo creates a new version-specific DOI, update downstream metadata after the archive is complete.

## Integrity

See `manifest.json`, `FILE_MANIFEST.csv`, and `SHA256SUMS.txt`.
```
