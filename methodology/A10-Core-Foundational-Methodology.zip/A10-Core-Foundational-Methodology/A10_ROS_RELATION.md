# Relationship between A10 Core v0.2.0 and A10-ROS

A10 Core is the foundational methodology. A10-ROS is the upstream research-construction operating protocol.

Version 0.2.0 changes the role of A10-ROS:

```text
A10-ROS should not prematurely reject bold hypotheses.
A10-ROS should intake them into controlled exploratory construction.
```

## A10-ROS stages under v0.2.0

| Stage | Purpose |
|---|---|
| ROS0 | Raw idea intake, including speculative hypotheses |
| ROS1 | Mission variable and failure boundary declaration |
| ROS2 | Claim boundary pre-lock for forbidden public claims |
| ROS3 | Minimal testable kernel construction |
| ROS4 | Comparator / null / destructive-null design |
| ROS5 | Exploratory validation run |
| ROS6 | Evidence ledger and failure archive |
| ROS7 | Revision / hold / archive decision |
| ROS8 | Claim-bounded synthesis |
| ROS9 | Repository / manuscript / release package |
