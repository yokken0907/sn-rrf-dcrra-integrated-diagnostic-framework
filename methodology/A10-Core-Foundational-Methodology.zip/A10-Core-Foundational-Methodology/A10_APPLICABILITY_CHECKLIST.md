# A10 Applicability Checklist v0.2.0

## Required

```text
[ ] A raw hypothesis or target
[ ] A mission variable
[ ] A plausible failure boundary
[ ] A reducible test kernel
[ ] A possible comparator or null
[ ] A way to log evidence
[ ] A way to state forbidden claims
```

## Strengthening factors

```text
[ ] High uncertainty
[ ] Risk of overclaiming
[ ] Cross-domain theory construction
[ ] AI-assisted reasoning
[ ] Need for failure preservation
[ ] Need for reduced-surrogate testing
[ ] Need for pre-publication claim-boundary review
```

## Warning signs

```text
[ ] It sounds impressive before it is testable
[ ] It has practical or safety implications
[ ] It could be mistaken for expert advice
[ ] It depends heavily on AI-generated coherence
[ ] It lacks comparators or nulls
[ ] It has no failure archive
```
