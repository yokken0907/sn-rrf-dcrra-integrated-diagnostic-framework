# Changelog

## v0.2.0

- Reframed A10 Core as Bold Hypothesis + Strict Process + Bounded Claim.
- Added exploratory validation protocol.
- Added failure/null/archive policy.
- Added claim-boundary publication gate.
- Updated templates and relation documents.
- Added methodology manuscript draft in Markdown and LaTeX.
- Added Zenodo release guide emphasizing CITATION.cff / release tag version alignment.
