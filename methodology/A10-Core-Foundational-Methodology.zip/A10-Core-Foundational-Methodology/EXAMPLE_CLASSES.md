# Example Classes under A10 Core v0.2.0

These are structural examples only, not claims of validation.

## Engineering surrogate

- mission variable: feasibility or safety margin
- failure boundary: thermal, material, control, or tail-risk limit
- kernel: reduced simulation or toy model
- output: PASS / FAIL / NULL / HOLD / ARCHIVE

## Research OS

- mission variable: evidence-claim correspondence
- failure boundary: overclaim, missing null, missing comparator
- kernel: staged research-construction protocol
- output: bounded candidate or archive

## Evidence audit

- mission variable: claim-boundary preservation
- failure boundary: unsupported public claim
- kernel: document/repository audit checklist
- output: pass/revise/hold/fail

## Bold exploratory theory

- mission variable: preserve theoretical possibility without public overclaim
- failure boundary: speculative mechanism promoted as truth
- kernel: minimal testable mechanism and null plan
- output: bounded hypothesis, negative archive, or revised candidate
