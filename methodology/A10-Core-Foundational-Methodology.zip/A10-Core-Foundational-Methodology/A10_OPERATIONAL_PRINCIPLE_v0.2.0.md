# A10 Operational Principle v0.2.0

## Bold Hypothesis + Strict Process + Bounded Claim

```text
A10 = Bold Hypothesis + Strict Process + Bounded Claim
```

Japanese:

```text
A10 = 大胆な仮説 + 厳格な工程 + 限定された主張
```

---

## Why this revision was necessary

A10 previously emphasized claim-boundary discipline so strongly that some potentially useful hypotheses could be suppressed too early. The updated view recognizes that risky, unstable, or speculative theory candidates may still be valuable if they are tested inside a strict process.

A theory that fails under controlled conditions still produces knowledge.

---

## Updated standard

| Domain | Standard |
|---|---|
| Hypothesis generation | Bold |
| Exploratory testing | Active |
| Failure treatment | Preserved |
| Process management | Strict |
| Evidence logging | Strict |
| Final declaration | Bounded |
| Public language | Conservative |

---

## Operating sentence

```text
A10 does not avoid dangerous ideas.
A10 isolates dangerous ideas inside strict process control.
```

Japanese:

```text
A10は危うい着想を避けるのではない。
危うい着想を、厳格な工程管理の内部に隔離して検証する。
```
