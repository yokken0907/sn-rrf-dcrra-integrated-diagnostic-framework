# Bold Exploration / Strict Claims

A10 separates **exploration permission** from **claim permission**.

A route may be explored even if it is speculative. A route may not be publicly claimed unless the evidence supports it.

---

## Exploration space

In exploration space, A10 permits questions such as:

```text
What if this mechanism works?
Where does it break?
Can a reduced surrogate expose a useful boundary?
Can failure itself teach us something?
Can a null result prevent future false claims?
```

---

## Claim space

In claim space, A10 asks:

```text
What exactly was tested?
Under what assumptions?
Against what comparators?
Which nulls were passed or failed?
What remains untested?
What must not be inferred?
```

---

## Correct path

```text
bold hypothesis
  ↓
controlled exploratory protocol
  ↓
evidence ledger
  ↓
failure/null/comparator review
  ↓
claim boundary
  ↓
bounded public statement
```
