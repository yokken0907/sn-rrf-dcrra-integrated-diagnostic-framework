# Release Notes

## v0.2.0 — Bold Exploration / Strict Claims Revision

This is a substantive philosophical and operational revision of A10 Core.

### Main principle

```text
A10 = Bold Hypothesis + Strict Process + Bounded Claim
```

Japanese:

```text
A10 = 大胆な仮説 + 厳格な工程 + 限定された主張
```

### Added

- `A10_OPERATIONAL_PRINCIPLE_v0.2.0.md`
- `BOLD_EXPLORATION_STRICT_CLAIMS.md`
- `EXPLORATORY_VALIDATION_PROTOCOL.md`
- `FAILURE_NULL_ARCHIVE_POLICY.md`
- `CLAIM_BOUNDARY_PUBLICATION_GATE.md`
- `ZENODO_RELEASE_GUIDE.md`
- `paper/a10_core_v0_2_0_methodology_note.md`
- `paper/a10_core_v0_2_0_methodology_note.tex`
- `paper/JXIV_SUBMISSION_METADATA_DRAFT_v0.2.0.md`

### Zenodo release requirement

```text
GitHub release tag = v0.2.0
CITATION.cff version = "0.2.0"
```
