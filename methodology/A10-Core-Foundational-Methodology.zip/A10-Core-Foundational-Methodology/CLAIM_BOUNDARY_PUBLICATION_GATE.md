# Claim Boundary Publication Gate

Before any public-facing release, manuscript, README, abstract, conclusion, one-page brief, or outreach text is published, it must pass this gate.

## Gate 1 — Evidence scope

State exactly what was tested, what was not tested, what model or surrogate was used, and whether the result is exploratory, reduced-surrogate, simulation-only, diagnostic-only, or conceptual.

## Gate 2 — Forbidden claims

Explicitly exclude unsupported claims such as practical readiness, production readiness, safety certification, expert replacement, physical discovery, social solution, commercial performance, real-world deployment, or universal theory status.

## Gate 3 — Wording scan

| Risky word | Safer alternative |
|---|---|
| proven | supported within tested scope |
| solved | addressed in a limited diagnostic setting |
| validated | evaluated in a reduced-surrogate setting |
| practical | pre-engineering / evaluation-only |
| safe | safety not established |
| certified | not certified |
| discovery | candidate / diagnostic signal / hypothesis |
| universal | methodologically reusable, not universal |

## Gate 4 — Public statement template

```text
This work presents [artifact type] for [limited purpose].
It was evaluated under [tested scope].
It does not establish [forbidden claims].
The result should be interpreted as [bounded interpretation].
Further work requires [expert review / empirical validation / field data / safety assessment].
```
