# A10 Exploratory Validation Protocol

This protocol allows bold or risky theory candidates to be explored without allowing uncontrolled claims.

## EV0 — Entry declaration

Declare hypothesis name, exploratory status, uncertainty source, mission variable, forbidden claims, and minimum evidence needed to proceed.

Output:

```text
STATUS: ENTER-EXPLORATORY-VALIDATION
```

## EV1 — Failure-boundary extraction

Identify primary failure modes, false-positive routes, hidden assumptions, domain-transfer risks, misuse risks, and evidence gaps.

Output:

```text
STATUS: FAILURE-BOUNDARY-MAPPED
```

## EV2 — Minimal testable kernel

Define inputs, assumptions, outputs, metrics, baselines, stress cases, null cases, and decision rules.

Output:

```text
STATUS: MINIMAL-TESTABLE-KERNEL-DEFINED
```

## EV3 — Comparator and null design

Define baseline comparator, null comparator, negative control, destructive null, stress regime, and holdout condition when applicable.

Output:

```text
STATUS: COMPARATOR-NULL-PLAN-LOCKED
```

## EV4 — Exploratory run

Run the pilot without changing thresholds midstream. Record code version, parameters, random seed, input data, output metrics, failures, anomalies, and review events.

Output:

```text
STATUS: EXPLORATORY-RUN-COMPLETE
```

## EV5 — Decision

Allowed decisions:

```text
PASS-WITHIN-TESTED-SCOPE
FAIL-WITHIN-TESTED-SCOPE
NULL-NO-DISCRIMINATIVE-EVIDENCE
HOLD-PENDING-DATA
ARCHIVE-NEGATIVE-ROUTE
REVISE-AND-RERUN-WITH-DECLARED-CHANGE
```

## EV6 — Claim boundary

Freeze allowed claims, forbidden claims, untested regions, required expert review, and required empirical or field validation.

Output:

```text
STATUS: CLAIM-BOUNDARY-FROZEN
```
