# A10 Core Foundational Methodology

**Version:** 0.2.0  
**Core principle:** Bold Hypothesis + Strict Process + Bounded Claim  
**Japanese:** 大胆な仮説 + 厳格な工程 + 限定された主張  
**Author:** Keiji Yoshimura  
**Known Zenodo DOI record:** `10.5281/zenodo.20343694`

---

## Overview

A10 Core is a claim-bounded methodology for constructing, testing, failing, archiving, and communicating theory candidates under uncertainty.

Version 0.2.0 is a substantive philosophical and operational revision. Earlier A10 practice emphasized strict separation between what may and may not be claimed, sometimes suppressing risky or speculative hypotheses too early. This release clarifies the updated distinction:

```text
A10 does not suppress bold hypotheses.
A10 suppresses uncontrolled claims.
```

Therefore, A10 permits ambitious theory proposal, exploratory validation, failure-prone reduced-surrogate modeling, AI-assisted hypothesis generation, and risky pilot testing, provided that all such work remains inside strict process control, evidence logging, failure/null archiving, and bounded public claims.

---

## What A10 Core does

A10 Core transforms uncertain targets into auditable candidates by defining:

- mission variables;
- failure boundaries and dominant bottlenecks;
- reduced surrogates / minimal testable kernels;
- structured priors, gates, and barriers;
- comparator, null, negative-control, destructive-null, and stress-test plans;
- evidence ledgers;
- failure / null / hold / archive records;
- claim-boundary publication gates;
- human-margin-oriented final synthesis.

---

## What changed in v0.2.0

| Layer | Previous tendency | v0.2.0 standard |
|---|---|---|
| Hypothesis generation | restrained early | bold exploration permitted |
| Risky theory candidates | often avoided | accepted into controlled protocol |
| Exploratory validation | conservative | active and failure-tolerant |
| Failure / NULL | preserved | first-class epistemic output |
| Process control | strict | strict |
| Evidence handling | strict | strict |
| Public claims | bounded | bounded |
| Public wording | conservative | conservative |

This is not a relaxation of claim boundaries. It is a separation between exploration freedom and publication discipline.

---

## Non-claims

This repository does not claim that A10 Core:

- is a universal theory;
- validates any generated theory automatically;
- replaces domain expertise;
- replaces experiments, measurements, peer review, safety review, or regulatory judgment;
- proves practical readiness;
- proves production readiness;
- proves safety;
- provides certification;
- establishes physical discovery;
- solves social or political problems;
- justifies unsafe deployment or human exhaustion.

---

## Relation to A10-ROS and A10-ELP

```text
A10 Core = foundational methodology
A10-ROS  = upstream research-construction protocol
A10-ELP  = downstream evidence-led audit / moderation protocol
Applied A10 theories = implementation examples
```

A10-ROS may intake bold hypotheses into controlled exploratory construction. A10-ELP remains strict about evidence-claim correspondence and public claim boundaries.

---

## Critical Zenodo release rule

Before release, verify:

```text
GitHub release tag = v0.2.0
CITATION.cff version = "0.2.0"
manifest.json version = "0.2.0"
```

Do **not** include `.zenodo.json` by default. The successful workflow should use `CITATION.cff` with version aligned to the GitHub release tag.
