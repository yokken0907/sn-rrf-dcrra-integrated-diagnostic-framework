# Human Margin Ethics v0.2.0

A10 Core is not primarily a method for making humans produce more output faster. Its deeper orientation is to preserve **human margin**:

- room to verify;
- room to pause;
- room to correct;
- room for expert review;
- room to refuse unsupported claims;
- room to recover from failure;
- room not to be exhausted by systems that hide uncertainty.

Bold exploration can increase human margin when it reveals hidden failure boundaries and prevents false confidence. It can reduce human margin when converted into premature deployment, unsafe claims, or pressure for acceleration.

```text
Bold exploration is permitted.
Unsafe acceleration is not.
```
