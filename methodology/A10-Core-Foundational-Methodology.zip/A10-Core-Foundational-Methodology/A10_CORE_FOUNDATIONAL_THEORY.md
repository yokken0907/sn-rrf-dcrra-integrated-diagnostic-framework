# A10 Core Foundational Theory v0.2.0

## A Claim-Bounded Methodology for Bold Theory Exploration under Strict Process Control

A10 Core is a methodology for constructing, testing, failing, archiving, and communicating theory candidates under uncertainty.

Version 0.2.0 formalizes the following principle:

```text
A10 does not suppress bold hypotheses.
A10 suppresses uncontrolled claims.
```

---

## 1. Fundamental separation

A10 separates three layers:

| Layer | Allowed posture | Required control |
|---|---|---|
| Theory proposal | bold, imaginative, cross-domain, risky | explicit exploratory label |
| Exploratory validation | active, failure-tolerant, stress-oriented | logs, nulls, comparators, gates, archives |
| Public claim | conservative, bounded, evidence-limited | claim boundary and publication gate |

The short grammar is:

```text
Exploration may be bold.
Evidence handling must be strict.
Final claims must be bounded.
```

---

## 2. Core transformation grammar

```text
bold hypothesis
  ↓
mission variable
  ↓
failure boundary / bottleneck
  ↓
minimal testable kernel
  ↓
structured prior / gate / barrier
  ↓
comparator / null / negative control
  ↓
exploratory validation
  ↓
evidence ledger
  ↓
failure / null / archive record
  ↓
claim boundary
  ↓
bounded public synthesis
```

---

## 3. Bold hypotheses are allowed

A10 permits:

- ambitious theory proposals;
- speculative mechanism construction;
- high-uncertainty candidate models;
- AI-assisted theory drafts;
- cross-domain analogies;
- exploratory tests that may fail;
- destructive-null attacks against a candidate;
- repeated refinement after logged failure.

Entry into exploration is not public acceptance.

---

## 4. Forbidden transitions

A10 prohibits uncontrolled promotion from exploration to claim:

- exploratory result → practical readiness claim;
- reduced surrogate → real-world validation claim;
- simulation success → safety certification claim;
- AI-generated coherence → truth claim;
- null/failure result → hidden omission;
- cherry-picked success → general theory claim;
- unstable prototype → deployment recommendation;
- conceptual framework → expert replacement claim.

---

## 5. Failure as output

In A10, failure is not waste. A failed route may produce a boundary condition, false-positive warning, null result, destructive-null archive, refined mission variable, rejected mechanism, future comparator, or stronger claim boundary.

```text
FAIL / NULL / HOLD / ARCHIVE are not embarrassing side effects.
They are part of the epistemic output.
```

---

## 6. Human margin

A10 is not primarily a method for forcing more output from humans. It should preserve room for verification, correction, refusal, expert review, rest, and non-exhaustive judgment.

A10 should not be used to justify unsafe acceleration, forced efficiency, expert bypass, hidden risk transfer, or exhaustion disguised as productivity.
